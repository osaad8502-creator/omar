    ░█████╗░██████╗░██████╗░░█████╗░██████╗░██╗████████╗██╗░█████╗░███╗░░██╗
    ██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔══██╗██║╚══██╔══╝██║██╔══██╗████╗░██║
    ███████║██████╔╝██████╔╝███████║██████╔╝██║░░░██║░░░██║██║░░██║██╔██╗██║
    ██╔══██║██╔═══╝░██╔═══╝░██╔══██║██╔══██╗██║░░░██║░░░██║██║░░██║██║╚████║
    ██║░░██║██║░░░░░██║░░░░░██║░░██║██║░░██║██║░░░██║░░░██║╚█████╔╝██║░╚███║
    ╚═╝░░╚═╝╚═╝░░░░░╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝

    Menu:                 Apparition
    Developer:            CF4_99
    Version:              1.6.0.9
    Discord:              cf4_99
    YouTube:              https://www.youtube.com/c/CF499
    Project Start Date:   6/10/21
    Initial Release Date: 1/29/23

    Apparition Discord Server: https://discord.gg/apparitionbo3

    Menu Source & Current Update: https://github.com/CF4x99/Apparition
    IF YOU USE ANY SCRIPTS FROM THIS PROJECT, OR MAKE AN EDIT, LEAVE CREDIT.

    Credits:
        - Extinct ~ Ideas, Suggestions, Constructive Criticism, and His Spec-Nade
        - CraftyCritter ~ BO3 Compiler
        - ItsFebiven ~ Ideas and Suggestions
        - Joel ~ Suggestions, Bug Reports, and Testing The Unique String Crash Protection

    If you find any bugs, or come across something that you feel isn't working as it should, please message me on discord.

    Discord: cf4_99



## Changelog

<details>
    <summary>
        Version 1.6.0.9
    </summary>

    - Added: Menu Base -- Small opening animation for options only
    - Added: Server Modifications -- End Game
    - Added: Host Menu -- Music Player -- Black Ops Music tracks that will play for the whole lobby
    - Added: Basic Scripts -- More visions to choose from
    - Added: Server Modifications/Quick Menu -- Restart Game Slider(Full / Fast)

    - Changed: Menu Base -- Instructions, entity count, zombie counter, and player info display designs should better match the current design menu design being used
    - Changed: Menu Base -- You no longer have to hit your use/activate button to save the values when using the width and position editors in menu customization
    - Changed: Menu Base -- Replaced "Physics 'n' Flex" design wtih "Basic" design(much better imo)
    - Changed: Menu Base -- Reposition Menu -- Now includes a custom offset value for you to decide the amount it moves while you are choosing the position
    - Changed: Menu Base -- Instructions -- The instructions text will now always align left when the background is disabled(issue with alternate instructions style)
    - Changed: Spawnables -- Mexican Wave -- It will now spawn at your crosshair position
    - Changed: HUD -- entity count position will adapt depending on whether zombie counter is enabled or not

    - Fixed: Menu Base -- Server text(all client hud) using the client archive system instead of always being archived -- Caused hud issues
    - Fixed: Menu Base -- Issue with 'RandomPosText' function -- Used for the 'Moving' doheart style
    - Fixed: Menu Base -- Soft Lock -- Issue with outline height for the AIO design
    - Fixed: Menu Base -- Adaptive Menu Instructions -- Should be more responsive and smoother now
    - Fixed: Menu Base -- Possible issue with saving a players verification
    - Fixed: Menu Customization -- Issues when repositioning menu instructions
    - Fixed: Menu Customization -- Reposition Menu Instructions -- Repositioning should be a little smoother now
    - Fixed: Server Tweakables -- Shoot To Revive -- Improved accuracy of shooting a downed player
    - Fixed: Visual Effects -- Issues causing a lot of dev errors when developer mode is enabled
    - Fixed: Aimbot -- Typo that could cause issues with the IsVisible function
</details>

<details>
    <summary>
        Version 1.6.0.8
    </summary>

    - Changed: Menu Base -- I moved the default menu position a little to the left
    - Changed: Menu Base -- Removed the need for relative point for hud

    - Fixed: Menu Base -- Critical bug with scrolling system causing hud count to be wrong and cause hud to flicker(reported by nemming - thank you)
    - Fixed: Menu Base -- Apparition is now fully undetected by the UEM anti-cheat again
    - Fixed: Newsbar -- Now supports ultra-wide screens
    - Fixed: Black Screen -- Now supports ultra-wide screens
    - Fixed: Light Protector -- A few issues with damage, radius, and targeting -- Should be perfect now
    - Fixed: Death Skull -- Fixed an issue with the skull effects
</details>

<details>
    <summary>
        Version 1.6.0.7
    </summary>

    - Special thank you to Joel and nemming for making reports and suggestiongs :P

    - I've rewritten the weaponry system. I know the weaponry has been plagued with some weapons not being classed correctly, which would place them in the wrong weapon category in the menu.
    - That should be mostly fixed now. You still might see that issue on custom maps, but that is 100% out of my control(they're literally classed as pistols with no way for me to tell their real class)

    - Added: Host Menu -- Entity Count Display(This will not affect menu hud) -- Displays current entity count and max entity count for the map -- Bool saves through games as well
    - Added: Menu Customization -- Menu Instructions -- Alternate Instructions Style(suggested by Joel)
    - Added: Menu Customization -- Menu Instructions -- Option to disable instructions background(suggested by Joel)
    - Added: Mystery Box Options -- Disable -- This will disable the mystery box trigger completely so no one can use it(suggested by nemming)
    - Added: Game Modes -- Mod Menu Lobby
    - Added: Host Menu -- FOV Scale Slider
    - Added: Fun Scripts -- Shoot Power-Ups Slider(Disable / Drop / Apply Physics) -- Apply Physics will launch the power-ups like bullets -- Drop will just spawn a power-up at your bullet end position

    - Changed: Light Protector -- Now shoots orbs(same as ufo orbs) at the target ai instead of moving to the target ai and killing them
    - Changed: Skybase -- Updated skybase locations(locations found by Joel)
    - Changed: Rapid Fire -- Switched from a burst fire to a full auto when holding down the fire button(mentioned by nemming)
    - Changed: Keyboard Input -- Increased max string size to 45 characters
    - Changed: Adaptive Instructions -- Better support for the Physics 'n' Flex design
    - Changed: Artillery Strike -- You will no longer see any firing effect coming from your guns muzzle during the strike
    - Changed: G_Spawn Crash Protection -- Better limits for SOE, DE, ZNS, GK, and Rev
    - Changed: GetTextWidth -- Rewrote parts of my utility function 'GetTextWidth' to hopefully get a better width for shaders based on string length

    - Fixed: Retain Perks -- When a player died with 'Retain Perks' enabled, the perks would never be removed from the active perk array(3arc is gay) this caused issues with giving/taking perks(reported by Joel)
    - Fixed: Mexican Wave -- Model angles when spawned
    - Fixed: Spawnables -- There was a possibility that perk machine cobwebs would be used as the model for spawnables(reported by Joel)
    - Fixed: Profile Management -- Skipping from level 1, to prestige 11(master) level 1000 would skip unlocks for the players account and they won't be able to unlock anything(reported by Joel)
    - Fixed: Weaponry -- Attachments -- Every attachment supported by your current weapon should now display(reported by Joel)
    - Fixed: Aimbot -- Not all AI types(i.e. wasps) would be targeted when requirement is set to 'Visible'
    - Fixed: Aimbot -- Targeting ai that isn't fully spawned yet(reported by Joel)
    - Fixed: Light Protector -- Targeting ai that isn't fully spawned yet(reported by Joel)
    - Fixed: Player Intersection Override -- Forgot to include a parameter for the override which would throw a dev error each time it was called(which is basically any time there is more than 1 player in the lobby)
</details>

<details>
    <summary>
        Version 1.6.0.6
    </summary>

    - Added: Spawnable System -- Added a failsafe to spawnables that will stop and delete the spawned structure if any part fails to spawn
    - Added: Skybase -- Location Selection -- You can now select if you want the skybase spawned at a custom location, or a pre-set location(suggested by Joel) -- Pre-set location only available for base maps
    - Added: Skybase -- Position Editor -- Edit the xyz(position) values of the skybase origin(Flyable base next? :P)
    - Added: Utilities -- Prop System -- I built a custom prop system to replace the skybase perk bottle spawner -- This will make it easier to spawn prop models for other scripts like the skybase, in future updates
    - Added: Advanced Scripts -- Flyable UFO
    - Added: Menu Customization -- Menu Preferences -- Option to enable no target while the menu is open

    - Changed: Skybase -- When selecting a custom location, you will now see a glowing preview of the floor layout
    - Changed: Skybase -- Custom Location Selection -- You can now melee to exit the location selector and cancel spawning the skybase
    - Changed: Spawnables -- Moved tornado, spiral staircase, mexican wave, and rain options from Advanced Scripts to Spawnables
    - Changed: Advanced Scripts -- Artillery Strike -- Now uses a waypoint icon to visualize target location
    - Changed: Rain Options -- All rain options will be shown as bool and when selected, it can be selected again to disable rain

    - Fixed: Zombie Options -- Zombie Death Sounds -- It would actually enable disappearing zombies by mistake
    - Fixed: Anti-Join -- it was completely broken
    - Fixed: Spawnable System -- Allowed you to spawn more than one large spawnable(you should be limited to one due to entity limits)
    - Fixed: Fun Scripts -- Death Skull -- Electric fx would only play when the death skull is initially spawned
    - Fixed: Custom Button Combinations -- You can't pair +frag & +smoke buttons together -- Something I can't fix(engine related)
</details>

<details>
    <summary>
        Version 1.6.0.5
    </summary>

    - This update was mainly pointed at bug fixes and improvements
    - This update should fix the issues with spawning zombies on maps like DE, origins, and Rev(spawned special zombies) -- Spawning zombies with the menu(including Controllable zombie and Body Guard)  should spawn the correct zombie types now

    - Added: Server Modifications -- Set Round -- It is now a submenu (Custom / Next Round / Previous Round)

    - Changed: You should now always be able to press and hold actionslots 1 & 3 to scroll and use sliders(Excluding actionslot 3 on origins) -- This will also disable the gobblegum bind for actionslot 1 & alt weapon in actionslot 3 while the menu is open
    - Changed: Setting rounds should be a little better -- probably won't really be noticable though

    - Fixed: Zombie Spawning -- Scripts that involve spawning zombies will now spawn the correct zombie types
    - Fixed: isPlayerLinked -- 'isPlayerLinked' check was bad and allowed the player to link to an entity, while already linked to another
    - Fixed: All The Weapons Gamemode -- Gamemode hud wasn't being created for all players


    ** Credit to Daltax for These Reports **
    - Changed: Bullet Menu -- Effects -- Effects will now only show for 1/2 a second then despawn

    - Fixed: Advanced Scripts -- Tornado -- Spawning the tornado after hitting the g_spawn limit would bypass the g_spawn crash protection, and crash -- Also fixed some minor issues with tornado logic
    - Fixed: Player Collision Damage -- Disabled player intersection(collision) tracking for damage -- This will prevent taking damage from teleporting/attaching to players
    - Fixed: Zombie Options -- Damage/Death Effect -- Some effects would crash your game due to how I was playing the fx
</details>

<details>
    <summary>
        Version 1.6.0.4
    </summary>

    - You should now be able to compile this source for PS4 with no changes needed
    - With the new additions for 'Zetsubou No Shima' you should be able to easily complete the EE within 10 minutes :P

    - Added: Menu Customization -- Physics 'n' Flex Menu Design -- This design will always have a max option count of 6
    - Added: Menu Customization -- Menu Instructions -- Reset Position
    - Added: Teleport Menu -- Entity Teleports -- Crafting Tables -- obviously this will only show for maps that have crafting tables
    - Added: Teleport Menu -- Zetsubou No Shima Teleports -- Easter Egg Room
    - Added: Zetsubou No Shima -- Skulltar Teleports -- Added 'Podium' to teleport back to the skull podium
    - Added: Zetsubou No Shima -- Flak Gun Bullet -- This will collect a flak gun bullet for you so you don't have to collect it from a plant
    - Added: Zetsubou No Shima -- KT-4 Upgrade Parts -- You can now collect the vial and plant for the KT-4 upgrade -- The spider fang is a fast and easy step...So I'm not making a script for it
    - Added: Zetsubou No Shima -- Mesmerize Map -- This step is needed to complete steps in the EE, so figured I would add it
    - Added: Der Eisendrache -- Side Easter Eggs -- Complete Plunger Side Easter Egg

    - Changed: Unlimited Special Weapon Has Been moved from 'Fun Scripts' To 'Basic Scripts'
    - Changed: Menu Base -- Increased distance between options and bool boxes when bool box location is set to the left side

    - Fixed: LUI Hud -- Fixed possible color issue when creating LUI hud
    - Fixed: Reposition Menu Instructions -- Issue that caused a dev error when exiting the position editor
    - Fixed: Advanced Scripts -- AC130 -- Players were able to use noclip while AC130 was active
    - Fixed: Zetsubou No Shima -- Controllable Spider -- Undefined sessionstate check that was throwing errors
    - Fixed: Fun Scripts -- Force Field -- Bug with radius for death skull and light types
</details>

<details>
    <summary>
        Version 1.6.0.3
    </summary>

    - Added: Menu Customization -- 'Classic' Menu Design -- Classic Apparition Design
    - Added: Menu Customization -- Bool box location -- Change where the bool boxes display(Right Side / Left Side)
    - Added: Menu Customization -- Custom Scroll Animation Time(ms) -- Lower number = faster scrolling -- Higher number = slower scrolling
    - Added: Menu Customization -- Option Counter -- This will remove 2 options from max option display count -- Not available for AIO design
    - Added: Menu Customization -- Menu Instructions -- Adaptive Position -- Instructions will appear below the menu and change position based on the menu position, width, and height
    - Added: Menu Customization -- Menu Instructions -- Reposition -- Set a custom position for menu instructions(credit to Dehabify for the suggestion)
    - Added: Host Menu -- Custom player score colors -- Select the player index(1 - player count) and set the color for that scorecard -- Also changes overhead name color -- Only shows for you(the host) upon the start of a new match

    - Changed: Menu Designs -- Decreased the space between menu options
    - Changed: Native Design -- Lowered the opacity of the scroller & banner
    - Changed: RGB Fade -- Dimmed the brightness of colors
    - Changed: Basic Scripts -- Custom Crosshairs -- Switched to LUI hud and fixed the issue with color not updating
    - Changed: Fun Scripts -- Effect Man Options -- If you select the effect that is currently being used, it will disable effect man
    - Changed: Fun Scripts -- Nuke Nades -- The nuke model that is attached to the grenade will now have the powerup glow effect
    - Changed: Fun Scripts -- Force Field Options -- You can now adjust the force field size for all types
    - Changed: Fun Scripts -- Health Bar -- Switch to LUI hud -- Shown in the bottom left under your score -- It will now show regardless of whether you're in the menu or not
    - Changed: Fun Scripts -- Zombie Counter -- Switched to LUI hud to avoid hud limitation issues -- Now in top left

    - Fixed: Menu Designs -- Rebuilt all designs and corrected several issues
    - Fixed: Menu Base -- Text Bool Display(ON / OFF) alignment -- The math used for the position had a typo
    - Fixed: Menu Base -- Potential crash when closing the quick menu while having instructions disabled -- Rare, but possible
    - Fixed: Player Info -- Player Info was hidden behind the menu
    - Fixed: Basic Scripts -- Issue with Unlimited equipment not refilling both tactical and lethal equipment
    - Fixed: Fun Scripts -- Light Protector -- Bug with the light fx not showing
    - Fixed: Der Eisendrache Scripts -- Fire Bow -- Issue with undefined flag
</details>

<details>
    <summary>
        Version 1.6.0.2
    </summary>

    - Added: Menu Customization -- Menu Design Selection (Apparition / Native / AIO)
    - Added: Menu Customization -- Menu Width Editor
    - Added: Menu Customization -- Option to change bool display (Boxes / Text / Text Color)
    - Added: Menu Customization -- Stealth UI -- This will set option display count to 5(due to hud limitation) and disable bool box display type -- menu ui will be completely hidden from anyone spectating you
    - Added: Menu Customization -- Quick Exit -- When enabled, you can hold your melee button down for 1 second and the menu will close and save where you're at
    - Added: Menu Customization -- Spotlight cursor -- Dims the opacity for all options except the cursor
    - Added: Menu Customization -- Toggle for Large cursor
    - Added: Host Menu -- Field Of View Slider -- There is no way of setting fov for all clients, so it will stay in Host Menu
    - Added: Player Malicious Options -- Loop Stance
    - Added: Entity Options -- Lists all entities on the map and allows you to select a specific entity, or all entities, to control
    - Added: Server Modifications -- Anti-Join -- Added an optional custom input clan tag password(saves through games)
    - Added: Color Selection -- Several new colors

    - Changed: Menu Base -- Option display count = 10 -- disable instructions = count + 1 -- set bool display to text or text color = count + 2 -- Both together = count + 4 -- max possible option count will be 14
    - Changed: Menu Base -- Menu cursor now saves at any position again instead of resetting if you didn't scroll past a certain point
    - Changed: Menu Base -- Scrolling System -- Minimalized the scrolling system
    - Changed: Scroller for the keyboard and numberpad is now the main theme color to make it easier to see
    - Changed: Color Selection -- Updated/improved the approach of color selection
    - Changed: Keyboard/Numberpad -- Both should now align perfectly with the menu, based on menu width

    - Fixed: Shadows Of Evil Scripts -- Bug With toggling beast mode for players(again)
</details>

<details>
    <summary>
        Version 1.6.0.1
    </summary>
    - I know Apparition has drifted a bit over time, and some of what made it feel unique, and honestly hard to compete with, has slipped.
    I’m not promising overnight fixes, but I’m hoping the recent updates and the ones ahead will slowly get it back to where it should be.
    New features will be coming to Apparition...stay tuned
    Please report any/all bugs/issues you encounter -> Discord: cf4_99
    

    - Added: Server Modifications -- Anti-Join (Requested by a PS User)
    - Added: Menu Base -- Blank or invalid option spacer -- This will display a wide bar as a spacer indicating a blank or invalid option that will be skipped when scrolling
    - Added: Menu Customization -- Ability to change the open controls for both Apparition and the Quick Menu

    - Changed: Menu Design -- The new design should be a little more modern looking -- Still not 100% set on it though
    - Changed: Menu Base -- When menu instructions are enabled max option count is 10, when instructions are disabled, max option count is 11
    - Changed: RGB Fade -- Rewrote the RGB fade so color cycling is smoother and covers a bigger range of colors

    - Fixed: Scrolling System -- Auto-scrolling over blank options should look a little smoother now
    - Fixed: Scrolling System -- Major Rewrite -- The max number of options shown on screen can now be set to an even value without breaking, and options should create and destroy correctly
    - Fixed: Revelations -- Fixed an override issue on Revelations that caused god mode and demi-god to not work
    - Fixed: Origins Scripts -- Disable Tank Cooldown
    - Fixed: Origins Scripts -- Dev errors being thrown when disabling mud slowdown -- Caused by undefining the entity array used by the mud slowdown monitor
    - Fixed: Der Eisendrache Scripts -- Bug with completing wolf bow 'Escort & Collect Wolf Souls'
    - Fixed: Shadows Of Evil Scripts -- Bug With toggling beast mode for players
</details>

<details>
    <summary>
        Version 1.6.0.0
    </summary>

    - I am aware of a crashing issue after some time in a match while using Apparition...That should 100% be fixed now(sorry it took so long for me to see it)
    - Apparition got a much needed structure rebuild which even includes a new and refined 3d scrolling system
    - The rebuild also changed the design completely, which might be temporary(idk yet)...The quick menu also shares this design

    - Removed: Several menu customization options

    - Changed: Major rewrite of the whole Apparition base structure
    - Changed: Replaced old scrolling system with a new and refined 3D scrolling system
    - Changed: Bullet Projectiles -- Added fallback 'MagicBullet' start origin for the case that 'GetWeaponMuzzlePoint' doesn't return a valid origin
    - Changed: 'All Players Menu' will now be visible even in a solo match
    - Changed: 'Game Modes' can only be seen/accessed by the host
    - Changed: 'Projectiles' -- Projectile Spread Multiplier is now 1 by default(was 10 by default)
    - Changed: 'Projectiles' -- You will now get a list of all available weapons -- each weapon option will be a slider for you to choose the base weapon or upraded bullets(if upgrade is available)

    - Fixed: Apparition Backend -- Fixed issues causing dev errors to be thrown for trying to access undefined array(s) -- Started happening in a recent update
    - Fixed: Aimbot -- Enabling 'In Playable Area' would break targeting for some AI types(i.e. dogs)
</details>

<details>
    <summary>
        Version 1.5.1.8
    </summary>
    - PS4 Users: I will now start including a pre-compiled version with each release(can be found in the release section on the Apparition Github repository)
    - The PS4 is identical to the version found on my Github aside from custom map scripts, and other stuff not needed on console

    - Added: Fun Scripts -> Hit Marker Options -> Hitmarker Sound
    - Added: Fun Scripts -> Frog Jump
    - Added: Der Riese: Declassified -> Custom teleport locations
    - Added: Der Riese: Declassified -> Turn on power
    - Added: Der Riese: Declassified -> Space for scripts to be added for the map
    - Added: Leviathan -> Custom teleport locations
    - Added: Leviathan -> Turn on power
    - Added: Leviathan -> Space for scripts to be added for the map
    - Added: Farm Survival -> Custom teleport locations
    - Added: Farm Survival -> Turn on power
    - Added: Farm Survival -> Space for scripts to be added for the map

    - Removed: Der Riese: Declassified -> Removed 'Wunderwaffe DG-Scharfschutze' craftable parts -- Collecting those parts using the menu would break the EE
    - Removed: Weaponry -> Attachments -> 'Correct Invalid Combination' -- It will now automatically correct invalid attachment combinations
    - Removed: 'Brick Account' option -- lol

    - Changed: G_Spawn Crash Protection -- Now works properly for supported custom maps
    - Changed: G_Spawn Crash Protection -- Will no longer be usable for unsupported custom maps(caused some custom maps to be unplayable)
    - Changed: Menu Base -- Slider options will now save the current slider value again
    - Changed: Custom game over message will no longer display for unsupported custom maps -- NOTE: this only displays for players that have been given access to the menu

    - Fixed: Duplicate function defintion -- 'GameOverHandle' was defined more than once -- Should fix compilation error when compiling with serious's t7 compiler
</details>

<details>
    <summary>
        Version 1.5.1.7
    </summary>
    
    - Changed: secret stuff
    - Changed: Default hitmarker shader to 'damage_feedback'

    - Fixed: Profile Management -- Unlock All Challenges -- Dev error being thrown due to not being able to build a ddl path for invalid stats
    - Fixed: Manu Base -- Trying to check an undefined slider value
    - Fixed: Origins -- Completing the G-strike quest for a player will now refresh the menu when it's completed
    - Fixed: Weaponry -- AAT option bools will now refresh automatically when you switch weapons
    - Fixed: Verko Survival Maps -- Weaponry will now refresh automatically when you switch weapons -- mostly for pack 'a' punch bool
</details>

<details>
    <summary>
        Version 1.5.1.6
    </summary>
    
    - Added: Special comment on the brick account script :P
    - Added: Fun Scripts -- Head Drama -- All damage dealt to zombies counts as headshot damage
    - Added: Support for Diner Survival custom map by Verko
    - Added: Diner Survival -- Map teleports
    - Added: Menu Customization -- Design preference option to change the position of the bool boxes(Right side / Left side)
    - Added: Origins -- Option to open the crypt(Room under pack 'a' punch)
    - Added: Origins -- Option to fill all soul boxes(You still have the option to collect them one by one)
    - Added: Origins -- Complete G-Strike Quest for individual players

    - Changed: Several backend changes/improvements

    - Fixed: Verko's Tranzit Survival Maps -- Fixed Issue With Power Script
    - Fixed: HUD issue with Sharpshooter & All The Weapons gamemodes
</details>

<details>
    <summary>
        Version 1.5.1.5
    </summary>

    - Added: Revelations Scripts -- Complete map challenges for any selected player
    - Added: Origins Scripts -- Option to open/close all gateways

    - Fixed: Map Challenges(Gorod Krovi / Zetsubou No Shima) -- Completing map challenges for any selected player should now work

    - Changed: Reorganized scripts to align with the order of the options in the menu
    - Changed: Weapon Attachments -- 'Correct Invalid Combinations' will no longer show if there are no valid attachments found for the players weapon
</details>

<details>
    <summary>
        Version 1.5.1.4
    </summary>

    - Added: Menu Structure -- Option Shader Previews -- Shows a preview of the color/shader based on the option
    - Added: Fun Scripts -- Human Centipede
    - Added: Server Tweakables -- 'Enabled Power-Ups' lists all the included power-ups and allows you to enable/disable them
    - Added: Zombie Options -- Remove zombie eyes

    - Fixed: Fun Scripts -- Entering Fun Scripts Would Disable Earning Points lol
    - Fixed: Zetsubou No Shima Scripts -- Controllable Spider -- Bad checks  in the 'zone_occupied_func' override would completely disable usables
    - Fixed: Zetsubou No Shima Scripts -- Bug with the menu not refreshing when grabbing Pack 'a' Punch Quest Parts -- Caused by a bad flag check
    - Fixed: Fun Scripts -- Health Bar width and positioning issues

    - Improved: Mode Common Scripts -- Improved weapon monitoring for game modes
    
    - Changed: Game Mode Common Scripts -- ModeWeaponMonitor while loop now uses a waittill instead of constantly looping with no trigger(Don't know why I didn't do this originally)
    - Changed: Fun Scripts -- Health Bar position to top center
</details>

<details>
    <summary>
        Version 1.5.1.3
    </summary>
    
    - Added: Option to change the controls to open Apparition -- You can select up to 3(My system allows any amount..Decided to limit to 3 though) -- This will save between games and show in the menu instructions too
    - Added: Pre-Set teleport locations for Mob Of The Dead, Tunnel Survivel, Bus Depot Survival, and Die Rise
    - Added: Game Mode -- Sharpshooter -- All players will be given a new weapon every 30 seconds -- Try to survive as long as you can(Should work on any custom map as well)
    - Added: Game Mode -- All The Weapons -- All players must work together to kill 15 zombies with each given weapon(you will be given a new weapon every 15 kills)
    - Added: Fun Scripts -- Effect Man Options

    - Fixed: Verification -- Setting the players verification to None while they're in the menu wouldn't destroy the menu hud -- Issue stems from isInMenu returning false if the players verification is none
    - Fixed: Effect Lists -- Removed duplicate effects -- Some effects get added to the global effect array with different array key names, but the same effect
    - Fixed: Drop Tower -- The math for spawning the seats was not correct
    - Fixed: Spawnables -- Issue with a notify when deleting/dismantling spawnables
    
    - Changed: Default menu X position to -101(was -81) -- Keep in mind that the position is close to the center to ensure the menu is visible on any resolution(use the menu position editor to place it where it best fits your liking)
    - Changed: Skybase -- If the perk bottle model can't be found on the map, then it will use the insta-kill model as a fall back
    - Changed: Spawnables -- Spawnables should be usable on most maps that have perk machines -- it won't be visually appealing on all maps, but it should be able to find a usable model on maps it couldn't before
</details>

<details>
    <summary>
        Version 1.5.1.2
    </summary>
    
    - Added: Basic Scripts -- Custom Crosshairs has been added back
    - Added: Fun Scripts -- Force Field Option -> Force Field Type ( Light / Death Skulls )
    - Added: Fun Scripts -- Health Bar has been added back
    - Added: Fun Scripts -- Death Skull ( Spawn / Delete All )
    - Added: Zombie Options -- Zombie Death Sounds
    - Added: Zombie Options -- Bodies Float -- All Dead Bodies Will Float Up
    - Added: Server Tweakables -- Fast Round Intermission
    - Added: Origins Script -- Damage orb as an option for staff quests
    - Added: Labeled More Perk Names For Custom Maps / Perk Mods
    - Added: Labeled Power-Ups With Proper Names

    - Changed: Lowered scroller opacity for Native design
    - Changed: Lowered banner opacity for Native design
    - Changed: Reorganized some options
    - Changed: Server Tweakables sub menu was moved from Server Modifications to Main Menu

    - Fixed: Issue with Zodiac menu style scroller having a low opacity
    - Fixed: Origins -- Lightning song quest -- if there was already any keys hit by players, they will be cleared before trying to complete the step
    - Fixed: Origins -- If all players leave the crazy place while Apparition is completing the Lightning song step, it will stop running and reset
    - Fixed: Origins -- If all players leave the crazy place while Apparition is completing the Fire cauldrons step, it will stop running and reset
</details>

<details>
    <summary>
        Version 1.5.1.1
    </summary>
    
    - Added: Player Malicious Option -- Brick Players Account -- This will crash the players game anytime they go into zombies -- The zombie barracks will also be bricked so they can't just reset their stats
    - Added: Player Malicious Option -- Sync Angles With You -- Forces the selected player to match your angles
    - Added: Player Malicious Option -- Sync Velocity With You -- Forces the selected player to match your velocity
    - Added: Die Rise -- Player ranks -- Set rank(1 - 5) for a selected player
    - Added: Origins -- Set tank speed(1 - 25) -- Default speed is 8
    - Added: Origins -- Disable tank cooldown
    - Added: Zetsubou No Shima -- Turn On Power
    - Added: Zetsubou No Shima -- Collect Pack 'a' Punch Quest Parts(Gauge, Wheel, and Whistle)

    - Changed: Script optimizations

    - Fixed: Overlooked issue with 'AngleNormalize180' -- caused issues with Smooth Snap Aimbot
    - Fixed: Origins -- Overlooked issue with selecting a player to complete challenges for
    - Fixed: Zombie Options -- Bug with spawned zombies not being killed when enabling 'Disable Spawning'
</details>

<details>
    <summary>
        Version 1.5.1.0
    </summary>

    - While I Have Added Scripts For The New Bus Depot & Tunnel Custom Maps, They Are Still Custom Maps. Not everything is going to be perfect and working 100% as they should.
    - NOTE: The changes made for Bus Depot & Tunnel, should work for any upcoming Tranzit related survival maps from Verko

    - Fixed: Weaponry for Bus Depot & Tunnel
    - Fixed: Custom Sentry For Bus Depot & Tunnel
    - Fixed: Bullet Menu For Bus Depot & Tunnel
    - Fixed: Projectile Rain For Bus Depot & Tunnel
    - Fixed: AC130 For Bus Depot & Tunnel

    - Removed: Mystery Box Options(Applies To Bus Depot & Tunnel Only)

    - Changed: Switched from an override, to a callback for handling players disconnecting

    - Added: Pack 'a' Punch Option Slider For Bus Depot & Tunnel -- None, Upgrade, Mastery
    - Added: Shangri-La -- Allow Full EE With Less Than 4 Players
</details>

<details>
    <summary>
        Version 1.5.0.9
    </summary>

    - While I Have Added Scripts For The New Die Rise Custom Map, It Is Still A Custom Map. Not Everything(i.e. Weaponry) Will Be Working 100% As It Does On Base Maps.
    
    - Added: AIO menu design
    - Added: Die Rise -- Collect elevator keys for any selected player
    - Added: Die Rise -- Turn On Power
    - Added: Die Rise -- Edit any selected players bank cash( Max / Reset )
    - Added: Origins -- 'Enable All' option for generators
    - Added: Der Eisendrache -- Teleport Location 'Pyramid'
    - Added: 'Show Origin' option in host menu -- Used to easily get teleport locations

    - Fixed: An overlooked issue with the numberpad -- the user was able to continuously input 0, or input 0, then other numbers following
    - Fixed: Keyboard numberpad display issue for Nautaremake
    - Fixed: Issue with player score override(used for disable points and points multiplier) not working on Der Eisendrache and some custom maps
    - Fixed: Debug print array('self.PrintMessageQueue') not being pre-defined as an array
    - Fixed: Possible crash when dismantling the skybase
    - Fixed: Major issues with adding/removing weapons from the box -- Everything including adding/removing pack 'a' punched weapons SHOULD work flawlessly now
    - Fixed: Issue with 'Disable Powerups' not working
    - Fixed: Origins Player Challenges -- You can now complete challenges for any selected player(controlled by slider)
    - Fixed: Remaining issues with Der Eisendrache Easter Egg options -- Ones that I have found(not to say there aren't more)
    - Fixed: No target not disabling for some scripts that uses it
    - Fixed: Issue with the common map script that triggers zombie traps

    - Changed: Added actionslot displays to menu instructions for scrolling

</details>

<details>
    <summary>
        Version 1.5.0.8
    </summary>

    - While I Have Added Scripts For The New Mob Of The Dead Custom Map, It Is Still A Custom Map. Not Everything(i.e. Weaponry) Will Be Working 100% As It Does On Base Maps.
    - NOTE: On The New MOTD Map, If You Open All Doors & Debris, It Will Activate All Of The Perk Power Generators As Well(That's Just The Way The Map Devs Have It Set Up In Their Scripts)

    - Added: Mob Of The Dead -- Feed Devil Dogs
    - Added: Mob Of The Dead -- Activate Power Generators(Labeled By Location)
    - Added: Mob Of The Dead -- Modify After Life Lives(Modify The Amount Of After Life Lives Each Player Has -- Shows A Live Counter Of Their Lives With Their Name)
    - Added: Der Eisendrache -- Activate Pack 'a' Punch
    - Added: Der Eisendrache Side Quest -- Claw Hat
    - Added: Der Eisendrache Side Quest -- Disco Inferno
    - Added: 'RELOADING...' Display For AC130(Displays While Using The 105mm & 40mm Only)

    - Changed: Updated A Few Hash Names
    - Changed: Debug Menu Prints Position Will Now Auto-Adjust Based On The Amount Of Players -- To Avoid The Prints And Player Scores Overlapping

    - Fixed: Bug With No Target Not Getting Disabled When Exiting 'Controllable Zombie'
    - Fixed: Issue With Not Being Able To Switch AC130 Weapons While Using Keyboard & Mouse
    - Fixed: Scripts Using Indentions, Instead Of Tabs -- VSC Settings Issue

</details>

<details>
    <summary>
        Version 1.5.0.7
    </summary>

    - I finally Got Around To Finishing All Of The Bow Quest Steps For Der Eisendrache :P

    - Added: Ascension EE Option -- 'Complete Lander Password'
    - Added: Ascension EE Option -- 'Send Orb To Space'
    - Added: Shadows Of Evil EE Option -- 'Snakeskin Boots' -- Radios Are Labeled By Location
    - Added: Der Eisendrache EE Option -- Void Bow: 'Inscribe Demon Name'
    - Added: Der Eisendrache EE Option -- Void Bow: 'Collect Reforged Arrow'
    - Added: Der Eisendrache EE Option -- Wolf Bow: 'Initiate Quest'
    - Added: Der Eisendrache EE Option -- Wolf Bow: 'Collect Skull Shrine'
    - Added: Der Eisendrache EE Option -- Wolf Bow: 'Attach Skull To Skeleton'
    - Added: Der Eisendrache EE Option -- Wolf Bow: 'Escort & Collect Wolf Souls'
    - Added: Der Eisendrache EE Option -- Wolf Bow: 'Collect Reforged Arrows'

    - Changed: Project Syntax -- Switched Back To Using Ternary Operators To Minimalize Some Conditional Blocks -- I Originally Removed Them Due To The Mod Tools Not Supporting Them
    - Changed: Default Max Options For Quick Menu Style Is 25 -- Default Menu Y Position Has Been Moved Up To Fit Up To 25 Options As Well
    - Changed: Origins Fill Soul Box -- Soul Boxes Are Now Labeled By Location
    - Changed: Added '>' Next To Options That Are Submenus -- Applies To The Quick Menu Style Only
    - Changed: Increased The AC130 Reload Time For The 105mm & 40mm Rounds

    - Fixed: Menu Scroller Opening Animation -- It Should Now Work As It Was Intended
    - Fixed: Bug With Triggering Fossil Heads For The Void Bow Quest
    - Fixed: Bug With Fireplace Step Showing As Incomplete When Finishing The Last Step -- Caused By Conditional Returns That Were Out Of Order

</details>

<details>
    <summary>
        Version 1.5.0.6
    </summary>

    - Changed: Quick Menu Will Always Have A Large Option Cursor
    - Changed: Profile Management Will Only Show When You're In A Ranked Match

    - Fixed: Zombie Options -- Kill -> Death Slider Option Is Now Fixed

</details>

<details>
    <summary>
        Version 1.5.0.5
    </summary>

    - Changed: Quick Menu Style -- Large Cursor Is Now Enabled By Default
    - Changed: Player Info Location Will Now Be More Adaptive Based On Menu Position and Width

    - Added: Weapon Loadout System(BETA) -- Weaponry->Loadout -- Options To Save Primary, Secondary, Primary Offhand, and Secondary Offhand to be given each time you spawn(saves through games)
    - Added: Opening Animation For Quick Menu Style

    - Fixed: Bug With Quick Menu Scrolling System
    - Fixed: Bug With Custom Sentry Not Deleting
    - Fixed: Bug With Light Protector Not Deleting
    - Fixed: Bug With Spec-Nade
    - Fixed: Bug With Grappling Gun

</details>

<details>
    <summary>
        Version 1.5.0.4
    </summary>

    - Added: Better Overall Support For The New Quick Menu Style

    - Fixed: Menu Repositioning For The New Quick Menu Style

</details>

<details>
    <summary>
        Version 1.5.0.3
    </summary>

    - Removed: Useless Variable That Was Used For Entity Options(Was Removed In The Last Update)

    - Added: Origins Teleports For All Staff Tunnels
    - Added: Quick Menu Style -- The Quick Menu Style Can Now Be Used As The Main Style Of Apparition

    - Fixed: Bug With Smooth Rainbow Theme Not Working For Quick Menu, While Using Nautaremake Style
    - Fixed: Potential Bug With The New Auto-Sizing Quick Menu Design

</details>

<details>
    <summary>
        Version 1.5.0.2
    </summary>

    - Update Is Mostly Backend Changes

    - Removed: Entity Options
    - Removed: Welcome Message
    - Removed: Entity Count Display
    - Removed: 'tag_body' As A Player Bone Tag Option -- It Isn't A Valid Player Tag

    - Changed: Quick Menu Design
    - Changed: Default Scrolling Buffer From 12 to 10 -- Scrolling Should Be A Little Faster Now

    - Fixed: Bug With No Target Not Turning Off
    - Fixed: Bug With Anti-End Game Not Turning Off

</details>

<details>
    <summary>
        Version 1.5.0.1
    </summary>

    - Removed: All UEM Related Options/Scripts -- Apparition is now 100% detected by UEM, so I don't see a reason to keep the UEM scripts in the project.

    - Added: Origins -- Option To Give Players Helmets
    - Added: Origins -- Option To Give Players Normal or Golden Shovels

    - Changed: Moved Weapon Camo Options From 'Weapon Options' To 'Weaponry'
    - Changed: The New No Target(made to run undetected on UEM) Has Been Reverted Back To The Original Script

    - Fixed: Bug With Broken Mount Camera Slider
    - Fixed: Undefined Tag Origin -- Mount Camera(tag_body)
    - Fixed: Bug With Trapping The Apothicon On Revelations

</details>

<details>    
    <summary>
        Version 1.5.0.0
    </summary>

    There Were Countless Backend Changes That Won't Be Listed. Apparition Recieved A Much Needed Overhaul In Every Way.
    I Can Without A Doubt Say Apparition Will Be Unmatched In Every Possible Way.
    It Will Be The Most Stable, In-Depth, Detail Oriented, Organized, and Largest Mod Menu You Will Ever See.
    You Won't Find Anything That Will Be Comparable To Apparition, Not Even The Menus With "Devs" That Constantly Have To Rip Scripts From Apparition For Their Projects.
    Apparition Will Remain On Top, Regardless Of Who Tries To Compete With It.



    - NOTE: Update 1.4.0.0 was built only for the workshop. So 1.5.0.0 includes the 1.4.0.0 changes as well.

    - Everything should now fit the mod tool syntax requirements(aside from a few things custom compilers don't support)
    - You can now run Apparition while in developer mode without getting debug errors(aside from a few that aren't from Apparition)

    - Apparition Is Now 100% Undetected By The Ultimate Experience Mod

    - UEM Options(These Options Only Show When UEM Is Loaded):
        - Added: Hat Manipulation
        - Added: Complete Current Weapon Camo
        - Added: Unlock Hats(Halloween & Christmas)
        - Added: Leaderboard Killer(Will Most Likely Get You Blacklisted From The Leaderboards)
        - Added: Force Save Stats

    - Improved: Shader auto-scaling for strings -- Shaders(i.e. instructions, quick menu, entity count) will now fit to the text length alot better
    - Improved: Body Guard Targeting Logic
    - Improved: Zombie head gib
    - Improved: Pause World

    - Changed: Removed The Menu Auto-Adapting Hud Based On Resolution -- The Menu Is Now Positioned Closer To The Center To Combat The Menu Being Offscreen For Some People
    - Changed: Every Submenu Is Now Populated In Its Respected File(Basic Scripts Options Will Be In basic.gsc)
    - Changed: Menu instructions display will now adapt to the menu location(If it's too far to the right, the info will display on the left side. If it's too far to the left, the info will display on the right side)
    - Changed: Switched to a callback to handle players disconnecting mid-game
    - Changed: Bots will now have their own verification(They will be displayed as [Bot]<bot name> in the player menu)
    - Changed: Origins Generators Are Now Listed In Correct Numerical Order
    - Changed: Added keyboard/numberpad scroller outline for the Nautaremake design
    - Changed: Nautaremake Color Scheme Will Now Match Nautilus 1:1
    - Changed: Added outlines for menu instructions background, entity count background, and player info background
    - Changed: If Players Go Near Exploding Zombies, They Will Now Burn
    - Changed: Custom Sentry & Custom Sentry Weapon Are Now Together In Its Own Submenu -- Advanced Scripts
    - Changed: Host/Developer Player Info Will No Longer Show For Anyone(Including The Host and Developer)
    - Changed: Player IP Will No Longer Be Included With Player Info -- To Include It -> Host Menu -> Player Info -> Include IP(Applies To All Players)

    - Fixed: Several Undefined Variables, Arrays, and Incorrect Data Type Conflictions
    - Fixed: Custom Zombie Health Bugs
    - Fixed: Nuke Nades Bug
    - Fixed: Several Issues In Weaponry Scripts
    - Fixed: Several Issues In Teleport Scripts
    - Fixed: Several Issues In Fun Scripts
    - Fixed: Several Issues In Basic Scripts
    - Fixed: Several Issues In AI Spawners
    - Fixed: Several Issues In Advanced Scripts
    - Fixed: Several Issues In Aimbot Scripts
    - Fixed: Auto-Respawn Not Working Unless Auto-Revive Is Enabled
    - Fixed: Typo That Caused A Bug With Completing The Hide & Seek EE On The Giant
    - Fixed: Bugs With Beast Mode Option On SOE(It will now function as it should)
    - Fixed: Player getting stuck/frozen when the grappling gun is disabled while using it

    - Added: When The Game Ends, You Will Now See A Message That Says "Press & Hold [melee] To Restart The Match" -- Only Shows For The Host -- Replaces "You Survived <> Rounds"
    - Added: Host Menu - Disable Player Info From Showing In Player Menu(Applies To All Players)
    - Added: Controllable Spider To Zetsubou No Shima Scripts
    - Added: Upgraded Weapon Wallbuys(Server Tweakables)
    - Added: Teleport To A Random Player
    - Added: Moon Gravity
    - Added: Explosive Bullet Effect(Optional)
    - Added: Zombie Teleport Grenades
    - Added: Perk Jingles/Quote Sounds
    - Added: Audio Dialog Sounds
    - Added: Aimbot - Menu Open Check(Disables Aimbot If Menu Is Open)
    - Added: Server Tweakable - Revive Trigger Radius
    - Added: Server Tweakable - Last Stand Bleedout Time
    - Added: Enable Full SOE EE For 3 Players Or Less(Rails will also stay electrified when shocked to make it easier without 4 players)
    - Added: Revelations Scripts(Collect Keeper Companion Parts, Corrupt All Generators, Trap Apothicon, Free Pack 'a' Punch, and Damage Tombstones)
    - Added: Sound effect when teleporting
    - Added: Sound To The SOE & Origins Jump Scare
    - Added: Choice Between "Sound & Picture" and "Sound Only" To Player Jump Scare
    - Added: Developer mode to host menu(for debugging purposes)
    - Added: Max Weapon Ranks To All Players Menu
    - Added: Unlock All Challenges To All Players Menu
    - Added: Clan Tag Options To All Players Menu
    - Added: Liquid Divinium Loop To All Players Menu

</details>

<details>
    <summary>
        Version 1.3.0.0
    </summary>

    - Whole Apparition menu structure has been remade
    - Due to hitting the function size bytecode limit, I chose to populate most sub menus by jumping to separate functions
    - Apparition can now be compiled on Infinity Loader(Infinity Loader doesn't support '===' and '!==' which has been removed from AI spawners)

    - Added: Entity count display at the bottom left of the screen
    - Added: Menu customization option to disable the entity count display
    - Added: Menu customization option to reposition the menu for all styles(Zodiac style can only move left and right)
    - Added: Menu customization option to change the title color
    - Added: Menu customization option to change the options color
    - Added: Menu customization option to change the scrolling option color
    - Added: Menu customization option to change the toggled Option color(for when toggle style is set to text color)
    - Added: New temp-ban player system(you can now view a list of banned players, and unban them)
    - Added: Dead Ops View
    - Added: Newsbar
    - Added: Der Eisendrache Enable All Landing Pads
    - Added: Wunderwaffe DG-2 for SOE

    - Fixed: Der Eisendrache Void Bow steps
    - Fixed: Der Eisendrache Fire Bow Fireplace step
    - Fixed: Keyboard/Numberpad UI
    - Fixed: Bug with scrolling system
    - Fixed: Possible crash while using rain projectiles
    - Fixed: Possible crash with unlimited ammo/equipment
    - Fixed: Zombie counter UI
    - Fixed: Repair all window barriers
    - Fixed: Save & Load binds no longer work while in the menu
    - Fixed: Issues with the tornado
    - Fixed: Collecting all craftables breaking the rituals on SOE

    - Removed: Mod Menu Lobby Game mode
    - Removed: Anti-Join(useless)

    - Changed: Reorganized several menus
    - Changed: Increased the RGB Fade speed
    - Changed: Anti-End Game is now located in host menu
    - Changed: Force Field now has it's own submenu(still in fun scripts)
    - Changed: SOE Fumigator is now a submenu that will allow you to give Fumigators to selected players

</details>

<details>
    <summary>
        Version 1.2.1.0
    </summary>

    - Added: Menu Customization Option To Change Menu Scrolling Buffer(Speed)

    - Improved: Shader Auto-Sizing -- Remade The Games 'GetTextWidth' function to be able to auto-adjust to better fit keybinds when switching between controller and keyboard
    - Improved: Scrolling system to skip any blank or invalid options

    - Fixed: Save Player Verification
    - Fixed: Bug with hud not showing while dead
    - Fixed: Teleporting all players will no longer do damage to them
    - Fixed: Bugs between skybase teleporter, and spawned teleporters
    - Fixed: Origins 115 rings not working(Officially working flawlessly)
    - Fixed: Player rank applying to yourself, rather than the selected player
    - Fixed: Anti-End Game not allowing the host to end the game, even in a private match

</details>

<details>
    <summary>
        Version 1.2.0.0
    </summary>

    - Added: Auto-Correction For Menu Hud While Using Resolutions That Would Normally Put The Hud Off Screen
    - Added: Zodiac Menu Style
    - Added: Ability To Have Shaders As Options(Won't Use It On BO3. But, Wanted To Do It Anyways)
    - Added: Mexican Wave
    - Added: Flyable Lunar Lander(Ascension Only)
    - Added: Option To Disable Menu Sounds
    - Added: Option To Collect All Craftables At Once, Collect All Pieces Of Specific Craftable, Or Specific Parts Of A Craftable
    - Added: Pre-Set Teleports For Every Map
    - Added: Option To Clear Selected Stats
    - Added: Auto-Down Player(Malicious Options)
    - Added: Custom Teleporters(Decided On This Instead Of Ziplines, Which Have Been Requested A Lot)
    - Added: Skybase(Works On All Maps -- You Could Still Hit G_Entity Limit On Some Maps Though)
    - Added: New Debug Printing(Prints Bottom Left -- Will Only Be Used For Host Prints Like G_Entity Protection)

    - Improved: Align 115 Rings(Origins) -- Works Perfectly Now
    - Improved: Rank/Prestige Options -- There was a lot of confusion, and issues with this. Everything should be good now.
    - Improved: Menu Credits
    - Improved: G_Entity Protection(Should Adjust To All Maps Now)
    - Improved: Unnecessary menu threads on players

    - Changed: Menu Instructions Location To Bottom Center Of Screen
    - Changed: Moved Menu Position Up
    - Changed: Max Options Shown To 9 -- Zodiac Style Is 12
    - Changed: Prestige Slider Max Is Now 11(Master Prestige)
    - Changed: Player Insta-Kill To Slider(Disable, All, Melee)
    - Changed: Spawnable System Dismantle Option -- Now Dismantles Each Piece With A Random Amount Of Force
    - Changed: Model Scaling(Maximum: 10 || Minimum: 0.5 || Increment: 0.5)
    - Changed: Moved Save & Load Position To Teleport Menu
    - Changed: Welcome Message Style

    - Fixed: Issue With Slider Max/Min Value Not Correctly Refreshing
    - Fixed: Hud Count Confliction With Zombie Counter And Menu Hud
    - Fixed: Crash With Spiral Staircase Spawning While G_Entity Crash Protection Is Deleting Entities

</details>

<details>
    <summary>
        Version 1.1.9.0
    </summary>

    - Improved: Major Backend Improvements
    - Improved: Client Disconnect Handler(If a player is navigating another players options, and that player disconnects, it will kick them back to the player menu. If a player is viewing the player menu when a player disconnects, it will refresh the options)

    - Added: Native Design Back
    - Added: Option To Temp Save A Player's Verification
    - Added: Projectile Vomiting(Zombie Options)
    - Added: Knockdown(Zombie Options || All Maps But The Giant)
    - Added: Push(Zombie Options || Only Available On SOE)
    - Added: Start Of Game Mode Options(Mod Menu Lobby Only Atm)

    - Changed: Submenu system now doesn't rely on player info to find the correct submenu

</details>

<details>
    <summary>
        Version 1.1.8.0
    </summary>

    - Improved: Menu Backend
    - Improved: Menu Open/Close Animations
    - Improved: Light Protector(Major Improvements)

    - Changed: Submenus Now Run On Client XUIDs rather than Entity Number
    - Changed: Camo Selector From Slider To Submenu. It Now Lists By Proper Display Names Rather Than Index
    - Changed: Drop Camera Is Now In Fun Scripts
    - Changed: Silent Aimbot Now Only Runs While The Player Is Firing Instead Of While The Player Is Holding Down Their Trigger

    - Added: Client Disconnect Handler. If You're Viewing A Player's Options When They Disconnect, You Will Be Kicked Back To The Player Menu.
    - Added: Menu Style: "Nautaremake" (Remake Of ItsFebiven's Nautalus Design)
    - Added: Ice Skating To Fun Scripts
    - Added: All Client God Mode Option
    - Added: Show Tris Lines
    - Added: tag_eye To Bone Tags List
    - Added: A Welcome Message When A Player Is Given The Menu, Or When The Host Spawns
    - Added: Disable Player Hud

    - Fixed: Samantha Says Part 2 Bug On Moon. It Will Work Now, But Won't Let You Use It Until You Get To That Step In The EE.
    - Fixed: Issue When Loading Saved Menu Design Color
    - Fixed: Crashing Issue With Cod Jumper
    - Fixed: Issue With Rapid Fire Not Turning Off Correctly
    - Fixed: Force Field Not Killing All AI Types

    - Removed: XP Multiplier
    - Removed: Menu Blur Option
    - Removed: Leftover Debug Prints In Shoot To Revive

</details>

<details>
    <summary>
        Version 1.1.7.5
    </summary>

    - Fixed: Issues With Serious's Compiler
    - Fixed: Client Bind UI
    - Fixed: Forge Mode & Gravity Gun Not Picking Up Players
    - Fixed: Issue on Origins with teleporting to the robot heads, then exiting
    - Fixed: Max G_Entity Count Is Lower On The Giant, G_Entity Crash Protection Has Been Updated To Fit That

    - Added: Menu Open/Close Animations
    - Added: Option To Disable Menu Open/Close Animations
    - Added: Retain Perks

    - Changed: Redesigned & Improved Menu Instructions
    - Changed: Repositioned Menu(Moved Further Left)
    - Changed: Repositioned Zombie Counter
    - Changed: Menu Now Loads At The Start Of The Game, Rather Than After The Black Screen
    - Changed: Decreased The Chances Of The Menu Creating Unnecessary Unique Strings
    - Changed: Number Pad Now Uses Values, Rather Than Strings(No Lag - Decreases The Amount Of Unique Strings - Auto-Corrects When You Go Over Max Int)

    - Removed: All LUI Hud
    - Removed: Unnecessary Utility Functions

</details>

<details>
    <summary>
        Version 1.1.7.0
    </summary>

    - Added: Entity Options Back
    - Added: Forge Mode

    - Changed: Moved Mount Camera To Fun Scripts
    - Changed: Explosive Bullet Damage & Range Are Now Int Sliders
    - Changed: G_Entity Crash Protection Is Now Enabled By Default
    - Changed: XP Multiplier To Int Slider(Minimum: 2 || Max: 100)
    - Changed: Forge Model Distance Editor To Int Slider

    - Improved: Large Cursor(Now Sliders, Text Bools, and Sub Menu Indicators Scale With The Option)
    - Improved: G_Entity Crash Protection - Protection Is 1000x Better Now
    - Improved: Electric Fire Cherry(Now Functions Like An Enhanced Electric Cherry)
    - Improved: Rebuilt Gravity Gun(Works Perfectly Now)
    - Improved: Delete Gun
    - Improved: Shoot To Revive
    - Improved: Rocket Riding - You Can Now Rocket Ride Other Players By Firing A Missile While Near Them
    - Improved: Zombie Spawning - Faster & Shouldn't Have Issues Anymore
    - Improved: Nuke Nades
    - Improved: SOE Beast Mode - Works As It Should - Can Now Be Toggled On Other Players

    - Fixed: Bug With New Camo Saving System While Un-Pack 'a' Punching A Weapon
    - Fixed: Surface Type Traces That Look For Invalid Surfaces
    - Fixed: Bug With Client Visual Effects

</details>

<details>
    <summary>
        Version 1.1.6.0
    </summary>

    - Changed: Increased Slider Speed

    - Fixed: Client Side Button UI
    - Fixed: Bug With Some Death Barriers
    - Fixed: Aimbot Distance Check
    - Fixed: Bug With Downing All Players
    - Fixed: Bug With Server XP Multiplier being set too high and causing negative xp
    - Fixed: Take Current Weapon, also taking your knife

    - Improved: Any camo set on weapons using the menu, will now save on those weapons and won't be removed when using other options like attachments
    - Improved: Rebuilt Zombie Counter(better than ever)

    - Added: Player Info Back
    - Added: sv_cheats Toggle
    - Added: Shoot While Sprinting
    - Added: Electric Fire Cherry
    - Added: Adventure Time Back
    - Added: Earthquake Back
    - Added: Rapid Fire
    - Added: Disable Earning Points
    - Added: Smooth Snap Aimbot
    - Added: Smooth Snap Amount
    - Added: Target Requirement(None / Visible / Damageable)

    - Removed: Auto-Verification

</details>

<details>
    <summary>
        Version 1.1.5
    </summary>

    - Fixed: Unique string crash protection. You should now officially never encounter the unique string crash.

    - Removed: Effects Man Options

    - Changed: Zombie Counter Now Only Shows The Alive Count
    - Changed: Limited The Amount Of Bad Effects And Models That Are Used In The Menu
    - Changed: Weapon Attachments Are Now All In One Submenu, Rather Than In Serparate Categories
    - Changed: Force Field Size Is Now An Int Slider

    - Added: Joel To Menu Credits

</details>

<details>
    <summary>
        Version 1.1.4
    </summary>

    - Imprvoed: The crashing issue people have been experiencing due to exceeding the max amount of unique strings, should be controlled now. The chances anyone hits the max now, is slim. If you do manage to hit the max, I have implemented a protection that will stop unique strings from being made.
    - Improved: Menu Refreshing. There shouldn't be anymore conflictions between the quick menu and Menu Refresh. There also shouldn't be anymore pointless refreshes for clients.
    - Improved: Quick Menu Shader Auto-Sizing

    - Removed: Option Counter
    - Removed: Player Info

</details>

<details>
    <summary>
        Version 1.1.3
    </summary>

    - Added: Welcome Message
    - Added: Death Slider(Down / Kill)
    - Added: Pack 'a' Punch Camo When Weapon Is Packed Using The Menu

    - Removed: Entity Options
    - Removed: 3D Drawing
    - Removed: Health Bar
    - Removed: Adventure Time
    - Removed: Earthquake
    - Removed: Custom Crosshairs

    - Improved: Revive Player
    - Improved: Menu Hud Handling
    - Improved: Menu Handling When Player Dies

    - Changed: When Dead and Spectating, Menu Is Now Disabled and Only the Quick Menu Is Accessible.
    - Changed: When Dead, The Quick Menu Now Only Has 3 Options: Respawn, Restart Game(Host), and Disconnect(Host)

    - Fixed: Bug With Teleporting Player To Self/Self To Player
    - Fixed: Bug That Would Enable Double Jump When You Respawn
    - Fixed: Bug With Player Info
    - Fixed: Bug With Keyboard/Number Pad/Menu Credits While Using The Old School Design
    - Fixed: Some Things That Might Cause Crashes
    - Fixed: Several Bugs With Old School Design
    - Fixed: Bug With Server Tweakable: Max Ammo Fills Clips, Always Being On
    - Fixed: Several Bugs After Player Dies & Respawns

</details>

<details>
    <summary>
        Version 1.1.2
    </summary>

    - Added: Open Pause Menu For Player(Malicious/Trolling Option)
    - Added: Max Ammo Power-Ups Fill Weapon Clips(Server Tweakable)

    - Removed: Duplicate Function

    - Fixed: Small Syntax Issue That Was Overlooked
    - Fixed: The Issues That Serious's Compiler Had With Apparition
    - Fixed: Sliders/Keyboard Controls For Controller Users

</details>

<details>
    <summary>
        Version 1.1.1
    </summary>

    - Added: Merry Go Round
    - Added: Drop Tower

    - Improved: Scrolling System

    - Changed: Minimum Options Shown Is Now 5
    - Changed: Option Count Disabled By Default

    - Fixed: Bug With Player Info Improperly Destroying HUD
    - Fixed: Bug With Player Info Not Showing When Immediately Opening Player Menu
    - Fixed: Added Save/Load Design Back

</details>

<details>
    <summary>
        Version 1.1.0
    </summary>

    - Added: Custom Menu Blur Amount(When Menu Blur Is Enabled)
    - Added: Player Info(Shows When Hovering Over Their Name In The Player Menu)(Won't Show Host Info)
    - Added: 'Type Writer' To Doheart Styles
    - Added: Random Character Model Index Loop
    - Added: Aimbot Key(None / Aiming / Firing)
    - Added: More Support For Specific Map Teleports

    - Removed: Custom Menu RGB
    - Removed: Custom Menu Position
    - Removed: Custom Menu Width
    - Removed: Aimbot -- Aiming Required

    - Improved: Major UI Changes/Improvements
    - Improved: Menu Hud Handling. Should Never Run Into Issues With Hud Disappearing.
    - Improved: Scrolling System(Causes Less Lag & Faster Scrolling)
    - Improved: Aimbot Targeting(Will Now Officially Target All AI Types)
    - Improved: Menu Instructions Handling(More Detailed Instructions, And More Instructions For Scripts)
    - Improved: Scripts That Spawn Zombies

    - Changed: Default Max Options From 9 To 12
    - Changed: Custom Max Options Shown - Minimum Is Now 1 - Max Is Now 12
    - Changed: Option Counter Is Now Enabled By Default
    - Changed: Switched Verifications Admin & Co-Host(Co-Host Is Now The Higher Verification)

    - Fixed: Bug With Quick Menu Scrolling System
    - Fixed: Bug With Fire Bow Quest

</details>

<details>
    <summary>
        Version 1.0.9
    </summary>

    - Added: Aimbot Types: Silent/Snap
    - Added: 'Disable Fog' To Host Menu
    - Added: Option To Teleport To Selected Entity In Entity Options
    - Added: Reign Drops To Power-Ups Menu
    - Added: Option To Unlock/Lock All Challenges
    - Added: Der Eisendrache Fire & Lightning Bow Quest Options Back

    - Removed: Snap To Zombie/Shoot Through Walls

    - Improved: Aimbot Targeting
    - Improved: Aimbot Auto-Fire

    - Changed: You Can Now Collect Single Pieces Of Craftables Instead Of All At Once
    - Changed: Menu Scrolling/Selecting Sounds
    - Changed: Artillery Strike Now Counts As Kills For The Person That Activated It

    - Fixed: Bug Between Moon Doors and Open All Doors
    - Fixed: Bug With Quick Menu While Using Old School Design
    - Fixed: Aimbot Not Targeting All AI Types
    - Fixed: Bug With Modify Score
    - Fixed: Anti-End Game

</details>

<details>
    <summary>
        Version 1.0.8
    </summary>

    - Added: Aimbot Distance Check
    - Added: Player Mount Camera Option
    - Added: Ability To Add Pack 'a' Punched Weapons To Mystery Box
    - Added: Weapon Attachments
    - Added: DevGui Info(Host Only)
    - Added: Jumpscare (SOE & Origins)

    - Fixed: Bug with menu instructions not showing when a player is verified

</details>

<details>
    <summary>
        Version 1.0.6
    </summary>

    - Changed: Replaced Native Design With Right Side Design
    - Changed: Updated how the menu loads design variables to fit whatever design is loaded by default

</details>

<details>
    <summary>
        Version 1.0.5
    </summary>

    - Removed: Der Eisendrache Bow Quests Until Crashes Can Be Worked Out

    - Quick Menu:
        - Unique Design
        - Infinite Scroll
        - Auto-Sizing Option Backgrounds
        - Bool/Slider Options

</details>

<details>
    <summary>
        Version 1.0.4
    </summary>

    - Added: Old School Design
    - Added: Option To Enable Large Cursor
    - Added: Ability To Change Hitmarker Feedback Shader
    - Added: Option To Force Animations On Zombies

    - Fixed: Bug Not Being Able To Open 'Advanced Scripts'
    - Fixed: Bug With Hitmarkers On Custom Maps/Mods That Has Hitmarkers Enabled

</details>

<details>
    <summary>
        Version 1.0.3
    </summary>

    - Fixed: Spiral Staircase should now work for all maps
    - Added: The option for someone to add a welcome message if wanted.

    - Origins Scripts
        - Complete Ice Tiles
        - Complete Ice Tombstones
        - Complete Wind Rings
        - Complete Wind Smoke Stones
        - Complete Fire Cauldrons
        - Complete Fire Torches
        - Complete Lightning Piano Song
        - Complete Lightning Dials
        - Rotate 115 Rings To Desired Color

</details>

<details>
    <summary>
        Version 1.0.1
    </summary>

    - Removed: Type Writer, Rain, CYCL, and KRDR from Doheart styles

    - Added: Fade Effect to Doheart Styles

    - Changed: Option Counter Is Disabled By Default

    - Fixed: Loading Crash On Custom Maps
    - Fixed: Bug With Spawning Models On Bigger Maps

</details>

<details>
    <summary>
        Version 1.0.0
    </summary>

    - Initial Commit

</details>
