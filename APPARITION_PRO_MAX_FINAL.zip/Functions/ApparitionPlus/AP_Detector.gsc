/*
    APPARITION PRO MAX - Phase 2
    Event detector. Uses verified Apparition state/events where available and
    limited polling only for player lifecycle state that has no direct hook
    in this source tree.
*/

AP_Detector_Init()
{
    if(Is_True(self.AP_DetectorRunning))
        return;

    self.AP_DetectorRunning = true;
    self.AP_DetectorLastRound = IsDefined(level.round_number) ? level.round_number : 1;
    self.AP_DetectorLastWeapon = undefined;
    self.AP_DetectorWasDown = false;
    self.AP_DetectorWasAlive = IsAlive(self);
    self.AP_DetectorLastPerks = [];
    self thread AP_Detector_Loop();
}

AP_Detector_Loop()
{
    self endon("disconnect");

    while(1)
    {
        currentRound = IsDefined(level.round_number) ? level.round_number : self.AP_DetectorLastRound;

        if(currentRound != self.AP_DetectorLastRound)
        {
            previous = self.AP_DetectorLastRound;
            self.AP_DetectorLastRound = currentRound;
            self AP_Stats_UpdateRound(currentRound);
            snapshot = self AP_Stats_RoundSnapshot();
            self AP_Challenge_OnRound();
            self AP_EmitEvent("ap_round_change", Array(previous, currentRound), 75);
            self thread AP_RoundSummary_Show(snapshot);
            self AP_Stats_ResetRoundCounters();

            if(!IsDefined(self.AP_Challenge["current"]))
                self AP_Challenge_Generate();
        }

        alive = IsAlive(self);
        down = self isDown();

        if(down && !self.AP_DetectorWasDown)
        {
            self AP_Stats_OnDown();

            if(IsDefined(self.AP_Challenge["current"]) && self.AP_Challenge["current"][0] == "round_survive")
                self AP_Challenge_Fail("player_down");
        }

        if(!down && self.AP_DetectorWasDown && alive)
            self AP_Stats_OnRevive();

        if(!down && !alive && self.AP_DetectorWasAlive)
        {
            self AP_Stats_OnDeath();

            if(IsDefined(self.AP_Challenge["current"]))
                self AP_Challenge_Fail("player_death");
        }

        self.AP_DetectorWasDown = down;
        self.AP_DetectorWasAlive = alive;

        if(alive)
        {
            weapon = self GetCurrentWeapon();

            if(IsDefined(weapon) && weapon != self.AP_DetectorLastWeapon)
            {
                self.AP_DetectorLastWeapon = weapon;
                self AP_EmitEvent("ap_weapon_change", weapon, 45);
            }

            self AP_Detector_CheckPerks();
            self AP_Detector_CheckSpecialWeapon(weapon);
        }

        wait 0.15;
    }
}

AP_Detector_CheckPerks()
{
    perks = IsDefined(self.perks_active) ? self.perks_active : [];
    if(!IsArray(perks))
        return;

    if(self.AP_DetectorLastPerks.size != perks.size)
    {
        self.AP_DetectorLastPerks = [];
        foreach(perk in perks)
            self.AP_DetectorLastPerks[self.AP_DetectorLastPerks.size] = perk;

        self AP_EmitEvent("ap_perk_change", perks, 40);
    }
}

AP_Detector_CheckSpecialWeapon(weapon)
{
    if(!IsDefined(weapon) || !IsDefined(weapon.name))
        return;

    name = ToLower(weapon.name);

    if(IsSubStr(name, "ray_gun") || IsSubStr(name, "raygun"))
    {
        if(!Is_True(self.AP_HasReportedRayGun))
        {
            self.AP_HasReportedRayGun = true;
            self AP_EmitEvent("ap_raygun", weapon, 70);
        }
    }

    if(IsSubStr(name, "upgraded"))
    {
        if(!Is_True(self.AP_HasReportedPAP))
        {
            self.AP_HasReportedPAP = true;
            self AP_EmitEvent("ap_pap_weapon", weapon, 65);
        }
    }
    else
    {
        self.AP_HasReportedPAP = false;
    }

    if(!IsSubStr(name, "ray_gun") && !IsSubStr(name, "raygun"))
        self.AP_HasReportedRayGun = false;
}
