/*
    APPARITION PRO MAX - Phase 1
    Shared state ownership and lifecycle foundation.
*/

AP_StateInitPlayer()
{
    self endon("disconnect");

    if(!IsDefined(self.AP_StateInitialized))
    {
        self.AP_StateInitialized = true;

        // Player-owned state.
        self.AP_HUD = [];
        self.AP_HUD_Layers = [];
        self.AP_HUD_Visibility = [];
        self.AP_HUD_ElementAlpha = [];

        self.AP_SideMenuOpen = false;
        self.AP_SideMenuCursor = 0;
        self.AP_SideMenuPrevDisableMenuControls = undefined;

        self.AP_Character = [];
        self.AP_Character["enabled"] = true;
        self.AP_Character["visible"] = true;
        self.AP_Character["queue"] = [];
        self.AP_Character["cooldownUntil"] = 0;
        self.AP_Character["lastDialogue"] = "";
        self.AP_Character["memory"] = [];
        self.AP_Character["mapPersonality"] = ReturnMapName();

        self.AP_Challenge = [];
        self.AP_Challenge["enabled"] = true;
        self.AP_Challenge["current"] = undefined;
        self.AP_Challenge["progress"] = 0;
        self.AP_Challenge["target"] = 0;
        self.AP_Challenge["difficulty"] = "Normal";
        self.AP_Challenge["history"] = [];

        self.AP_EventHistory = [];
    }

    self AP_HUD_Init();
    self AP_Character_Init();
    self AP_Challenge_Init();
}

AP_StateCleanupPlayer()
{
    if(IsDefined(self.AP_SideMenuOpen) && Is_True(self.AP_SideMenuOpen))
        self AP_SideMenu_Close();

    self AP_HUD_DestroyAll();

    if(IsDefined(self.AP_EventHistory))
        self.AP_EventHistory = [];

    if(IsDefined(self.AP_Character))
        self.AP_Character["queue"] = [];

    if(IsDefined(self.AP_Challenge))
        self.AP_Challenge["current"] = undefined;
}

AP_StateResetSpawn()
{
    if(!IsDefined(self.AP_StateInitialized))
        return;

    self.AP_SideMenuOpen = false;
    self.AP_SideMenuCursor = 0;

    if(IsDefined(self.AP_HUD_Layers))
    {
        self AP_HUD_ReapplyVisibility();
    }
}
