/*
    APPARITION PRO MAX - Phase 3
    Final Integration layer.

    This module is the traffic controller for the existing Phase 2 systems.
    It does not replace the systems; it coordinates State -> Events ->
    Director -> Difficulty -> Challenge -> Character -> HUD.

    Character and Director remain rule/state systems, not AI/LLM systems.
*/

AP_Integration_Init()
{
    if(Is_True(self.AP_IntegrationInitialized))
        return;

    self.AP_IntegrationInitialized = true;
    self.AP_IntegrationLastDecision = "";
    self.AP_IntegrationLastDecisionAt = 0;
    self.AP_IntegrationRound = IsDefined(level.round_number) ? level.round_number : 0;
    self.AP_IntegrationLastWeapon = undefined;
    self.AP_IntegrationLastHealth = IsAlive(self) ? self.health : 0;

    self thread AP_Integration_Loop();
}

AP_Integration_Loop()
{
    self endon("disconnect");

    while(1)
    {
        if(IsAlive(self))
        {
            self AP_Integration_SyncState();
        }

        wait 0.5;
    }
}

AP_Integration_SyncState()
{
    round = IsDefined(level.round_number) ? level.round_number : 0;
    zombies = self AP_ZombieCounter_Count();
    health = IsAlive(self) ? self.health : 0;

    self.AP_IntegrationRound = round;
    self.AP_IntegrationZombieCount = zombies;
    self.AP_IntegrationHealth = health;

    if(IsDefined(self.AP_Stats))
        self AP_Stats_UpdateRound(round);
}

AP_Integration_DirectorTick()
{
    if(!Is_True(self.AP_DirectorEnabled))
        return;

    if(IsDefined(self.AP_DirectorLastEvaluationAt) && GetTime() - self.AP_DirectorLastEvaluationAt < 1000)
        return;

    self.AP_DirectorLastEvaluationAt = GetTime();
    action = self AP_Director_Evaluate();

    if(action == "")
        return;

    self AP_Integration_ExecuteDirectorAction(action);
}

AP_Integration_ExecuteDirectorAction(action)
{
    if(!IsDefined(action) || action == "")
        return;

    self.AP_IntegrationLastDecision = action;
    self.AP_IntegrationLastDecisionAt = GetTime();

    switch(action)
    {
        case "emergency":
            self AP_EmitEvent("ap_director_emergency", Array(self.AP_IntegrationZombieCount, self.AP_IntegrationHealth), 100);
            break;

        case "generate_challenge":
            if(Is_True(self.AP_Challenge["enabled"]) && !IsDefined(self.AP_Challenge["current"]))
                self AP_Challenge_Generate();
            break;

        case "raise_difficulty":
            self AP_Challenge_SmartDifficulty();
            if(IsDefined(self.AP_Challenge["current"]))
                self AP_Challenge_ReevaluateCurrent();
            break;

        case "lower_difficulty":
            self AP_Challenge_SmartDifficulty();
            break;

        case "stay_silent":
            // Explicitly records a Director decision without forcing dialogue.
            self AP_Character_AddMemory(Array("director_silence", GetTime(), self.AP_IntegrationZombieCount));
            break;
    }
}

AP_Integration_OnEvent(eventData)
{
    if(!IsDefined(eventData) || eventData.size < 6)
        return;

    player = eventData[5];
    if(!IsDefined(player) || !IsPlayer(player))
        return;

    eventName = eventData[0];
    player AP_Integration_RecordEventContext(eventName, eventData[1]);

    if(eventName == "ap_round_change")
        player AP_Integration_OnRoundEvent(eventData[1]);
    else if(eventName == "ap_player_down")
        player AP_Integration_OnPressureEvent("down");
    else if(eventName == "ap_player_death")
        player AP_Integration_OnPressureEvent("death");
    else if(eventName == "ap_player_revive")
        player AP_Integration_OnPressureEvent("revive");
    else if(eventName == "ap_kill")
        player AP_Integration_OnPressureEvent("kill");
    else if(eventName == "ap_raygun" || eventName == "ap_pap_weapon")
        player AP_Integration_OnWeaponEvent(eventName);
    else if(eventName == "ap_challenge_complete")
        player AP_Integration_OnChallengeEvent("complete");
    else if(eventName == "ap_challenge_failure")
        player AP_Integration_OnChallengeEvent("failure");
}

AP_Integration_RecordEventContext(eventName, payload)
{
    if(!IsDefined(self.AP_Character))
        return;

    // Character memory is the persistent session-level context used by the
    // rule system. The bounded memory policy lives in AP_Character.
    self AP_Character_AddMemory(Array(eventName, payload, GetTime(), self.AP_IntegrationRound));
}

AP_Integration_OnRoundEvent(round)
{
    if(!IsDefined(round))
        return;

    self AP_Challenge_SmartDifficulty();

    if(Is_True(self.AP_Challenge["enabled"]) && !IsDefined(self.AP_Challenge["current"]))
        self AP_Challenge_Generate();

    self AP_Character_SetMapPersonality(ReturnMapName());
}

AP_Integration_OnPressureEvent(kind)
{
    zombies = self AP_ZombieCounter_Count();
    health = IsAlive(self) ? self.health : 0;

    self.AP_IntegrationZombieCount = zombies;
    self.AP_IntegrationHealth = health;

    if(kind == "down" || kind == "death")
    {
        if(Is_True(self.AP_DirectorEnabled))
            self.AP_EmitEvent("ap_director_emergency", Array(zombies, health, kind), 100);
    }
}

AP_Integration_OnWeaponEvent(eventName)
{
    if(eventName == "ap_raygun" || eventName == "ap_pap_weapon")
        self AP_Challenge_SmartDifficulty();
}

AP_Integration_OnChallengeEvent(kind)
{
    if(kind == "complete")
    {
        self AP_Challenge_SmartDifficulty();
        self AP_Challenge_Generate();
    }
    else if(kind == "failure")
    {
        self AP_Challenge_SmartDifficulty();
    }
}

AP_Integration_FinalizeSession()
{
    if(IsDefined(self.AP_Stats))
        self AP_Stats_SaveSessionRecord();

    self AP_Character_AddMemory(Array("session_end", GetTime(), self.AP_Stats["kills"], self.AP_Stats["downs"]));
}
