/*
    APPARITION PRO MAX - Phase 1
    HUD manager.

    Existing Apparition HUD helpers are reused rather than replaced.
    Features register elements into named layers; visibility only changes
    presentation and does not disable feature state.
*/

AP_HUD_Init()
{
    if(!IsDefined(self.AP_HUD))
        self.AP_HUD = [];

    if(!IsDefined(self.AP_HUD_Layers))
        self.AP_HUD_Layers = [];

    if(!IsDefined(self.AP_HUD_Visibility))
        self.AP_HUD_Visibility = [];

    if(!IsDefined(self.AP_HUD_ElementAlpha))
        self.AP_HUD_ElementAlpha = [];

    foreach(layerName in level.AP_Config["SideMenuItems"])
    {
        if(!IsDefined(self.AP_HUD_Visibility[layerName]))
            self.AP_HUD_Visibility[layerName] = true;

        if(!IsDefined(self.AP_HUD_Layers[layerName]))
            self.AP_HUD_Layers[layerName] = [];
    }

    foreach(layerName in Array("Character", "TopRight", "Challenge", "Notification", "RoundSummary"))
    {
        if(!IsDefined(self.AP_HUD_Visibility[layerName]))
            self.AP_HUD_Visibility[layerName] = true;

        if(!IsDefined(self.AP_HUD_Layers[layerName]))
            self.AP_HUD_Layers[layerName] = [];
    }
}

AP_HUD_RegisterElement(layerName, element)
{
    if(!IsDefined(element))
        return;

    if(!IsDefined(self.AP_HUD_Layers))
        self.AP_HUD_Layers = [];

    if(!IsDefined(self.AP_HUD_Layers[layerName]))
        self.AP_HUD_Layers[layerName] = [];

    self.AP_HUD_Layers[layerName][self.AP_HUD_Layers[layerName].size] = element;

    if(!IsDefined(element.AP_OriginalAlpha))
        element.AP_OriginalAlpha = IsDefined(element.alpha) ? element.alpha : 1;

    self AP_HUD_ApplyElementVisibility(layerName, element);
}

AP_HUD_ApplyElementVisibility(layerName, element)
{
    if(!IsDefined(element))
        return;

    visible = !IsDefined(self.AP_HUD_Visibility[layerName]) || Is_True(self.AP_HUD_Visibility[layerName]);

    if(visible)
        element.alpha = IsDefined(element.AP_OriginalAlpha) ? element.AP_OriginalAlpha : 1;
    else
        element.alpha = 0;
}

AP_HUD_SetVisibility(layerName, visible)
{
    if(!IsDefined(self.AP_HUD_Visibility))
        self.AP_HUD_Visibility = [];

    self.AP_HUD_Visibility[layerName] = Is_True(visible);

    if(!IsDefined(self.AP_HUD_Layers) || !IsDefined(self.AP_HUD_Layers[layerName]))
        return;

    foreach(element in self.AP_HUD_Layers[layerName])
    {
        if(IsDefined(element))
            self AP_HUD_ApplyElementVisibility(layerName, element);
    }
}

AP_HUD_IsVisible(layerName)
{
    if(!IsDefined(self.AP_HUD_Visibility[layerName]))
        return true;

    return Is_True(self.AP_HUD_Visibility[layerName]);
}

AP_HUD_ShowLayer(layerName)
{
    self AP_HUD_SetVisibility(layerName, true);
}

AP_HUD_HideLayer(layerName)
{
    self AP_HUD_SetVisibility(layerName, false);
}

AP_HUD_CreateText(layerName, font, fontSize, sort, text, align, x, y, alpha, color)
{
    element = self createText(font, fontSize, sort, text, align, x, y, alpha, color);
    self AP_HUD_RegisterElement(layerName, element);
    return element;
}

AP_HUD_CreateRectangle(layerName, align, x, y, width, height, color, sort, alpha, shader)
{
    element = self createRectangle(align, x, y, width, height, color, sort, alpha, shader);
    self AP_HUD_RegisterElement(layerName, element);
    return element;
}

AP_HUD_DestroyLayer(layerName)
{
    if(!IsDefined(self.AP_HUD_Layers) || !IsDefined(self.AP_HUD_Layers[layerName]))
        return;

    foreach(element in self.AP_HUD_Layers[layerName])
    {
        if(IsDefined(element))
            element DestroyHud();
    }

    self.AP_HUD_Layers[layerName] = [];
}

AP_HUD_DestroyAll()
{
    if(!IsDefined(self.AP_HUD_Layers))
        return;

    keys = GetArrayKeys(self.AP_HUD_Layers);

    foreach(layerName in keys)
        self AP_HUD_DestroyLayer(layerName);

    self.AP_HUD_Layers = [];
    self.AP_HUD = [];
}

AP_HUD_ReapplyVisibility()
{
    if(!IsDefined(self.AP_HUD_Layers))
        return;

    foreach(layerName in GetArrayKeys(self.AP_HUD_Layers))
    {
        if(!IsDefined(self.AP_HUD_Layers[layerName]))
            continue;

        foreach(element in self.AP_HUD_Layers[layerName])
        {
            if(IsDefined(element))
                self AP_HUD_ApplyElementVisibility(layerName, element);
        }
    }
}

AP_HUD_SetAllFeatureVisibility(visible)
{
    layers = Array(
        "ZombieCounter",
        "TimeCounter",
        "Character",
        "Challenge",
        "ZombieIntel",
        "Loadout",
        "KillStreak",
        "Clutch",
        "SessionStats",
        "PersonalRecords",
        "ChallengeStreak",
        "ChallengeDifficulty",
        "RoundSummary"
    );

    foreach(layerName in layers)
        self AP_HUD_SetVisibility(layerName, visible);
}
