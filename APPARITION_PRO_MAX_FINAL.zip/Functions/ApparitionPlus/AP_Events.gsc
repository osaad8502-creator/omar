/*
    APPARITION PRO MAX - Phase 1
    Event framework.

    This is an event abstraction only. Gameplay detection belongs to Phase 2/3.
*/

AP_EventsInit()
{
    if(Is_True(level.AP_EventsInitialized))
        return;

    level.AP_EventsInitialized = true;
    level.AP_EventHistory = [];
    level.AP_EventSubscribers = [];
    level.AP_EventSequence = 0;
}

AP_RegisterEventSubscriber(eventName, callback)
{
    if(!IsDefined(eventName) || !IsDefined(callback))
        return;

    if(!IsDefined(level.AP_EventSubscribers[eventName]))
        level.AP_EventSubscribers[eventName] = [];

    foreach(existing in level.AP_EventSubscribers[eventName])
    {
        if(existing == callback)
            return;
    }

    level.AP_EventSubscribers[eventName][level.AP_EventSubscribers[eventName].size] = callback;
}

AP_EmitEvent(eventName, payload, priority)
{
    if(!IsDefined(eventName) || eventName == "")
        return;

    if(!IsDefined(priority))
        priority = 0;

    if(!IsDefined(level.AP_EventHistory))
        level.AP_EventHistory = [];

    level.AP_EventSequence++;

    eventData = Array(
        eventName,
        payload,
        priority,
        GetTime(),
        level.AP_EventSequence,
        self
    );

    level.AP_EventHistory[level.AP_EventHistory.size] = eventData;

    limit = IsDefined(level.AP_Config["EventHistoryLimit"]) ? level.AP_Config["EventHistoryLimit"] : 32;

    while(level.AP_EventHistory.size > limit)
        ArrayRemoveIndex(level.AP_EventHistory, 0);

    level notify("AP_EVENT_" + eventName, eventData);

    if(IsDefined(level.AP_EventSubscribers[eventName]))
    {
        foreach(callback in level.AP_EventSubscribers[eventName])
        {
            if(IsDefined(callback))
                level thread [[ callback ]](eventData);
        }
    }
}

AP_GetRecentEvents()
{
    if(!IsDefined(level.AP_EventHistory))
        return [];

    return level.AP_EventHistory;
}
