/*
    APPARITION PRO MAX - Phase 2
    Session statistics, streaks, records and round summaries.
*/

AP_Stats_Init()
{
    if(!IsDefined(self.AP_Stats))
        self.AP_Stats = [];

    if(!IsDefined(self.AP_Stats["kills"])) self.AP_Stats["kills"] = 0;
    if(!IsDefined(self.AP_Stats["downs"])) self.AP_Stats["downs"] = 0;
    if(!IsDefined(self.AP_Stats["revives"])) self.AP_Stats["revives"] = 0;
    if(!IsDefined(self.AP_Stats["round"])) self.AP_Stats["round"] = IsDefined(level.round_number) ? level.round_number : 1;
    if(!IsDefined(self.AP_Stats["sessionStart"])) self.AP_Stats["sessionStart"] = GetTime();
    if(!IsDefined(self.AP_Stats["killStreak"])) self.AP_Stats["killStreak"] = 0;
    if(!IsDefined(self.AP_Stats["bestKillStreak"])) self.AP_Stats["bestKillStreak"] = 0;
    if(!IsDefined(self.AP_Stats["challengeStreak"])) self.AP_Stats["challengeStreak"] = 0;
    if(!IsDefined(self.AP_Stats["bestChallengeStreak"])) self.AP_Stats["bestChallengeStreak"] = 0;
    if(!IsDefined(self.AP_Stats["roundKills"])) self.AP_Stats["roundKills"] = 0;
    if(!IsDefined(self.AP_Stats["roundDowns"])) self.AP_Stats["roundDowns"] = 0;

    if(!IsDefined(self.AP_Records))
        self.AP_Records = [];

    if(!IsDefined(self.AP_Records["highestRound"])) self.AP_Records["highestRound"] = self.AP_Stats["round"];
    if(!IsDefined(self.AP_Records["longestSession"])) self.AP_Records["longestSession"] = 0;
    if(!IsDefined(self.AP_Records["bestKillStreak"])) self.AP_Records["bestKillStreak"] = 0;
    if(!IsDefined(self.AP_Records["bestChallengeStreak"])) self.AP_Records["bestChallengeStreak"] = 0;
}

AP_Stats_OnKill(weapon)
{
    self AP_Stats_Init();

    self.AP_Stats["kills"]++;
    self.AP_Stats["roundKills"]++;
    self.AP_Stats["killStreak"]++;

    if(self.AP_Stats["killStreak"] > self.AP_Stats["bestKillStreak"])
        self.AP_Stats["bestKillStreak"] = self.AP_Stats["killStreak"];

    if(self.AP_Stats["bestKillStreak"] > self.AP_Records["bestKillStreak"])
        self.AP_Records["bestKillStreak"] = self.AP_Stats["bestKillStreak"];

    if(IsDefined(weapon))
        self.AP_Stats["lastKillWeapon"] = weapon;

    self AP_EmitEvent("ap_kill", Array(self.AP_Stats["killStreak"], weapon), 30);
}

AP_Stats_OnDown()
{
    self AP_Stats_Init();

    self.AP_Stats["downs"]++;
    self.AP_Stats["roundDowns"]++;
    self.AP_Stats["killStreak"] = 0;

    self AP_EmitEvent("ap_player_down", self.AP_Stats["downs"], 95);
}

AP_Stats_OnRevive()
{
    self AP_Stats_Init();
    self.AP_Stats["revives"]++;
    self AP_EmitEvent("ap_player_revive", self.AP_Stats["revives"], 85);
}

AP_Stats_OnDeath()
{
    self AP_Stats_Init();
    self.AP_Stats["killStreak"] = 0;
    self AP_EmitEvent("ap_player_death", self.AP_Stats["downs"], 100);
}

AP_Stats_UpdateRound(roundNumber)
{
    self AP_Stats_Init();

    if(!IsDefined(roundNumber))
        return;

    self.AP_Stats["round"] = roundNumber;

    if(roundNumber > self.AP_Records["highestRound"])
        self.AP_Records["highestRound"] = roundNumber;
}

AP_Stats_GetSessionSeconds()
{
    self AP_Stats_Init();
    return Int((GetTime() - self.AP_Stats["sessionStart"]) / 1000);
}

AP_Stats_SaveSessionRecord()
{
    self AP_Stats_Init();

    seconds = self AP_Stats_GetSessionSeconds();

    if(seconds > self.AP_Records["longestSession"])
        self.AP_Records["longestSession"] = seconds;
}

AP_Stats_RoundSnapshot()
{
    self AP_Stats_Init();
    return Array(
        self.AP_Stats["round"],
        self.AP_Stats["roundKills"],
        self.AP_Stats["roundDowns"],
        self.AP_Stats["killStreak"],
        self AP_Stats_GetSessionSeconds()
    );
}

AP_Stats_ResetRoundCounters()
{
    self AP_Stats_Init();
    self.AP_Stats["roundKills"] = 0;
    self.AP_Stats["roundDowns"] = 0;
}

AP_Stats_ChallengeCompleted()
{
    self AP_Stats_Init();
    self.AP_Stats["challengeStreak"]++;

    if(self.AP_Stats["challengeStreak"] > self.AP_Stats["bestChallengeStreak"])
        self.AP_Stats["bestChallengeStreak"] = self.AP_Stats["challengeStreak"];

    if(self.AP_Stats["bestChallengeStreak"] > self.AP_Records["bestChallengeStreak"])
        self.AP_Records["bestChallengeStreak"] = self.AP_Stats["bestChallengeStreak"];
}

AP_Stats_ChallengeFailed()
{
    self AP_Stats_Init();
    self.AP_Stats["challengeStreak"] = 0;
}
