/*
    APPARITION PRO MAX - Phase 2
    Core player-facing systems. Data is read from real Apparition state/API.
*/

AP_Features_Init()
{
    if(!IsDefined(self.AP_Features))
        self.AP_Features = [];

    self.AP_Features["zombieCounter"] = true;
    self.AP_Features["timeCounter"] = true;
    self.AP_Features["perkGuard"] = false;
    self.AP_Features["round100"] = false;
    self.AP_Features["zombieIntel"] = true;
    self.AP_Features["loadout"] = true;
    self.AP_Features["killStreak"] = true;
    self.AP_Features["clutch"] = true;
    self.AP_Features["sessionStats"] = true;
    self.AP_Features["personalRecords"] = true;
    self.AP_Features["roundSummary"] = true;
}

AP_Feature_SetEnabled(name, enabled)
{
    if(!IsDefined(self.AP_Features))
        self AP_Features_Init();

    self.AP_Features[name] = Is_True(enabled);
}

AP_Feature_GetEnabled(name)
{
    if(!IsDefined(self.AP_Features[name]))
        return false;

    return Is_True(self.AP_Features[name]);
}

AP_ZombieCounter_Count()
{
    zombies = GetAITeamArray(level.zombie_team);
    count = 0;

    if(IsDefined(zombies))
    {
        foreach(zombie in zombies)
        {
            if(IsDefined(zombie) && IsAlive(zombie))
                count++;
        }
    }

    return count;
}

AP_ZombieCounter_Update()
{
    if(!self AP_Feature_GetEnabled("zombieCounter"))
        return;

    count = self AP_ZombieCounter_Count();

    if(!IsDefined(self.AP_ZombieCounterHUD))
    {
        pos = level.AP_Config["HUDPositions"]["TopRight"];
        self AP_HUD_DestroyLayer("ZombieCounter");
        self.AP_ZombieCounterHUD = self AP_HUD_CreateText("ZombieCounter", "default", 1.0, 24, "", "RIGHT", pos[0] + 105, pos[1], 1, (1, 1, 1));
    }

    self AP_ZombieCounterHUD SetTextString("ZOMBIES  " + count);
    self AP_HUD_SetVisibility("ZombieCounter", self AP_HUD_IsVisible("Zombie Counter"));
}

AP_TimeCounter_Update()
{
    if(!self AP_Feature_GetEnabled("timeCounter"))
        return;

    seconds = self AP_Stats_GetSessionSeconds();
    mins = Int(seconds / 60);
    secs = seconds - (mins * 60);
    text = "TIME  " + mins + ":" + (secs < 10 ? "0" : "") + secs;

    if(!IsDefined(self.AP_TimeCounterHUD))
    {
        pos = level.AP_Config["HUDPositions"]["TopRight"];
        self.AP_TimeCounterHUD = self AP_HUD_CreateText("TimeCounter", "default", 1.0, 24, "", "RIGHT", pos[0] + 105, pos[1] + 22, 1, (1, 1, 1));
    }

    self.AP_TimeCounterHUD SetTextString(text);
    self AP_HUD_SetVisibility("TimeCounter", self AP_HUD_IsVisible("Time Counter"));
}

AP_PerkGuard_Apply()
{
    if(!self AP_Feature_GetEnabled("perkGuard"))
        return;

    if(!IsDefined(level._custom_perks))
        return;

    perks = GetArrayKeys(level._custom_perks);

    foreach(perk in perks)
    {
        if(!self HasPerk(perk) && !self zm_perks::has_perk_paused(perk))
            self zm_perks::give_perk(perk, true);
    }
}

AP_Round100_Enable()
{
    if(Is_True(self.AP_Round100Started))
        return;

    self.AP_Round100Started = true;

    if(IsDefined(level.round_number) && level.round_number < 100)
        self thread SetRound(100);
}

AP_Loadout_Update()
{
    if(!self AP_Feature_GetEnabled("loadout"))
        return;

    weapon = self GetCurrentWeapon();

    if(IsDefined(weapon))
        self.AP_LoadoutCurrentWeapon = weapon;

    if(!IsDefined(self.AP_LoadoutPrimary))
        self.AP_LoadoutPrimary = weapon;
    else if(IsDefined(weapon) && weapon != self.AP_LoadoutPrimary)
        self.AP_LoadoutSecondary = weapon;
}

AP_ZombieIntel_Update()
{
    if(!self AP_Feature_GetEnabled("zombieIntel"))
        return;

    zombies = GetAITeamArray(level.zombie_team);
    alive = 0;

    if(IsDefined(zombies))
    {
        foreach(zombie in zombies)
        {
            if(IsDefined(zombie) && IsAlive(zombie))
                alive++;
        }
    }

    if(!IsDefined(self.AP_ZombieIntelHUD))
    {
        pos = level.AP_Config["HUDPositions"]["TopRight"];
        self.AP_ZombieIntelHUD = self AP_HUD_CreateText("ZombieIntel", "default", 0.82, 23, "", "RIGHT", pos[0] + 105, pos[1] + 43, 0.9, (0.8, 0.8, 0.8));
    }

    self.AP_ZombieIntelHUD SetTextString("INTEL  " + alive + " ACTIVE");
    self AP_HUD_SetVisibility("ZombieIntel", self AP_HUD_IsVisible("Zombie Intel"));
}

AP_ClutchMeter_Update()
{
    if(!self AP_Feature_GetEnabled("clutch"))
        return;

    zombies = self AP_ZombieCounter_Count();
    health = IsAlive(self) ? self.health : 0;
    pressure = zombies;

    if(health > 0)
        pressure += Int((100 - health) / 10);

    if(self AP_Stats["downs"] > 0)
        pressure += self.AP_Stats["downs"] * 2;

    round = IsDefined(level.round_number) ? level.round_number : 1;
    pressure += Int(round / 20);

    if(pressure > 99)
        pressure = 99;

    if(!IsDefined(self.AP_ClutchHUD))
    {
        pos = level.AP_Config["HUDPositions"]["Challenge"];
        self.AP_ClutchHUD = self AP_HUD_CreateText("Clutch", "default", 0.82, 23, "", "LEFT", pos[0], pos[1] + 76, 0.8, (1, 1, 1));
    }

    self.AP_ClutchHUD SetTextString("CLUTCH  " + pressure + "%");
    self AP_HUD_SetVisibility("Clutch", self AP_HUD_IsVisible("Clutch Meter"));
}

AP_SessionStats_Update()
{
    if(!self AP_Feature_GetEnabled("sessionStats"))
        return;

    if(!IsDefined(self.AP_SessionStatsHUD))
    {
        pos = level.AP_Config["HUDPositions"]["Notification"];
        self.AP_SessionStatsHUD = self AP_HUD_CreateText("SessionStats", "default", 0.78, 23, "", "LEFT", pos[0], pos[1], 0.85, (0.8, 0.8, 0.8));
    }

    text = "SESSION  K:" + self.AP_Stats["kills"] + " D:" + self.AP_Stats["downs"] + " R:" + self.AP_Stats["revives"];
    self.AP_SessionStatsHUD SetTextString(text);
    self AP_HUD_SetVisibility("SessionStats", self AP_HUD_IsVisible("Session Stats"));
}

AP_PersonalRecords_Update()
{
    if(!self AP_Feature_GetEnabled("personalRecords"))
        return;

    if(!IsDefined(self.AP_RecordsHUD))
    {
        pos = level.AP_Config["HUDPositions"]["Notification"];
        self.AP_RecordsHUD = self AP_HUD_CreateText("PersonalRecords", "default", 0.75, 23, "", "LEFT", pos[0], pos[1] + 18, 0.82, (0.8, 0.8, 0.8));
    }

    text = "RECORDS  R:" + self.AP_Records["highestRound"] + " KS:" + self.AP_Records["bestKillStreak"] + " CS:" + self.AP_Records["bestChallengeStreak"];
    self.AP_RecordsHUD SetTextString(text);
    self AP_HUD_SetVisibility("PersonalRecords", self AP_HUD_IsVisible("Personal Records"));
}

AP_RoundSummary_Show(snapshot)
{
    if(!self AP_Feature_GetEnabled("roundSummary"))
        return;

    self AP_HUD_DestroyLayer("RoundSummary");

    pos = level.AP_Config["HUDPositions"]["RoundSummary"];
    self.AP_HUD_CreateText("RoundSummary", "default", 0.9, 24, "ROUND " + snapshot[0], "CENTER", pos[0], pos[1], 1, (1, 1, 1));
    self AP_HUD_CreateText("RoundSummary", "default", 0.78, 24, "KILLS " + snapshot[1] + "  DOWNS " + snapshot[2] + "  STREAK " + snapshot[3], "CENTER", pos[0], pos[1] + 20, 0.9, (0.85, 0.85, 0.85));
    self AP_HUD_CreateText("RoundSummary", "default", 0.72, 24, "SESSION " + snapshot[4] + "s", "CENTER", pos[0], pos[1] + 38, 0.8, (0.75, 0.75, 0.75));

    if(!self AP_HUD_IsVisible("Round Summary"))
        self AP_HUD_HideLayer("RoundSummary");
    else
        self AP_HUD_ShowLayer("RoundSummary");

    self thread AP_RoundSummary_Clear();
}

AP_RoundSummary_Clear()
{
    self endon("disconnect");
    wait 5;

    if(IsDefined(self))
        self AP_HUD_DestroyLayer("RoundSummary");
}

AP_ChallengeHUD_Update()
{
    if(!IsDefined(self.AP_Challenge["current"]))
    {
        self AP_HUD_DestroyLayer("Challenge");
        return;
    }

    definition = self.AP_Challenge["current"];
    progress = self.AP_Challenge["progress"];
    target = self.AP_Challenge["target"];

    pos = level.AP_Config["HUDPositions"]["Challenge"];

    if(!IsDefined(self.AP_ChallengeHUD))
        self.AP_ChallengeHUD = self AP_HUD_CreateText("Challenge", "default", 0.82, 24, "", "LEFT", pos[0], pos[1], 1, (1, 1, 1));

    self.AP_ChallengeHUD SetTextString("CHALLENGE  " + definition[1] + "  " + progress + "/" + target);
    self AP_HUD_SetVisibility("Challenge", self AP_HUD_IsVisible("Challenge"));
}

AP_LoadoutHUD_Update()
{
    if(!self AP_Feature_GetEnabled("loadout"))
        return;

    weapon = IsDefined(self.AP_LoadoutCurrentWeapon) ? self.AP_LoadoutCurrentWeapon : undefined;
    if(!IsDefined(weapon) || !IsDefined(weapon.name))
        return;

    if(!IsDefined(self.AP_LoadoutHUD))
    {
        self.AP_LoadoutHUD = self AP_HUD_CreateText("Loadout", "default", 0.72, 23, "", "LEFT", 32, 145, 0.8, (0.8, 0.8, 0.8));
    }

    self.AP_LoadoutHUD SetTextString("LOADOUT  " + weapon.name);
    self AP_HUD_SetVisibility("Loadout", self AP_HUD_IsVisible("Loadout"));
}

AP_KillStreakHUD_Update()
{
    if(!self AP_Feature_GetEnabled("killStreak"))
        return;

    if(!IsDefined(self.AP_KillStreakHUD))
        self.AP_KillStreakHUD = self AP_HUD_CreateText("KillStreak", "default", 0.72, 23, "", "LEFT", 32, 162, 0.8, (0.8, 0.8, 0.8));

    self.AP_KillStreakHUD SetTextString("STREAK  " + self.AP_Stats["killStreak"] + "  BEST " + self.AP_Stats["bestKillStreak"]);
    self AP_HUD_SetVisibility("KillStreak", self AP_HUD_IsVisible("KillStreak"));
}

AP_ChallengeStreakHUD_Update()
{
    if(!IsDefined(self.AP_Stats))
        return;

    if(!IsDefined(self.AP_ChallengeStreakHUD))
        self.AP_ChallengeStreakHUD = self AP_HUD_CreateText("ChallengeStreak", "default", 0.68, 23, "", "LEFT", 32, 196, 0.8, (0.8, 0.8, 0.8));

    self.AP_ChallengeStreakHUD SetTextString("CHALLENGE STREAK  " + self.AP_Stats["challengeStreak"] + "  BEST " + self.AP_Stats["bestChallengeStreak"]);
    self AP_HUD_SetVisibility("ChallengeStreak", self AP_HUD_IsVisible("Challenge Streak"));
}

AP_ChallengeDifficultyHUD_Update()
{
    if(!IsDefined(self.AP_Challenge))
        return;

    if(!IsDefined(self.AP_ChallengeDifficultyHUD))
        self.AP_ChallengeDifficultyHUD = self AP_HUD_CreateText("ChallengeDifficulty", "default", 0.68, 23, "", "LEFT", 32, 179, 0.8, (0.8, 0.8, 0.8));

    self.AP_ChallengeDifficultyHUD SetTextString("DIFFICULTY  " + self.AP_Challenge["difficulty"]);
    self AP_HUD_SetVisibility("ChallengeDifficulty", self AP_HUD_IsVisible("Challenge Difficulty"));
}

AP_Features_UpdateLoop()
{
    self endon("disconnect");

    while(1)
    {
        if(Is_Alive(self))
        {
            self AP_ZombieCounter_Update();
            self AP_TimeCounter_Update();
            self AP_ZombieIntel_Update();
            self AP_ClutchMeter_Update();
            self AP_SessionStats_Update();
            self AP_PersonalRecords_Update();
            self AP_Loadout_Update();
            self AP_ChallengeHUD_Update();
            self AP_LoadoutHUD_Update();
            self AP_KillStreakHUD_Update();
            self AP_ChallengeDifficultyHUD_Update();
            self AP_ChallengeStreakHUD_Update();

            if(self AP_Feature_GetEnabled("perkGuard"))
                self AP_PerkGuard_Apply();
        }

        wait 0.25;
    }
}
