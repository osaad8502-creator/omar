/*
    APPARITION PRO MAX - Phase 2
    Lifecycle glue for the core systems.
*/

AP_Phase2_InitializePlayer()
{
    self endon("disconnect");

    if(Is_True(self.AP_Phase2Initialized))
        return;

    self.AP_Phase2Initialized = true;

    self AP_Stats_Init();
    self AP_Features_Init();
    self AP_Detector_Init();
    self AP_Director_Init();
    self AP_Integration_Init();

    self AP_Challenge_Generate();

    if(!Is_True(self.AP_Phase2UpdateThread))
    {
        self.AP_Phase2UpdateThread = true;
        self thread AP_Features_UpdateLoop();
    }

    self AP_EmitEvent("ap_session_start", Array(ReturnMapName(), self AP_Stats["sessionStart"]), 60);
}

AP_Phase2_RegisterEvents()
{
    if(Is_True(level.AP_Phase2EventsRegistered))
        return;

    level.AP_Phase2EventsRegistered = true;

    AP_RegisterEventSubscriber("ap_kill", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_player_down", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_player_revive", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_player_death", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_weapon_change", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_raygun", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_pap_weapon", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_challenge_complete", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_challenge_failure", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_round_change", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_director_emergency", ::AP_Phase2_OnEvent);
    AP_RegisterEventSubscriber("ap_challenge_started", ::AP_Phase2_OnEvent);
}

AP_Phase2_OnEvent(eventData)
{
    if(!IsDefined(eventData) || eventData.size < 6)
        return;

    player = eventData[5];
    if(!IsDefined(player) || !IsPlayer(player))
        return;

    eventName = eventData[0];

    player AP_Integration_OnEvent(eventData);

    if(eventName == "ap_kill")
        player AP_Challenge_OnKill();

    if(eventName == "ap_challenge_complete" || eventName == "ap_challenge_failure")
    {
        if(eventName == "ap_challenge_complete")
            player AP_Character_HandleEvent(eventData);
        else
            player AP_Character_HandleEvent(eventData);
    }
    else
        player AP_Character_HandleEvent(eventData);
}

AP_Phase2_OnZombieKill(einflictor, attacker, idamage, smeansofdeath, weapon, vdir, shitloc, psoffsettime)
{
    if(IsDefined(attacker) && IsPlayer(attacker))
    {
        attacker AP_Stats_OnKill(weapon);
    }
}

AP_Phase2_OnRoundEnd()
{
    foreach(player in level.players)
    {
        if(!IsDefined(player) || !IsPlayer(player))
            continue;

        if(IsDefined(player.AP_Stats))
            player AP_Stats_SaveSessionRecord();
    }
}
