/*
    APPARITION PRO MAX - Phase 1
    Configuration foundation.

    This file contains only shared structure/configuration. Core gameplay
    systems are intentionally implemented in later phases.
*/

AP_ConfigInit()
{
    if(Is_True(level.AP_ConfigInitialized))
        return;

    level.AP_ConfigInitialized = true;
    level.AP_Config = [];

    // Side-menu input is grounded in Apparition's existing input abstraction:
    // +speed_throw = Ads/R2 and +actionslot 2 = ActionSlotTwoButtonPressed().
    level.AP_Config["SideMenuOpenControls"] = Array("+speed_throw", "+actionslot 2");

    level.AP_Config["SideMenuItems"] = Array(
        "Zombie Counter",
        "Time Counter",
        "Perk Guard",
        "Round 100",
        "Smart Difficulty",
        "Director",
        "Character",
        "Challenge",
        "Zombie Intel",
        "Loadout",
        "Kill Streak",
        "Clutch Meter",
        "Session Stats",
        "Round Summary",
        "Personal Records",
        "Challenge Streak",
        "Challenge Difficulty",
        "HUD Visibility Settings"
    );

    level.AP_Config["HUDPositions"] = [];
    level.AP_Config["HUDPositions"]["Character"] = Array(32, 30, 280, 86);
    level.AP_Config["HUDPositions"]["TopRight"] = Array(520, 30, 112, 44);
    level.AP_Config["HUDPositions"]["Challenge"] = Array(500, 92, 132, 72);
    level.AP_Config["HUDPositions"]["Notification"] = Array(320, 175, 300, 70);
    level.AP_Config["HUDPositions"]["RoundSummary"] = Array(320, 365, 300, 80);

    level.AP_Config["EventHistoryLimit"] = 32;
    level.AP_Config["CharacterMemoryLimit"] = 32;
    level.AP_Config["ChallengeHistoryLimit"] = 32;
}
