/*
    APPARITION PRO MAX - Phase 1
    Integration point and lifecycle foundation.

    Phase 1 intentionally initializes architecture only. Gameplay detectors,
    counters, Director logic and full challenge generation belong to later phases.
*/

AP_Initialize()
{
    if(Is_True(level.AP_Initialized))
        return;

    level.AP_Initialized = true;

    AP_ConfigInit();
    AP_EventsInit();
    AP_ChallengesInit();
    AP_Phase2_RegisterEvents();

    level.AP_SessionState = [];
    level.AP_SessionState["map"] = ReturnMapName();
    level.AP_SessionState["startedAt"] = GetTime();
    level.AP_SessionState["round"] = IsDefined(level.round_number) ? level.round_number : 0;
}

AP_OnPlayerSpawned()
{
    self endon("disconnect");

    // The existing Apparition callback owns playerSetup(). Wait until its
    // player state/menu variables are established before touching AP HUD/menu.
    for(a = 0; a < 200; a++)
    {
        if(IsDefined(self.playerSpawned) && IsDefined(self.OpenControls))
            break;

        wait 0.01;
    }

    if(!IsDefined(self.playerSpawned))
        return;

    self AP_StateInitPlayer();
    self AP_StateResetSpawn();
    self AP_SideMenu_Init();
    self AP_Phase2_InitializePlayer();

    if(!Is_True(self.AP_CharacterQueueThread))
        self thread AP_Character_ProcessQueue();
}

AP_OnPlayerDisconnect()
{
    if(IsDefined(self.AP_IntegrationInitialized))
        self AP_Integration_FinalizeSession();
    else if(IsDefined(self.AP_Stats))
        self AP_Stats_SaveSessionRecord();

    self AP_StateCleanupPlayer();
}
