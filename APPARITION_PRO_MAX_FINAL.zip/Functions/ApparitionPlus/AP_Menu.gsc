/*
    APPARITION PRO MAX - Phase 1
    Independent side-menu foundation.

    It coexists with the original Apparition menu and temporarily disables
    the original menu monitor only while this menu is open.
*/

AP_SideMenu_Init()
{
    self endon("disconnect");

    if(Is_True(self.AP_SideMenuMonitor))
        return;

    self.AP_SideMenuMonitor = true;
    self thread AP_SideMenu_Monitor();
}

AP_SideMenu_Monitor()
{
    self endon("disconnect");

    while(1)
    {
        if(!Is_True(self.AP_SideMenuOpen))
        {
            if(Is_Alive(self) && !self isInMenu(true) && self AreButtonsPressed(level.AP_Config["SideMenuOpenControls"]))
            {
                self AP_SideMenu_Open();
                wait 0.4;
            }
        }
        else
        {
            if(!Is_Alive(self))
            {
                self AP_SideMenu_Close();
            }
            else if(self AttackButtonPressed() && !self AdsButtonPressed())
            {
                self AP_SideMenu_Move(1);
                wait 0.14;
            }
            else if(self AdsButtonPressed() && !self AttackButtonPressed())
            {
                self AP_SideMenu_Move(-1);
                wait 0.14;
            }
            else if(self UseButtonPressed())
            {
                self AP_SideMenu_Select();
                wait 0.18;
            }
            else if(self MeleeButtonPressed())
            {
                self AP_SideMenu_Close();
                wait 0.2;
            }
        }

        wait 0.05;
    }
}

AP_SideMenu_Open()
{
    if(Is_True(self.AP_SideMenuOpen))
        return;

    if(self isInMenu(true))
        return;

    self.AP_SideMenuOpen = true;
    self.AP_SideMenuCursor = 0;
    self.AP_SideMenuPrevDisableMenuControls = self.DisableMenuControls;
    self.DisableMenuControls = true;

    self AP_SideMenu_Draw();
}

AP_SideMenu_Close()
{
    if(!Is_True(self.AP_SideMenuOpen))
        return;

    self AP_SideMenu_Destroy();

    self.AP_SideMenuOpen = false;
    self.AP_SideMenuCursor = 0;

    if(IsDefined(self.AP_SideMenuPrevDisableMenuControls))
        self.DisableMenuControls = self.AP_SideMenuPrevDisableMenuControls;
    else
        self.DisableMenuControls = undefined;

    self.AP_SideMenuPrevDisableMenuControls = undefined;
}

AP_SideMenu_Move(direction)
{
    count = level.AP_Config["SideMenuItems"].size;

    if(count <= 0)
        return;

    self.AP_SideMenuCursor += direction;

    if(self.AP_SideMenuCursor < 0)
        self.AP_SideMenuCursor = count - 1;

    if(self.AP_SideMenuCursor >= count)
        self.AP_SideMenuCursor = 0;

    self AP_SideMenu_Draw();
}

AP_SideMenu_Select()
{
    item = level.AP_Config["SideMenuItems"][self.AP_SideMenuCursor];

    switch(item)
    {
        case "Perk Guard":
            self AP_Feature_SetEnabled("perkGuard", !self AP_Feature_GetEnabled("perkGuard"));
            break;

        case "Round 100":
            if(!Is_True(self.AP_Round100Started))
            {
                self AP_Feature_SetEnabled("round100", true);
                self AP_Round100_Enable();
            }
            break;

        case "Smart Difficulty":
            self AP_Challenge_SmartDifficulty();
            break;

        case "Director":
            self.AP_DirectorEnabled = !Is_True(self.AP_DirectorEnabled);
            break;

        case "Character":
            self AP_Character_SetEnabled(!Is_True(self.AP_Character["enabled"]));
            break;

        case "Challenge":
            self.AP_Challenge["enabled"] = !Is_True(self.AP_Challenge["enabled"]);
            break;

        case "HUD Visibility Settings":
            visible = !self AP_HUD_IsVisible("ZombieCounter");
            self AP_HUD_SetAllFeatureVisibility(visible);
            break;

        default:
            layer = self AP_SideMenu_ItemLayer(item);
            current = self AP_HUD_IsVisible(layer);
            self AP_HUD_SetVisibility(layer, !current);
            break;
    }

    self AP_SideMenu_Draw();
}

AP_SideMenu_ItemState(item)
{
    switch(item)
    {
        case "Perk Guard":
            return self AP_Feature_GetEnabled("perkGuard") ? "ON" : "OFF";
        case "Round 100":
            return Is_True(self.AP_Round100Started) ? "ON" : "OFF";
        case "Smart Difficulty":
            return IsDefined(self.AP_Challenge["difficulty"]) ? self.AP_Challenge["difficulty"] : "Normal";
        case "Director":
            return Is_True(self.AP_DirectorEnabled) ? "ON" : "OFF";
        case "Character":
            return Is_True(self.AP_Character["enabled"]) ? "ON" : "OFF";
        case "Challenge":
            return Is_True(self.AP_Challenge["enabled"]) ? "ON" : "OFF";
        case "HUD Visibility Settings":
            return self AP_HUD_IsVisible("ZombieCounter") ? "ON" : "OFF";
        default:
            layer = self AP_SideMenu_ItemLayer(item);
            return self AP_HUD_IsVisible(layer) ? "ON" : "OFF";
    }
}

AP_SideMenu_Draw()
{
    self AP_SideMenu_Destroy();

    self.AP_HUD["SideMenu"] = [];

    self.AP_HUD["SideMenu"][0] = self createRectangle("CENTER", 520, 235, 250, 300, (0, 0, 0), 20, 0.88, "white");
    self.AP_HUD["SideMenu"][1] = self createRectangle("CENTER", 520, 235, 250, 2, self.MainTheme, 21, 1, "white");
    self.AP_HUD["SideMenu"][2] = self createText("default", 1.25, 22, "APPARITION PRO MAX", "CENTER", 520, 105, 1, (1, 1, 1));

    startY = 132;

    for(a = 0; a < level.AP_Config["SideMenuItems"].size; a++)
    {
        item = level.AP_Config["SideMenuItems"][a];
        state = self AP_SideMenu_ItemState(item);
        selected = a == self.AP_SideMenuCursor;

        text = selected ? "> " + item + "   " + state : item + "   " + state;
        fontColor = selected ? self.MainTheme : (1, 1, 1);

        self.AP_HUD["SideMenu"][self.AP_HUD["SideMenu"].size] = self createText(
            "default",
            1.0,
            22,
            text,
            "LEFT",
            410,
            startY + (a * 20),
            1,
            fontColor
        );
    }

    self.AP_HUD["SideMenu"][self.AP_HUD["SideMenu"].size] = self createText(
        "default",
        0.9,
        22,
        "[{+attack}]/[{+speed_throw}] Navigate    [{+activate}] Toggle    [{+melee}] Close",
        "CENTER",
        520,
        385,
        1,
        (0.8, 0.8, 0.8)
    );
}

AP_SideMenu_Destroy()
{
    if(!IsDefined(self.AP_HUD) || !IsDefined(self.AP_HUD["SideMenu"]))
        return;

    foreach(element in self.AP_HUD["SideMenu"])
    {
        if(IsDefined(element))
            element DestroyHud();
    }

    self.AP_HUD["SideMenu"] = [];
}

AP_SideMenu_ItemLayer(item)
{
    switch(item)
    {
        case "Zombie Counter": return "ZombieCounter";
        case "Time Counter": return "TimeCounter";
        case "Character": return "Character";
        case "Challenge": return "Challenge";
        case "Zombie Intel": return "ZombieIntel";
        case "Loadout": return "Loadout";
        case "Kill Streak": return "KillStreak";
        case "Clutch Meter": return "Clutch";
        case "Session Stats": return "SessionStats";
        case "Personal Records": return "PersonalRecords";
        case "Round Summary": return "RoundSummary";
        case "Challenge Streak": return "ChallengeStreak";
        case "Challenge Difficulty": return "ChallengeDifficulty";
        case "HUD Visibility Settings": return "HUDSettings";
        default: return item;
    }
}
