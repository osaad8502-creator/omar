/*
    APPARITION PRO MAX - Phase 2
    Interactive Arabic character: event-driven dialogue, priority queue,
    session memory and map personality.
*/

AP_Character_Init()
{
    if(!IsDefined(self.AP_Character))
        self.AP_Character = [];

    if(!IsDefined(self.AP_Character["enabled"])) self.AP_Character["enabled"] = true;
    if(!IsDefined(self.AP_Character["visible"])) self.AP_Character["visible"] = true;
    if(!IsDefined(self.AP_Character["queue"])) self.AP_Character["queue"] = [];
    if(!IsDefined(self.AP_Character["pools"])) self.AP_Character["pools"] = [];
    if(!IsDefined(self.AP_Character["memory"])) self.AP_Character["memory"] = [];
    if(!IsDefined(self.AP_Character["mapPersonality"])) self.AP_Character["mapPersonality"] = ReturnMapName();
    if(!IsDefined(self.AP_Character["cooldownUntil"])) self.AP_Character["cooldownUntil"] = 0;
    if(!IsDefined(self.AP_Character["lastDialogue"])) self.AP_Character["lastDialogue"] = "";

    self AP_Character_RegisterDefaultPools();
    self AP_HUD_SetVisibility("Character", self.AP_Character["visible"]);
}

AP_Character_RegisterDefaultPools()
{
    self.AP_Character_SetDialoguePool("ap_raygun", Array(
        "أوووه الريقن... هسه صار اللعب جد.",
        "حلو، جبت الريقن. لا تضيعه بس.",
        "ههههههههههههههههههه الريقن وصل."
    ));

    self.AP_Character_SetDialoguePool("ap_pap_weapon", Array(
        "زين، طوّرت السلاح. هسه نشوف الشغل.",
        "التطوير تم. لا تقول بعدين ما نبهتك.",
        "السلاح صار مطوّر، خل نشوف الأداء."
    ));

    self.AP_Character_SetDialoguePool("ap_player_down", Array(
        "داون؟ قوم قوم، مو وقت نوم.",
        "يا ساتر، داون جديد. شد حيلك.",
        "ههههههههههههههههههه شنو هذا الداوني؟"
    ));

    self.AP_Character_SetDialoguePool("ap_player_death", Array(
        "خلصت؟ يلا، الجولة الجاية ركز أكثر.",
        "الموت صار. نشوف شتسوي بالمحاولة الجاية."
    ));

    self.AP_Character_SetDialoguePool("ap_player_revive", Array(
        "رجعت؟ يلا كمل.",
        "إنعاش مضبوط، لا تعيدها."
    ));

    self.AP_Character_SetDialoguePool("ap_challenge_complete", Array(
        "التحدي خلص. هذا الشغل.",
        "تم التحدي. حلو، كمل بنفس المستوى."
    ));

    self.AP_Character_SetDialoguePool("ap_challenge_failure", Array(
        "التحدي راح. حاول تضبطها المرة الجاية.",
        "فشل التحدي. عادي، نكمل."
    ));

    self.AP_Character_SetDialoguePool("ap_director_emergency", Array(
        "الوضع صار ضغط. تحرك ولا تتورط.",
        "الزومبي زايدين والدم نازل، انتبه."
    ));

    self.AP_Character_SetDialoguePool("ap_kill", Array(
        "زين.",
        "واحد بعد.",
        "استمر."
    ));
}

AP_Character_SetEnabled(enabled)
{
    self AP_Character_Init();
    self.AP_Character["enabled"] = Is_True(enabled);
}

AP_Character_SetVisible(visible)
{
    self AP_Character_Init();
    self.AP_Character["visible"] = Is_True(visible);
    self AP_HUD_SetVisibility("Character", self.AP_Character["visible"]);
}

AP_Character_SetMapPersonality(mapName)
{
    self AP_Character_Init();
    self.AP_Character["mapPersonality"] = IsDefined(mapName) ? mapName : ReturnMapName();
}

AP_Character_SetDialoguePool(eventName, pool)
{
    if(!IsDefined(eventName) || eventName == "" || !IsDefined(pool) || !IsArray(pool))
        return;

    self.AP_Character["pools"][eventName] = pool;
}

AP_Character_AddMemory(memoryEvent)
{
    if(!IsDefined(memoryEvent))
        return;

    self.AP_Character["memory"][self.AP_Character["memory"].size] = memoryEvent;

    limit = IsDefined(level.AP_Config["CharacterMemoryLimit"]) ? level.AP_Config["CharacterMemoryLimit"] : 32;
    while(self.AP_Character["memory"].size > limit)
        ArrayRemoveIndex(self.AP_Character["memory"], 0);
}

AP_Character_QueueDialogue(text, priority, eventName)
{
    if(!IsDefined(text) || text == "")
        return;

    if(!IsDefined(priority)) priority = 0;
    if(!IsDefined(eventName)) eventName = "";

    // Avoid queuing the exact same line repeatedly while it is pending.
    foreach(item in self.AP_Character["queue"])
    {
        if(IsDefined(item) && item[0] == text)
            return;
    }

    self.AP_Character["queue"][self.AP_Character["queue"].size] = Array(text, priority, eventName);
    self notify("AP_CHARACTER_QUEUE");
}

AP_Character_GetHighestPriorityDialogue()
{
    if(!self.AP_Character["queue"].size)
        return undefined;

    bestIndex = 0;
    bestPriority = self.AP_Character["queue"][0][1];

    for(a = 1; a < self.AP_Character["queue"].size; a++)
    {
        if(self.AP_Character["queue"][a][1] > bestPriority)
        {
            bestIndex = a;
            bestPriority = self.AP_Character["queue"][a][1];
        }
    }

    result = self.AP_Character["queue"][bestIndex];
    ArrayRemoveIndex(self.AP_Character["queue"], bestIndex);
    return result;
}

AP_Character_RandomPoolLine(eventName)
{
    pool = self.AP_Character["pools"][eventName];

    if(!IsDefined(pool) || !IsArray(pool) || !pool.size)
        return "";

    // Prevent immediate repetition when a pool has alternatives.
    candidates = [];
    foreach(line in pool)
    {
        if(line != self.AP_Character["lastDialogue"] || pool.size == 1)
            candidates[candidates.size] = line;
    }

    if(!candidates.size)
        return pool[0];

    return candidates[RandomInt(candidates.size)];
}

AP_Character_HandleEvent(eventData)
{
    if(!IsDefined(eventData) || eventData.size < 1)
        return;

    eventName = eventData[0];

    if(!IsDefined(self.AP_Character["pools"][eventName]))
        return;

    priority = eventData[2];
    text = self AP_Character_RandomPoolLine(eventName);

    if(text != "")
        self AP_Character_QueueDialogue(text, priority, eventName);

    self AP_Character_AddMemory(Array(eventName, GetTime(), self.AP_Stats["downs"], self.AP_Stats["killStreak"]));
}

AP_Character_ShowDialogue(text, duration)
{
    if(!IsDefined(text) || text == "")
        return;

    if(!IsDefined(duration)) duration = 3;

    self AP_HUD_DestroyLayer("Character");

    pos = level.AP_Config["HUDPositions"]["Character"];
    bg = self AP_HUD_CreateRectangle("Character", "TOP_LEFT", pos[0], pos[1], pos[2], pos[3], (0, 0, 0), 2, 0.72, "white");
    line = self AP_HUD_CreateRectangle("Character", "TOP_LEFT", pos[0], pos[1], 3, pos[3], (1, 0.5, 0), 3, 1, "white");
    txt = self AP_HUD_CreateText("Character", "default", 1.05, 4, text, "LEFT", pos[0] + 10, pos[1] + 9, 1, (1, 1, 1));

    if(!Is_True(self.AP_Character["visible"]))
        self AP_HUD_HideLayer("Character");

    wait duration;

    if(IsDefined(self))
        self AP_HUD_DestroyLayer("Character");
}

AP_Character_ProcessQueue()
{
    self endon("disconnect");

    if(Is_True(self.AP_CharacterQueueThread))
        return;

    self.AP_CharacterQueueThread = true;

    while(1)
    {
        self waittill("AP_CHARACTER_QUEUE");

        if(!Is_True(self.AP_Character["enabled"]))
            continue;

        dialogue = self AP_Character_GetHighestPriorityDialogue();
        if(!IsDefined(dialogue))
            continue;

        now = GetTime();

        if(now < self.AP_Character["cooldownUntil"])
        {
            // Preserve the event for a later pass instead of dropping it.
            self.AP_Character["queue"][self.AP_Character["queue"].size] = dialogue;
            wait 0.25;
            self notify("AP_CHARACTER_QUEUE");
            continue;
        }

        self.AP_Character["lastDialogue"] = dialogue[0];
        self AP_Character_AddMemory(Array(dialogue[2], dialogue[0], now));
        self AP_Character_ShowDialogue(dialogue[0], 3);
        self.AP_Character["cooldownUntil"] = GetTime() + 5000;
    }
}
