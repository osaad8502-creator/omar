/*
    APPARITION PRO MAX - Phase 3
    Integrated rule/state Director.

    Decision order:
    Read State -> Recent Events -> Map -> Difficulty -> Context -> Action.
    This is not an AI/LLM system.
*/

AP_Director_Init()
{
    if(Is_True(self.AP_DirectorRunning))
        return;

    self.AP_DirectorRunning = true;
    self.AP_DirectorEnabled = true;
    self.AP_DirectorLastAction = "";
    self.AP_DirectorLastEvaluationAt = 0;
    self.AP_DirectorCooldownUntil = 0;
    self.AP_DirectorEmergencyUntil = 0;
    self thread AP_Director_Loop();
}

AP_Director_Loop()
{
    self endon("disconnect");

    while(1)
    {
        if(Is_True(self.AP_DirectorEnabled) && IsAlive(self))
        {
            action = self AP_Director_Evaluate();
            if(action != "")
            {
                self.AP_DirectorLastAction = action;
                self AP_Integration_ExecuteDirectorAction(action);
            }
        }

        wait 1;
    }
}

AP_Director_Evaluate()
{
    if(!Is_True(self.AP_DirectorEnabled) || !IsAlive(self))
        return "";

    now = GetTime();
    if(now < self.AP_DirectorCooldownUntil)
        return "";

    zombies = self AP_ZombieCounter_Count();
    health = self.health;
    round = IsDefined(level.round_number) ? level.round_number : 1;
    difficulty = self AP_Challenge_SmartDifficulty();
    recent = AP_GetRecentEvents();
    recentCount = IsDefined(recent) ? recent.size : 0;

    // Emergency has priority over every other Director action.
    if(self isDown() || (health > 0 && health < 35 && zombies >= 8))
    {
        if(now >= self.AP_DirectorEmergencyUntil)
        {
            self.AP_DirectorEmergencyUntil = now + 5000;
            self.AP_DirectorCooldownUntil = now + 2000;
            return "emergency";
        }
        return "";
    }

    // Avoid starting a new challenge while the player is under sustained
    // pressure or immediately after a high-priority event burst.
    if(!IsDefined(self.AP_Challenge["current"]) && Is_True(self.AP_Challenge["enabled"]) && round >= 3)
    {
        if(zombies <= 5 && recentCount < 12)
        {
            self.AP_DirectorCooldownUntil = now + 3000;
            return "generate_challenge";
        }
    }

    // Re-evaluate challenge difficulty only at meaningful state boundaries.
    if(IsDefined(self.AP_Challenge["current"]))
    {
        if(difficulty == "Extreme" && zombies >= 10)
        {
            self.AP_DirectorCooldownUntil = now + 3000;
            return "lower_difficulty";
        }

        if((difficulty == "Easy" || difficulty == "Normal") && round >= 15 && zombies <= 5)
        {
            self.AP_DirectorCooldownUntil = now + 3000;
            return "raise_difficulty";
        }
    }

    // No useful action is better than noisy dialogue or random decisions.
    return "";
}
