/*
    APPARITION PRO MAX - Phase 2
    Map-aware challenge generator and challenge difficulty.
    Selection is state-driven; randomness is only used inside a valid pool.
*/

AP_Challenge_Define(id, name, description, difficulty, target, mapFilter)
{
    if(!IsDefined(id) || id == "" || !IsDefined(name))
        return undefined;

    definition = Array(
        id,
        name,
        IsDefined(description) ? description : "",
        IsDefined(difficulty) ? difficulty : "Normal",
        IsDefined(target) ? target : 0,
        IsDefined(mapFilter) ? mapFilter : []
    );

    level.AP_ChallengeDefinitions[id] = definition;
    return definition;
}

AP_ChallengesInit()
{
    if(Is_True(level.AP_ChallengeDefinitionsInitialized))
        return;

    level.AP_ChallengeDefinitionsInitialized = true;
    level.AP_ChallengeDefinitions = [];

    AP_Challenge_Define("kills_10", "Ten Down", "Get 10 zombie kills.", "Easy", 10, []);
    AP_Challenge_Define("kills_25", "Quarter Century", "Get 25 zombie kills.", "Normal", 25, []);
    AP_Challenge_Define("streak_10", "Keep It Going", "Reach a 10 kill streak.", "Normal", 10, []);
    AP_Challenge_Define("round_survive", "Hold The Round", "Survive the current round without going down.", "Hard", 1, []);
    AP_Challenge_Define("kino_momentum", "Kino Momentum", "Get 20 zombie kills on Kino Der Toten.", "Normal", 20, Array("Kino Der Toten"));
    AP_Challenge_Define("origins_momentum", "Origins Momentum", "Get 20 zombie kills on Origins.", "Normal", 20, Array("Origins"));
}

AP_Challenge_Init()
{
    if(!IsDefined(self.AP_Challenge))
        self.AP_Challenge = [];

    if(!IsDefined(self.AP_Challenge["enabled"]))
        self.AP_Challenge["enabled"] = true;
    if(!IsDefined(self.AP_Challenge["history"]))
        self.AP_Challenge["history"] = [];
    if(!IsDefined(self.AP_Challenge["difficulty"]))
        self.AP_Challenge["difficulty"] = "Normal";
    if(!IsDefined(self.AP_Challenge["lastId"]))
        self.AP_Challenge["lastId"] = "";
}

AP_Challenge_GetDefinition(id)
{
    if(!IsDefined(level.AP_ChallengeDefinitions) || !IsDefined(id))
        return undefined;

    return level.AP_ChallengeDefinitions[id];
}

AP_Challenge_MapAllowed(definition, mapName)
{
    if(!IsDefined(definition))
        return false;

    mapFilter = definition[5];

    if(!IsDefined(mapFilter) || !IsArray(mapFilter) || !mapFilter.size)
        return true;

    return isInArray(mapFilter, mapName);
}

AP_Challenge_SetCurrent(id)
{
    self AP_Challenge_Init();

    definition = self AP_Challenge_GetDefinition(id);
    if(!IsDefined(definition))
        return false;

    if(!self AP_Challenge_MapAllowed(definition, ReturnMapName()))
        return false;

    self.AP_Challenge["current"] = definition;
    self.AP_Challenge["progress"] = 0;
    self.AP_Challenge["target"] = definition[4];
    self.AP_Challenge["difficulty"] = definition[3];
    self.AP_Challenge["lastId"] = definition[0];
    self.AP_Challenge["roundStarted"] = IsDefined(level.round_number) ? level.round_number : 1;

    self AP_EmitEvent("ap_challenge_started", Array(definition[0], definition[1]), 55);
    return true;
}

AP_Challenge_UpdateProgress(amount)
{
    self AP_Challenge_Init();

    if(!IsDefined(self.AP_Challenge["current"]))
        return;

    if(!IsDefined(amount))
        amount = 1;

    self.AP_Challenge["progress"] += amount;

    if(self.AP_Challenge["target"] > 0 && self.AP_Challenge["progress"] >= self.AP_Challenge["target"])
        self AP_Challenge_Complete();
}

AP_Challenge_Complete()
{
    self AP_Challenge_Init();

    if(!IsDefined(self.AP_Challenge["current"]))
        return;

    definition = self.AP_Challenge["current"];
    self.AP_Challenge["history"][self.AP_Challenge["history"].size] = Array(definition[0], true, GetTime());

    limit = IsDefined(level.AP_Config["ChallengeHistoryLimit"]) ? level.AP_Config["ChallengeHistoryLimit"] : 32;
    while(self.AP_Challenge["history"].size > limit)
        ArrayRemoveIndex(self.AP_Challenge["history"], 0);

    self AP_Stats_ChallengeCompleted();
    self AP_EmitEvent("ap_challenge_complete", Array(definition[0], definition[1]), 90);

    self.AP_Challenge["current"] = undefined;
    self.AP_Challenge["progress"] = 0;
    self.AP_Challenge["target"] = 0;
}

AP_Challenge_Fail(reason)
{
    self AP_Challenge_Init();

    if(!IsDefined(self.AP_Challenge["current"]))
        return;

    definition = self.AP_Challenge["current"];
    self.AP_Challenge["history"][self.AP_Challenge["history"].size] = Array(definition[0], false, GetTime(), reason);

    limit = IsDefined(level.AP_Config["ChallengeHistoryLimit"]) ? level.AP_Config["ChallengeHistoryLimit"] : 32;
    while(self.AP_Challenge["history"].size > limit)
        ArrayRemoveIndex(self.AP_Challenge["history"], 0);

    self AP_Stats_ChallengeFailed();
    self AP_EmitEvent("ap_challenge_failure", Array(definition[0], reason), 80);

    self.AP_Challenge["current"] = undefined;
    self.AP_Challenge["progress"] = 0;
    self.AP_Challenge["target"] = 0;
}

AP_Challenge_SetDifficulty(difficulty)
{
    if(difficulty != "Easy" && difficulty != "Normal" && difficulty != "Hard" && difficulty != "Extreme")
        return;

    self AP_Challenge_Init();
    self.AP_Challenge["difficulty"] = difficulty;
}

AP_Challenge_DifficultyScore()
{
    self AP_Stats_Init();

    round = IsDefined(level.round_number) ? level.round_number : 1;
    score = 0;

    score += Int(round / 10);
    score += Int(self.AP_Stats["killStreak"] / 10);
    score += self.AP_Stats["downs"] * -2;

    if(IsAlive(self) && self.health < 50)
        score -= 3;

    if(IsDefined(self.AP_DetectorLastWeapon) && IsDefined(self.AP_DetectorLastWeapon.name))
    {
        if(zm_weapons::is_weapon_upgraded(self.AP_DetectorLastWeapon))
            score += 2;
    }

    if(IsDefined(self.perks_active) && self.perks_active.size >= 3)
        score += 1;

    if(IsDefined(self.AP_Challenge["current"]))
        score += 1;

    recent = AP_GetRecentEvents();
    if(IsDefined(recent) && recent.size >= 4)
        score += 1;

    if(score <= 2) return 0;
    if(score <= 5) return 1;
    if(score <= 8) return 2;
    return 3;
}

AP_Challenge_SmartDifficulty()
{
    score = self AP_Challenge_DifficultyScore();

    difficulty = "Easy";
    if(score == 1) difficulty = "Normal";
    if(score == 2) difficulty = "Hard";
    if(score >= 3) difficulty = "Extreme";

    self AP_Challenge_SetDifficulty(difficulty);
    return difficulty;
}

AP_Challenge_Generate()
{
    self AP_Challenge_Init();

    if(!Is_True(self.AP_Challenge["enabled"]))
        return false;

    if(IsDefined(self.AP_Challenge["current"]))
        return true;

    difficulty = self AP_Challenge_SmartDifficulty();
    round = IsDefined(level.round_number) ? level.round_number : 1;
    pool = [];

    if(round >= 10)
        pool[pool.size] = "kills_25";
    else
        pool[pool.size] = "kills_10";

    if(self.AP_Stats["killStreak"] >= 5)
        pool[pool.size] = "streak_10";

    pool[pool.size] = "round_survive";

    mapName = ReturnMapName();
    if(mapName == "Kino Der Toten")
        pool[pool.size] = "kino_momentum";
    else if(mapName == "Origins")
        pool[pool.size] = "origins_momentum";

    valid = [];
    foreach(id in pool)
    {
        definition = self AP_Challenge_GetDefinition(id);
        if(!IsDefined(definition) || id == self.AP_Challenge["lastId"])
            continue;

        if(difficulty == "Easy" && definition[3] == "Extreme")
            continue;

        valid[valid.size] = id;
    }

    if(!valid.size)
        return false;

    // Random is used only to choose among state-valid, non-repeating candidates.
    chosen = valid[RandomInt(valid.size)];
    return self AP_Challenge_SetCurrent(chosen);
}

AP_Challenge_ReevaluateCurrent()
{
    self AP_Challenge_Init();

    if(!IsDefined(self.AP_Challenge["current"]))
        return;

    difficulty = self AP_Challenge_SmartDifficulty();
    definition = self.AP_Challenge["current"];

    // A running challenge is never silently replaced. Difficulty only affects
    // the Director's next selection; current progress remains intact.
    self.AP_Challenge["lastEvaluatedDifficulty"] = difficulty;
    self.AP_Challenge["lastEvaluatedId"] = definition[0];
}

AP_Challenge_OnKill()
{
    if(!IsDefined(self.AP_Challenge["current"]))
        return;

    id = self.AP_Challenge["current"][0];

    if(id == "kills_10" || id == "kills_25" || id == "kino_momentum" || id == "origins_momentum")
        self AP_Challenge_UpdateProgress(1);

    if(id == "streak_10" && self.AP_Stats["killStreak"] >= 10)
        self AP_Challenge_Complete();
}

AP_Challenge_OnRound()
{
    if(!IsDefined(self.AP_Challenge["current"]))
        return;

    if(self.AP_Challenge["current"][0] == "round_survive")
        self AP_Challenge_UpdateProgress(1);
}
