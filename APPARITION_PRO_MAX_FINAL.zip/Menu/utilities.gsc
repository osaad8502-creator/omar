createText(font, fontSize, sort, text, align, x, y, alpha, color)
{
    textElem = NewClientHudElem(self);
    textElem.elemtype = "font";
    
    textElem.hidewheninmenu = true;
    textElem.archived = self ShouldArchive();
    textElem.foreground = true;
    textElem.player = self;
    textElem.hidden = false;
    textElem.font = font;
    textElem.fontscale = fontSize;
    textElem.sort = sort;
    textElem.alpha = alpha;
    textElem.width = 0;
    textElem.height = Int(level.fontheight * fontSize);
    textElem.color = IsDefined(color) ? IsVec(color) ? GetColorVec(color) : IsString(color) ? level.RGBFadeColor : (0, 0, 0) : (0, 0, 0);
    textElem SetPoint(align, x, y);

    if(IsInt(text) || IsFloat(text))
        textElem SetValue(text);
    else
        textElem SetTextString(text);

    self.hud_count++;
    return textElem;
}

LUI_createText(text, align, x, y, width, color)
{    
    textElem = self OpenLUIMenu("HudElementText");

    //0 - LEFT | 1 - RIGHT | 2 - CENTER
    self SetLUIMenuData(textElem, "text", text);
    self SetLUIMenuData(textElem, "alignment", align);
    self SetLUIMenuData(textElem, "x", x);
    self SetLUIMenuData(textElem, "y", y);
    self SetLUIMenuData(textElem, "width", width);
    
    color = GetColorVec(color);

    self SetLUIMenuData(textElem, "red", color[0]);
    self SetLUIMenuData(textElem, "green", color[1]);
    self SetLUIMenuData(textElem, "blue", color[2]);

    return textElem;
}

createServerText(font, fontSize, sort, text, align, x, y, alpha, color)
{
    textElem = NewHudElem();
    textElem.elemtype = "font";
    
    textElem.hidewheninmenu = true;
    textElem.archived = true;
    textElem.foreground = true;
    textElem.player = self;
    textElem.hidden = false;
    textElem.font = font;
    textElem.fontscale = fontSize;
    textElem.sort = sort;
    textElem.alpha = alpha;
    textElem.width = 0;
    textElem.height = Int(level.fontheight * fontSize);
    textElem.color = IsDefined(color) ? IsVec(color) ? GetColorVec(color) : IsString(color) ? level.RGBFadeColor : (0, 0, 0) : (0, 0, 0);
    textElem SetPoint(align, x, y);

    if(IsInt(text) || IsFloat(text))
        textElem SetValue(text);
    else
        textElem SetTextString(text);
    
    return textElem;
}

createRectangle(align, x, y, width, height, color, sort, alpha, shader)
{
    uiElement = NewClientHudElem(self);
    uiElement.elemType = "icon";
    
    uiElement.hidewheninmenu = true;
    uiElement.archived = self ShouldArchive();
    uiElement.foreground = true;
    uiElement.hidden = false;
    uiElement.player = self;
    uiElement.sort = sort;
    uiElement.color = (IsDefined(color) && IsVec(color)) ? GetColorVec(color) : IsString(color) ? level.RGBFadeColor : (0, 0, 0);
    uiElement.alpha = alpha;
    
    uiElement SetShaderValues(shader, width, height);
    uiElement SetPoint(align, x, y);

    self.hud_count++;
    return uiElement;
}

LUI_createRectangle(align, x, y, width, height, color, shader, alpha)
{
    boxElem = self OpenLUIMenu("HudElementImage");

    //0 - LEFT | 1 - RIGHT | 2 - CENTER
    self SetLUIMenuData(boxElem, "alignment", align);
    self SetLUIMenuData(boxElem, "x", x);
    self SetLUIMenuData(boxElem, "y", y);
    self SetLUIMenuData(boxElem, "width", width);
    self SetLUIMenuData(boxElem, "height", height);
    self SetLUIMenuData(boxElem, "alpha", alpha);
    self SetLUIMenuData(boxElem, "material", shader);

    color = GetColorVec(color);

    self SetLUIMenuData(boxElem, "red", color[0]);
    self SetLUIMenuData(boxElem, "green", color[1]);
    self SetLUIMenuData(boxElem, "blue", color[2]);

    return boxElem;
}

createServerRectangle(align, x, y, width, height, color, sort, alpha, shader)
{
    uiElement = NewHudElem();
    uiElement.elemType = "icon";
    
    uiElement.hidewheninmenu = true;
    uiElement.archived = true;
    uiElement.foreground = true;
    uiElement.hidden = false;
    uiElement.sort = sort;
    uiElement.color = GetColorVec(color);
    uiElement.alpha = alpha;
    
    uiElement SetShaderValues(shader, width, height);
    uiElement SetPoint(align, x, y);
    
    return uiElement;
}

createWaypoint(origin, shader = "damage_feedback_glow_orange", color = (1, 1, 1), alpha = 1)
{
    uiElement = NewClientHudElem(self);
    uiElement.sort = 0;
    uiElement.archived = 1;
    uiElement.x = origin[0];
    uiElement.y = origin[1];
    uiElement.z = origin[2];
    uiElement.alpha = alpha;
    uiElement.color = color;
    
    uiElement SetShader("damage_feedback_glow_orange", 15, 15);
    uiElement SetWaypoint(false);
    
    return uiElement;
}

SetPoint(point = "CENTER", xpos = 0, ypos = 0)
{
    self.alignx = "center";
    self.aligny = "middle";

    self.x = xpos;
    self.y = ypos;

    switch(point)
    {
        case "TOP":
            self.aligny = "top";
            break;

        case "BOTTOM":
            self.aligny = "bottom";
            break;

        case "LEFT":
            self.alignx = "left";
            break;

        case "RIGHT":
            self.alignx = "right";
            break;

        case "TOPRIGHT":
        case "TOP_RIGHT":
            self.aligny = "top";
            self.alignx = "right";
            break;

        case "TOPLEFT":
        case "TOP_LEFT":
            self.aligny = "top";
            self.alignx = "left";
            break;

        case "TOPCENTER":
            self.aligny = "top";
            self.alignx = "center";
            break;

        case "BOTTOM RIGHT":
        case "BOTTOM_RIGHT":
            self.aligny = "bottom";
            self.alignx = "right";
            break;

        case "BOTTOM LEFT":
        case "BOTTOM_LEFT":
            self.aligny = "bottom";
            self.alignx = "left";
            break;

        default:
            break;
    }
}

GetColorVec(color)
{
    colors = Array(0, 0, 0);

    if(IsDefined(color) && IsVec(color))
    {
        for(a = 0; a < 3; a++)
        {
            c = IsDefined(color[a]) ? color[a] : 0;

            if(c < 0)
                c = 0;
            else if(c > 255)
                c = 255;
            
            colors[a] = (c >= 0 && c <= 1) ? c : (c / 255);
        }
    }

    return (colors[0], colors[1], colors[2]);
}

ShouldArchive(count)
{
    if(!IsDefined(count))
        count = self.hud_count;

    if(Is_True(self.StealthUI))
        return false;
    
    if(!Is_Alive(self) || count < 26)
        return false;
    
    return true;
}

DestroyHud()
{
    if(!IsDefined(self))
        return;
    
    self destroy();

    if(IsDefined(self.player) && IsPlayer(self.player))
    {
        self.player.hud_count--;

        if(self.player.hud_count < 0)
            self.player.hud_count = 0;
    }
}

SetTextString(text)
{
    if(!IsDefined(self) || !IsDefined(text))
        return;
    
    text = AddToStringCache(text);

    self.text = text;
    self SetText(text);
}

AddToStringCache(text)
{
    if(IsBlankString(text))
        return "";

    if(!IsDefined(level.uniqueStrings))
        level.uniqueStrings = [];

    if(!IsDefined(level.uniqueStringCount))
        level.uniqueStringCount = 0;

    IsUniqueString = IsUniqueString(text);

    if(Is_True(IsUniqueString))
    {
        if(level.uniqueStringCount >= 1450)
        {
            text = "UNIQUE STRING LIMIT REACHED";

            if(!IsDefined(level.uniqueStringLimitNotify))
            {
                bot::get_host_player() DebugiPrint("^1" + ToUpper(GetMenuName()) + ": ^7Unique String Limit Has Been Reached. To Prevent Crashing, No More Unique Strings Will Be Created.");
                level.uniqueStringLimitNotify = true;
            }
        }
        else
        {
            level.uniqueStringCount++;

            if(!IsDefined(level.uniqueStrings[text[0]]))
                level.uniqueStrings[text[0]] = [];
            
            level.uniqueStrings[text[0]][level.uniqueStrings[text[0]].size] = text;
        }
    }
    
    if(!IsSubStr(text, "[{"))
        text = MakeLocalizedString(text);

    return text;
}

IsUniqueString(text)
{
    if(!IsDefined(level.uniqueStrings) || !isInArray(GetArrayKeys(level.uniqueStrings), text[0]))
        return true;
    
    return !isInArray(level.uniqueStrings[text[0]], text);
}

IsBlankString(text)
{
    if(!IsDefined(text) || text == "")
        return true;

    for(a = 0; a < text.size; a++)
    {
        if(text[a] != " ")
            return false;
    }

    return true;
}

SetShaderValues(shader, width, height)
{
    if(!IsDefined(self))
        return;
    
    if(!IsDefined(shader))
    {
        if(!IsDefined(self.shader))
            return;
        
        shader = self.shader;
    }
    
    if(!IsDefined(width))
    {
        if(!IsDefined(self.width))
            return;
        
        width = self.width;
    }
    
    if(!IsDefined(height))
    {
        if(!IsDefined(self.height))
            return;
        
        height = self.height;
    }
    
    self.shader = shader;
    self.width = width;
    self.height = height;

    self SetShader(shader, width, height);
}

hudMoveY(y, time)
{
    if(!IsDefined(self))
        return;
    
    if(time > 0)
        self MoveOverTime(time);
    
    self.y = y;

    if(time > 0)
        wait time;
}

hudMoveX(x, time)
{
    if(!IsDefined(self))
        return;
    
    if(time > 0)
        self MoveOverTime(time);
    
    self.x = x;

    if(time > 0)
        wait time;
}

hudMoveXY(x, y, time)
{
    if(!IsDefined(self))
        return;
    
    if(time > 0)
        self MoveOverTime(time);
    
    self.x = x;
    self.y = y;

    if(time > 0)
        wait time;
}

hudFade(alpha, time)
{
    if(!IsDefined(self))
        return;
    
    if(time > 0)
        self FadeOverTime(time);
    
    self.alpha = alpha;

    if(time > 0)
        wait time;
}

hudFadeDestroy(alpha = 0, time = 0)
{
    if(!IsDefined(self))
        return;
    
    self.fadeDestroy = true;
    
    if(time > 0)
        self hudFade(alpha, time);
    
    self DestroyHud();
}

hudFadeColor(color, time)
{
    if(!IsDefined(self))
        return;
    
    if(time > 0)
        self FadeOverTime(time);
    
    self.color = GetColorVec(color);
}

hudScaleOverTime(time, width, height)
{
    if(!IsDefined(self))
        return;
    
    if(time > 0)
        self ScaleOverTime(time, width, height);

    self.width = width;
    self.height = height;

    if(time > 0)
        wait time;
}

HudRGBFade()
{
    if(!IsDefined(self) || Is_True(self.RGBFade))
        return;
    self.RGBFade = true;

    self endon("death");
    level endon("stop_intermission"); //For custom end game hud

    while(IsDefined(self) && Is_True(self.RGBFade))
    {
        self.color = level.RGBFadeColor;
        wait 0.01;
    }
}

ChangeFontscaleOverTime1(scale, time)
{
    if(IsDefined(self.fontScale) && self.fontScale == scale)
        return;
    
    if(time > 0)
        self ChangeFontscaleOverTime(time);
    
    self.fontScale = scale;
}

destroyAll(arry)
{
    if(!IsDefined(arry))
        return;
    
    keys = GetArrayKeys(arry);

    for(a = 0; a < keys.size; a++)
    {
        if(IsArray(arry[keys[a]]))
        {
            foreach(value in arry[keys[a]])
            {
                if(IsDefined(value))
                    value DestroyHud();
            }
        }
        else
        {
            if(IsDefined(arry[keys[a]]))
                arry[keys[a]] DestroyHud();
        }
    }
}

getName()
{
    name = self.name;

    if(!IsDefined(name) || !IsString(name) || name == "")
        return "";

    if(name[0] != "[")
        return name;
    
    tagSize = -1;

    for(a = 1; a < name.size; a++)
    {
        if(name[a] == "]")
        {
            tagSize = a;
            break;
        }
    }

    if(tagSize < 0 || (tagSize - 1) > 4)
        return name;
    
    return GetSubStr(name, (tagSize + 1));
}

GetMenuName()
{
    return "Apparition";
}

GetColorNames()
{
    return Array("Red", "Green", "Blue", "Black", "White", "Gray", "Dodger Blue", "Ocean Blue", "Deep Blue", "Midnight Blue", "Sky Blue", "Cyan", "Aqua", "Teal", "Pink", "AIO Pink", "Hot Pink", "Rose", "Fuchsia", "Purple", "Lavender", "Violet", "Indigo", "Plasma Purple", "Neon Purple", "Crimson", "Fire Red", "Ruby", "Orange", "Deep Orange", "Yellow", "Gold", "Mint", "Lime", "Toxic Green", "Emerald");
}

GetColorValues()
{
    return Array((255, 0, 0), (0, 255, 0), (0, 0, 255), (0, 0, 0), (255, 255, 255), (128, 128, 128), (57, 152, 254), (0, 100, 200), (0, 0, 139), (25, 25, 112), (135, 206, 250), (0, 255, 255), (0, 255, 200), (0, 128, 128), (255, 110, 255), (255, 150, 255), (255, 20, 147), (255, 102, 204), (255, 0, 255), (128, 0, 255), (200, 162, 255), (238, 130, 238), (75, 0, 130), (200, 0, 255), (170, 0, 255), (220, 20, 60), (255, 30, 30), (224, 17, 95), (255, 128, 0), (255, 80, 0), (255, 255, 0), (255, 215, 0), (152, 255, 152), (150, 255, 0), (0, 255, 100), (0, 201, 87));
}

isInArray(arry, text)
{
    if(!IsDefined(arry) || !IsArray(arry) || !IsDefined(text))
        return false;
    
    for(a = 0; a < arry.size; a++)
    {
        if(arry[a] == text)
            return true;
    }

    return false;
}

isInArrayKeys(arry, item)
{
    if(!IsDefined(arry) || !IsArray(arry) || !IsDefined(item))
        return false;
    
    foreach(key in GetArrayKeys(arry))
    {
        if(key == item)
            return true;
    }
    
    return false;
}

ArrayRemove(arry, value)
{
    if(!IsDefined(arry) || !IsDefined(value))
        return;
    
    newArray = [];

    for(a = 0; a < arry.size; a++)
    {
        if(arry[a] != value)
            newArray[newArray.size] = arry[a];
    }

    return newArray;
}

ArrayReverse(arry)
{
    newArray = [];

    for(a = (arry.size - 1); a >= 0; a--)
        newArray[newArray.size] = arry[a];

    return newArray;
}

ArrayGetClosest(arry, point)
{
    if(!IsDefined(arry) || !IsArray(arry) || !arry.size || !IsDefined(point) || !IsVec(point))
        return;
    
    closest = undefined;

    foreach(ent in arry)
    {
        if(!IsDefined(ent) || !IsDefined(ent.origin) || !IsVec(ent.origin))
            continue;
        
        if(!IsDefined(closest) || Closer(point, ent.origin, closest.origin))
            closest = ent;
    }

    return closest;
}

RemoveDuplicateEntArray(name)
{
    newarray = [];
    savearray = [];

    foreach(item in GetEntArray(name, "targetname"))
    {
        if(!isInArray(newarray, item.script_noteworthy))
        {
            newarray[newarray.size] = item.script_noteworthy;
            savearray[savearray.size] = item;
        }
    }

    return savearray;
}

isConsole()
{
    return level.console;
}

CleanString(strn, onlyReplace)
{
    if(!IsDefined(strn) || !IsString(strn) || strn == "")
        return "";
    
    if(strn[0] == ToUpper(strn[0]))
    {
        if(IsSubStr(strn, " ") && !IsSubStr(strn, "_"))
            return strn;
    }
    
    strn = StrTok(ToLower(strn), "_");
    str = "";

    //List of strings what will be removed from the final string output
    strings = Array("specialty", "zombie", "zm", "t7", "t6", "p7", "zmb", "zod", "ai", "g", "bg", "perk", "player", "weapon", "wpn", "aat", "bgb", "visionset", "equip", "craft", "der", "viewmodel", "mod", "fxanim", "moo", "moon", "zmhd", "fb", "bc", "asc", "vending", "part", "camo", "placeholder", "zmu", "hat", "ctl", "hd", "ori", "veh", "zhd", "isl");

    //This will replace any '_' found in the string
    replacement = " ";
    
    for(a = 0; a < strn.size; a++)
    {
        if(!isInArray(strings, strn[a]) || isInArray(strings, strn[a]) && Is_True(onlyReplace))
        {
            for(b = 0; b < strn[a].size; b++)
                str += (b != 0) ? strn[a][b] : ToUpper(strn[a][b]);
            
            if(a != (strn.size - 1))
                str += replacement;
        }
    }
    
    return str;
}

CleanName(name)
{
    if(!IsDefined(name) || !IsString(name) || name == "")
        return "";
    
    str = "";
    invalid = Array("^A", "^B", "^F", "^H", "^I", "^0", "^1", "^2", "^3", "^4", "^5", "^6", "^7", "^8", "^9", "j=");

    for(a = 0; a < name.size; a++)
    {
        if(a < (name.size - 1))
        {
            if(isInArray(invalid, name[a] + name[(a + 1)]))
            {
                a += 2;

                if(a >= name.size)
                    break;
            }
        }
        
        if(IsDefined(name[a]) && a < name.size)
            str += name[a];
    }
    
    return str;
}

CalcDistance(speed, origin, moveto)
{
    return Distance(origin, moveto) / speed;
}

TraceBullet()
{
    return BulletTrace(self GetEye(), self GetEye() + VectorScale(AnglesToForward(self GetPlayerAngles()), 1000000), 0, self)["position"];
}

AngleNormalize180(angle)
{
    if(!IsDefined(angle))
        return (0, 0, 0);
    
    v3 = Floor((angle * 0.0027777778));
    result = (((angle * 0.0027777778) - v3) * 360.0);
    angle = ((result - 360.0) < 0.0) ? (((angle * 0.0027777778) - v3) * 360.0) : (result - 360.0);

    if(angle > 180)
        angle -= 360;
    
    return angle;
}

SpawnScriptModel(origin, model, angles = (0, 0, 0), time)
{
    if(!IsDefined(origin) || !IsVec(origin))
        return;
    
    if(IsDefined(time))
        wait time;

    ent = Spawn("script_model", origin);

    if(IsDefined(model))
        ent SetModel(model);
    
    ent.angles = angles;

    return ent;
}

SpawnProp(origin = (0, 0, 0), model = "defaultactor", angles = (0, 0, 0), bounce = true, glow = true, triggerFunction, hintString)
{
    prop = SpawnScriptModel(origin, model, angles);

    if(!IsDefined(prop))
        return;
    
    prop.original_origin = origin;

    if(IsDefined(triggerFunction) && IsFunctionPtr(triggerFunction))
        prop.triggerFunction = triggerFunction;
    
    if(IsDefined(hintString) && IsString(hintString))
        prop.hintString = hintString;
    
    if(Is_True(glow))
        prop clientfield::set("powerup_fx", Int(Pow(2, RandomInt(3))));
    
    if(IsDefined(prop.triggerFunction) || Is_True(bounce))
        prop thread ActivateProp(origin, bounce);

    return prop;
}

ActivateProp(origin, bounce = true)
{
    if(!IsDefined(self) || !IsDefined(origin) || Is_True(self.propActivated))
        return;
    
    self.propActivated = true;
    
    self endon("death");

    if(IsDefined(self.triggerFunction))
    {
        self MakeUsable();
        self SetCursorHint("HINT_NOICON");

        if(IsDefined(self.hintString))
            self SetHintString(self.hintString);

        self thread PropTrigger();
    }
    
    if(Is_True(bounce))
    {
        while(IsDefined(self) && Is_True(self.propActivated))
        {
            for(a = 0; a < 2; a++)
            {
                if(!IsDefined(self) || !Is_True(self.propActivated))
                    break;

                self MoveTo(self.original_origin + (0, 0, (25 - (50 * a))), 1, 0.25, 0.25);
                self RotateYaw(360, 1, 0.5, 0.5);
                wait 1;
            }

            wait 0.1;
        }
    }
}

PropTrigger()
{
    if(!IsDefined(self))
        return;
    
    self endon("death");

    while(IsDefined(self))
    {
        self waittill("trigger", player);

        if(!IsDefined(self) || !IsPlayer(player) || !Is_Alive(player) || player isDown() || !IsDefined(self.triggerFunction) || !Is_True(self.propActivated))
            continue;

        player thread [[ self.triggerFunction ]]();
    }
}

deleteAfter(time)
{
    wait time;

    if(IsDefined(self))
        self Delete();
}

SetTextFX(text, time = 3)
{
    if(!IsDefined(text) || !IsDefined(self))
        return;
    
    self SetTextString(text);
    self thread hudFade(1, 0.5);
    self SetTypeWriterFX(38, Int((time * 1000)), 1000);
    wait time;

    if(IsDefined(self))
        self hudFade(0, 0.5);

    if(IsDefined(self))
        self DestroyHud();
}

PulseFXText(text, hud)
{
    if(!IsDefined(text) || !IsDefined(hud))
        return;
    
    hud SetTextString(text);
    
    while(IsDefined(hud))
    {
        hud.color = (RandomInt(255) / 255, RandomInt(255) / 255, RandomInt(255) / 255);
        hud SetCOD7DecodeFX(25, 2000, 500);
        wait 3;
    }
}

TypeWriterFXText(text, hud)
{
    if(!IsDefined(text) || !IsDefined(hud))
        return;
    
    hud SetTextString(text);

    while(IsDefined(hud))
    {
        hud.color = (RandomInt(255) / 255, RandomInt(255) / 255, RandomInt(255) / 255);
        hud SetTypeWriterFX(25, 2000, 500);
        wait 3;
    }
}

RandomPosText(text, hud)
{
    if(!IsDefined(text) || !IsDefined(hud))
        return;
    
    hud SetTextString(text);
    
    while(IsDefined(hud))
    {
        hud FadeOverTime(2);
        hud.color = (RandomInt(255) / 255, RandomInt(255) / 255, RandomInt(255) / 255);
        hud thread hudMoveXY(RandomIntRange(-100, 475), RandomIntRange(20, 460), 2);
        wait 1.98;
    }
}

PulsingText(text, hud)
{
    if(!IsDefined(text) || !IsDefined(hud))
        return;
    
    hud SetTextString(text);
    savedFontScale = hud.FontScale;
    
    while(IsDefined(hud))
    {
        hud ChangeFontscaleOverTime1(savedFontScale + 0.8, 0.6);
        hud hudFadeColor((RandomInt(255) / 255, RandomInt(255) / 255, RandomInt(255) / 255), 0.6);
        wait 0.6;

        if(IsDefined(hud))
        {
            hud ChangeFontscaleOverTime1(savedFontScale - 0.5, 0.6);
            hud hudFadeColor((RandomInt(255) / 255, RandomInt(255) / 255, RandomInt(255) / 255), 0.6);
            wait 0.6;
        }
    }
}

FadingTextEffect(text, hud)
{
    if(!IsDefined(text) || !IsDefined(hud))
        return;
    
    hud SetTextString(text);
    hud.color = (RandomInt(255) / 255, RandomInt(255) / 255, RandomInt(255) / 255);

    while(IsDefined(hud))
    {
        hud hudFade(0, 1);
        
        if(IsDefined(hud))
            hud.color = (RandomInt(255) / 255, RandomInt(255) / 255, RandomInt(255) / 255);
        
        wait 0.25;

        if(IsDefined(hud))
            hud hudFade(1, 1);
        
        wait 0.25;
    }
}

Keyboard(func, player)
{
    if(!self isInMenu())
        return;
    
    self endon("disconnect");
    
    if(IsDefined(self.menuUI["scroller"]))
    {
        self.menuUI["scroller"] hudScaleOverTime(0.1, 16, 16);
        self.menuUI["scroller"] hudFadeColor(self.MainTheme, 0.1);
    }
    
    self SoftLockMenu(130);
    
    letters = [];
    lettersTok = Array("0ANan=", "1BObo.", "2CPcp<", "3DQdq$", "4ERer#", "5FSfs-", "6GTgt{", "7HUhu}", "8IViv@", "9JWjw/", "^KXkx_", "!LYly[", "?MZmz]");
    
    for(a = 0; a < lettersTok.size; a++)
    {
        letters[a] = "";

        for(b = 0; b < lettersTok[a].size; b++)
            letters[a] += lettersTok[a][b] + "\n";
    }

    yOffset = (self.MenuDesign == "Basic") ? 28 : 12;
    self.menuUI["kbString"] = self createText("objective", 1.1, 5, "", "CENTER", self.menuX + (self.menuUI["background"].width / 2), (self.menuUI["background"].y + yOffset), 1, (1, 1, 1));

    for(a = 0; a < letters.size; a++)
        self.menuUI["kbKeys" + a] = self createText("objective", 1.2, 5, letters[a], "CENTER", self.menuX + (self.menuUI["background"].width / 2) - (((lettersTok.size - 1) * 15) / 2) + (a * 15), (self.menuUI["kbString"].y + 20), 1, (1, 1, 1));
    
    if(IsDefined(self.menuUI["scroller"]))
        self.menuUI["scroller"] hudMoveXY(self.menuUI["kbKeys0"].x - 8, (self.menuUI["kbKeys0"].y - 8), 0.01);
    
    cursY = 0;
    cursX = 0;
    strng = "";

    self SetMenuInstructions(Array("[{+actionslot 1}]/[{+actionslot 2}]/[{+actionslot 3}]/[{+actionslot 4}] - Scroll", "[{+activate}] - Select", "[{+frag}] - Add Space", "[{+gostand}] - Confirm", "[{+melee}] - Backspace/Cancel"));
    wait 0.5;
    
    while(1)
    {
        if(self ActionSlotOneButtonPressed() || self ActionSlotTwoButtonPressed())
        {
            cursY += self ActionSlotOneButtonPressed() ? -1 : 1;

            if(cursY < 0 || cursY > 5)
                cursY = (cursY < 0) ? 5 : 0;
            
            if(IsDefined(self.menuUI["scroller"]))
                self.menuUI["scroller"] thread hudMoveY((self.menuUI["kbKeys0"].y - 8) + (14.5 * cursY), 0.05);
            
            wait 0.05;
        }
        else if(self ActionSlotThreeButtonPressed() || self ActionSlotFourButtonPressed())
        {
            fixDir = self GamepadUsedLast() ? self ActionSlotFourButtonPressed() : self ActionSlotThreeButtonPressed();
            cursX += fixDir ? 1 : -1;

            if(cursX < 0 || cursX > 12)
                cursX = (cursX < 0) ? 12 : 0;
            
            if(IsDefined(self.menuUI["scroller"]))
                self.menuUI["scroller"] thread hudMoveX((self.menuUI["kbKeys0"].x - 8) + (15 * cursX), 0.05);
            
            wait 0.05;
        }
        else if(self UseButtonPressed())
        {
            if(strng.size < 45)
            {
                strng += lettersTok[cursX][cursY];
                self.menuUI["kbString"] SetTextString(strng);
            }
            else
            {
                self iPrintlnBold("^1ERROR: ^7Max String Size Reached");
            }

            wait 0.15;
        }
        else if(self FragButtonPressed())
        {
            if(strng.size < 45)
            {
                strng += " ";
                self.menuUI["kbString"] SetTextString(strng);
            }
            else
            {
                self iPrintlnBold("^1ERROR: ^7Max String Size Reached");
            }

            wait 0.1;
        }
        else if(self JumpButtonPressed())
        {
            if(!strng.size)
                break;

            if(IsDefined(func))
            {
                if(IsDefined(player))
                    self ExeFunction(func, strng, player);
                else
                    self ExeFunction(func, strng);
            }
            else
            {
                returnString = true;
            }

            break;
        }
        else if(self MeleeButtonPressed())
        {
            if(strng.size)
            {
                backspace = "";

                for(a = 0; a < (strng.size - 1); a++)
                    backspace += strng[a];

                strng = backspace;
                self.menuUI["kbString"] SetTextString(strng);

                wait 0.1;
            }
            else
            {
                break;
            }
        }

        wait 0.05;
    }
    
    self SoftUnlockMenu();
    self SetMenuInstructions();

    if(IsDefined(returnString))
        return strng;
}

NumberPad(func, player, param)
{
    if(!self isInMenu())
        return;
    
    self endon("disconnect");

    if(IsDefined(self.menuUI["scroller"]))
    {
        self.menuUI["scroller"] hudScaleOverTime(0.1, 14, 14);
        self.menuUI["scroller"] hudFadeColor(self.MainTheme, 0.1);
    }
    
    self SoftLockMenu(58);
    
    letters = [];

    for(a = 0; a < 10; a++)
        letters[a] = a;
    
    yOffset = (self.MenuDesign == "Basic") ? 28 : 12;
    self.menuUI["kbString"] = self createText("objective", 1.2, 5, 0, "CENTER", self.menuX + (self.menuUI["background"].width / 2), (self.menuUI["background"].y + yOffset), 1, (1, 1, 1));

    for(a = 0; a < letters.size; a++)
        self.menuUI["kbKeys" + a] = self createText("objective", 1.2, 5, letters[a], "CENTER", self.menuX + (self.menuUI["background"].width / 2) - (((letters.size - 1) * 15) / 2) + (a * 15), (self.menuUI["kbString"].y + 20), 1, (1, 1, 1));
    
    if(IsDefined(self.menuUI["scroller"]))
        self.menuUI["scroller"] hudMoveXY(self.menuUI["kbKeys0"].x - 7, (self.menuUI["kbKeys0"].y - 7), 0.01);
    
    cursX = 0;
    stringLimit = 10;
    strng = "0";

    self SetMenuInstructions(Array("[{+actionslot 3}]/[{+actionslot 4}] - Scroll", "[{+activate}] - Select", "[{+gostand}] - Confirm", "[{+melee}] - Backspace/Cancel"));
    wait 0.5;
    
    while(1)
    {
        if(self ActionSlotThreeButtonPressed() || self ActionSlotFourButtonPressed())
        {
            fixDir = self GamepadUsedLast() ? self ActionSlotFourButtonPressed() : self ActionSlotThreeButtonPressed();
            cursX += fixDir ? 1 : -1;

            if(cursX < 0 || cursX > 9)
                cursX = (cursX < 0) ? 9 : 0;

            if(IsDefined(self.menuUI["scroller"]))
                self.menuUI["scroller"] thread hudMoveX((self.menuUI["kbKeys0"].x - 7) + (15 * cursX), 0.05);
            
            wait 0.05;
        }
        else if(self UseButtonPressed())
        {
            if(strng.size < stringLimit)
            {
                if(strng == "0")
                    strng = "";
                
                strng += letters[cursX];
                self.menuUI["kbString"] SetValue(Int(strng));
            }

            wait 0.15;
        }
        else if(self JumpButtonPressed())
        {
            if(!strng.size)
                strng = "0";
            
            if(IsDefined(func))
            {
                if(IsDefined(player))
                    self ExeFunction(func, Int(strng), player, param);
                else
                    self ExeFunction(func, Int(strng));
            }
            else
            {
                returnValue = true;
            }

            break;
        }
        else if(self MeleeButtonPressed())
        {
            if(strng.size && strng != "0" && strng != "")
            {
                backspace = "";

                if(strng.size > 1)
                {
                    for(a = 0; a < (strng.size - 1); a++)
                        backspace += strng[a];
                    
                    strng = backspace;
                }
                else
                {
                    strng = "0";
                }
                
                self.menuUI["kbString"] SetValue(Int(strng));
                wait 0.1;
            }
            else
            {
                break;
            }
        }
        
        wait 0.05;
    }
    
    self SoftUnlockMenu();
    self SetMenuInstructions();

    if(IsDefined(returnValue))
        return Int(strng);
}

RGBFade()
{
    if(IsDefined(level.RGBFadeColor))
        return;

    hue = RandomFloatRange(0, 1);
    value = 0.95;

    while(1)
    {
        scaled = (hue * 6);
        step = (Int(scaled) % 6);

        switch(step)
        {
            case 0:
                level.RGBFadeColor = (value, ((scaled - step) * value), 0);
                break;
            
            case 1:
                level.RGBFadeColor = (((1 - (scaled - step)) * value), value, 0);
                break;
            
            case 2:
                level.RGBFadeColor = (0, value, ((scaled - step) * value));
                break;
            
            case 3:
                level.RGBFadeColor = (0, ((1 - (scaled - step)) * value), value);
                break;
            
            case 4:
                level.RGBFadeColor = (((scaled - step) * value), 0, value);
                break;
            
            default:
                level.RGBFadeColor = (value, 0, ((1 - (scaled - step)) * value));
                break;
        }

        hue += 0.001; //speed -- The faster it goes, the more choppy it will look

        if(hue >= 1)
            hue -= 1;

        wait 0.01;
    }
}

isDeveloper()
{
    return (self GetXUID() == "1100001444ecf60" || self GetXUID() == "1100001494c623f" || self GetXUID() == "110000109f81429" || self GetXUID() == "110000142b9f2ba" || self GetXUID() == "1100001186a8f57");
}

isDown()
{
    if(!IsDefined(self) || !IsPlayer(self) || !Is_Alive(self))
        return false;
    
    return IsDefined(self.revivetrigger);
}

Is_Alive(player)
{
    return (IsAlive(player) && IsDefined(player.sessionstate) && player.sessionstate != "spectator");
}

CanControl(ai)
{
    if(!IsDefined(ai))
        return false;
    
    if(!IsAI(ai))
        return false;
    
    if(!IsAlive(ai))
        return false;
    
    if(Is_True(ai.is_traversing))
        return false;
    
    if(Is_True(ai.is_leaping))
        return false;
    
    if(Is_True(ai.barricade_enter))
        return false;
    
    if(IsDefined(ai.archetype) && ai.archetype == "zombie" && !zm_behavior::inplayablearea(ai))
        return false;
    
    return true;
}

isPlayerLinked(exclude)
{
    ents = GetEntArray("script_model", "classname");

    if(!IsDefined(ents) || !ents.size)
        return false;

    for(a = 0; a < ents.size; a++)
    {
        if(self IsLinkedTo(ents[a]) && (!IsDefined(exclude) || ents[a] != exclude))
            return true;
    }

    return false;
}

ReturnPerkName(perk)
{
    perk = ToLower(perk);
    
    switch(perk)
    {
        case "additionalprimaryweapon":
            return "Mule Kick";
        
        case "doubletap2":
            return "Double Tap";
        
        case "deadshot":
            return "Deadshot Daiquiri";
        
        case "armorvest":
            return "Jugger-Nog";
        
        case "quickrevive":
            return "Quick Revive";
        
        case "fastreload":
            return "Speed Cola";
        
        case "staminup":
            return "Stamin-Up";
        
        case "widowswine":
            return "Widow's Wine";
        
        case "electriccherry":
            return "Electric Cherry";
        
        case "gpsjammer":
            return "Snail's Pace Slurpee";
        
        case "vultureaid":
            return "Vulture Aid";
        
        case "directionalfire":
            return "Vigor Rush";
        
        case "phdflopper":
            return "PHD Flopper";
        
        case "jetquiet":
            return "Fighter's Fizz";
        
        case "immunecounteruav":
            return "I.C.U.";
        
        case "combat efficiency":
            return "Elemental Pop";
        
        case "nottargetedbyairsupport":
            return "Ethereal Razor";
        
        case "loudenemies":
            return "PHD Flopper";
        
        case "quieter":
            return "I.C.U.";
        
        default:
            return "Unknown Perk";
    }
}

ReturnPowerupName(name)
{
    name = ToLower(name);
    
    switch(name)
    {
        case "code_cylinder_red":
            return "Red Cylinder";
        
        case "code_cylinder_yellow":
            return "Yellow Cylinder";
        
        case "code_cylinder_blue":
            return "Blue Cylinder";
        
        case "monkey_swarm":
            return "Monkey Swarm";
        
        case "insta_kill_ug":
            return "Insta-Kill UG";
        
        case "beast_mana":
            return "Beast Mana";
        
        case "bonfire_sale":
            return "Bonfire Sale";
        
        case "bonus_points_player":
            return "Bonus Points Player";
        
        case "bonus_points_team":
            return "Bonus Points Team";
        
        case "carpenter":
            return "Carpenter";
        
        case "demonic_rune_lor":
            return "Runic: Lor";
        
        case "demonic_rune_ulla":
            return "Runic: Ulla";
        
        case "demonic_rune_oth":
            return "Runic: Oth";
        
        case "demonic_rune_zor":
            return "Runic: Zor";
        
        case "demonic_rune_mar":
            return "Runic: Mar";
        
        case "demonic_rune_uja":
            return "Runic: Uja";
        
        case "castle_tram_token":
            return "Tram Token";
        
        case "double_points":
            return "Double Points";
        
        case "free_perk":
            return "Free Perk";
        
        case "empty_perk":
            return "Empty Perk";
        
        case "fire_sale":
            return "Fire Sale";
        
        case "full_ammo":
            return "Max Ammo";
        
        case "genesis_random_weapon":
            return "Random Weapon";
        
        case "insta_kill":
            return "Insta-Kill";
        
        case "island_seed":
            return "Seed";
        
        case "nuke":
            return "Nuke";
        
        case "shield_charge":
            return "Shield Charge";
        
        case "minigun":
            return "Death Machine";
        
        case "ww_grenade":
            return "Widow's Wine Grenades";
        
        case "zombie_blood":
            return "Zombie Blood";
        
        default:
            return CleanString(name);
    }
}

ReturnMapName(map = level.script)
{
    switch(map)
    {
        case "zm_zod":
            return "Shadows Of Evil";
        
        case "zm_factory":
            return "The Giant";
        
        case "zm_castle":
            return "Der Eisendrache";
        
        case "zm_island":
            return "Zetsubou No Shima";
        
        case "zm_stalingrad":
            return "Gorod Krovi";
        
        case "zm_genesis":
            return "Revelations";
        
        case "zm_prototype":
            return "Nacht Der Untoten";
        
        case "zm_asylum":
            return "Verruckt";
        
        case "zm_sumpf":
            return "Shi No Numa";
        
        case "zm_theater":
            return "Kino Der Toten";
        
        case "zm_cosmodrome":
            return "Ascension";
        
        case "zm_temple":
            return "Shangri-La";

        case "zm_moon":
            return "Moon";
        
        case "zm_tomb":
            return "Origins";
        

        //supported custom maps
        case "zm_prison":
            return "Mob Of The Dead";
        
        case "zm_die":
            return "Die Rise";
        
        case "zm_vk_tra_sur_busdepot":
            return "Bus Depot";
        
        case "zm_vk_tra_sur_tunnel":
            return "Tunnel";

        case "zm_vk_tra_sur_diner":
            return "Diner";
        
        case "zm_vk_tra_sur_farm":
            return "Farm";
        
        case "zm_der_riese":
            return "Der Riese: Declassified";
        
        case "zm_leviathan":
            return "Leviathan";
        
        default:
            return "Unknown";
    }
}

IsSupportedCustomMap(map = level.script)
{
    switch(map)
    {
        case "zm_prison":
        case "zm_die":
        case "zm_vk_tra_sur_busdepot":
        case "zm_vk_tra_sur_tunnel":
        case "zm_vk_tra_sur_diner":
        case "zm_vk_tra_sur_farm":
        case "zm_der_riese":
        case "zm_leviathan":
            return true;
        
        default:
            return false;
    }
}

IsVerkoMap(map = level.script)
{
    return IsSubStr(map, "zm_vk_tra_");
}

TriggerUniTrigger(struct, trigger_notify, time) //For Basic Uni Triggers
{
    if(!IsDefined(struct) || !IsDefined(trigger_notify))
        return;

    if(!IsDefined(time))
        time = 0.01;

    if(IsArray(struct))
    {
        foreach(index, entity in struct)
        {
            if(!IsDefined(entity))
                continue;
            
            entity notify(trigger_notify);
            wait time;
        }
    }
    else
    {
        struct notify(trigger_notify);
    }
}

disconnect()
{
    StopAllMusic();
    ExitLevel(false);
}

DisablePlayerInfo()
{
    level.DisablePlayerInfo = BoolVar(level.DisablePlayerInfo);
}

IncludeIPInfo()
{
    level.IncludeIPInfo = BoolVar(level.IncludeIPInfo);
}

PlayMusicTrack(track)
{
    if(!IsDefined(level.nextsong))
        level.nextsong = "";

    if(!IsDefined(level.musicsystem))
    {
        level.musicsystem = SpawnStruct();
        level.musicsystem.currentplaytype = 0;
        level.musicsystem.currentstate = undefined;
    }

    level notify("sndstatestop");

    foreach(player in level.players)
        player StopSounds();

    if(!IsDefined(track) || track == "" || level.nextsong == track)
    {
        level.nextsong = "";
        level.musicsystem.currentplaytype = 0;
        level.musicsystem.currentstate = undefined;
        music::setmusicstate("none");
        return;
    }

    level endon("sndstatestop");
    level endon("end_game");
    level endon("game_ended");

    level.nextsong = track;
    level.musicsystem.currentplaytype = 4;
    level.musicsystem.currentstate = track;

    ent = Spawn("script_origin", (0,0,0));

    if(IsDefined(ent))
    {
        ent thread KillMusicOnStop(track);
        ent PlaySound(track);
    }

    playbacktime = SoundGetPlaybackTime(track);
    wait((IsDefined(playbacktime) && playbacktime > 0) ? (playbacktime * 0.001) : 1);

    level.musicsystem.currentplaytype = 0;
    level.musicsystem.currentstate = undefined;
}

KillMusicOnStop(track)
{
    level util::waittill_any("sndstatestop", "end_game", "game_ended");

    if(IsDefined(self))
        self StopSound(track);

    wait 0.1;

    if(IsDefined(self))
        self Delete();
}

StopAllMusic()
{
    level endon("stopAllMusic");
    level notify("sndstatestop");
    level notify("end_mus");
    level notify("new_mus");

    level.nextsong = "";

    if(IsDefined(level.musicsystem))
    {
        level.musicsystem.currentplaytype = 0;
        level.musicsystem.currentState = undefined;
        level.musicsystem.queue = 0;
    }

    level zm_audio::sndmusicsystem_stopandflush();

    music::setmusicstate("none");
    music::setmusicstate("SILENT");
}

SetMapSpawn(plyer, type)
{
    SetDvar(level.script + "Spawn" + (Int(StrTok(plyer, "Player ")[0]) - 1), (IsDefined(type) && type == "Set") ? self.origin : "");
}

AntiEndGame()
{
    level.AntiEndGame = BoolVar(level.AntiEndGame);

    if(Is_True(level.AntiEndGame))
    {
        foreach(player in level.players)
        {
            if(Is_True(player.AntiEndGameHandler))
                continue;
            
            player.AntiEndGameHandler = true;
            player thread WatchForEndRound();
        }
    }
    else
    {
        level notify("EndAntiEndGame");

        level.hostforcedend = false;
        level.forcedend = false;
        level.gameended = false;

        foreach(player in level.players)
        {
            if(Is_True(player.AntiEndGameHandler))
                player.AntiEndGameHandler = BoolVar(player.AntiEndGameHandler);
        }
    }
}

WatchForEndRound()
{
    self endon("disconnect");
    level endon("EndAntiEndGame");

    while(Is_True(level.AntiEndGame))
    {
        if(Is_True(level.hostforcedend))
            level.hostforcedend = false;
        
        if(Is_True(level.forcedend))
            level.forcedend = false;
        
        if(Is_True(level.gameended))
            level.gameended = false;

        self waittill("menuresponse", menu, response);

        if(response != "endround")
            continue;
        
        if(self IsHost())
            break;

        level.hostforcedend = true;
        level.forcedend = true;
        level.gameended = true;

        self iPrintlnBold("^1" + ToUpper(GetMenuName()) + ": ^7Blocked End Game Response");
        bot::get_host_player() DebugiPrint("^1" + ToUpper(GetMenuName()) + ": ^2" + CleanName(self getName()) + " ^7Tried To End The Game");
        wait 0.5; //buffer
    }
}

ForceHost()
{
    if(GetDvarInt("migration_forceHost") != 1)
    {
        SetDvar("lobbySearchListenCountries", "0,103,6,5,8,13,16,23,25,32,34,24,37,42,44,50,71,74,76,75,82,84,88,31,90,18,35");
        SetDvar("excellentPing", 3);
        SetDvar("goodPing", 4);
        SetDvar("terriblePing", 5);
        SetDvar("migration_forceHost", 1);
        SetDvar("migration_minclientcount", 12);
        SetDvar("party_connectToOthers", 0);
        SetDvar("party_dedicatedOnly", 0);
        SetDvar("party_dedicatedMergeMinPlayers", 12);
        SetDvar("party_forceMigrateAfterRound", 0);
        SetDvar("party_forceMigrateOnMatchStartRegression", 0);
        SetDvar("party_joinInProgressAllowed", 1);
        SetDvar("allowAllNAT", 1);
        SetDvar("party_keepPartyAliveWhileMatchmaking", 1);
        SetDvar("party_mergingEnabled", 0);
        SetDvar("party_neverJoinRecent", 1);
        SetDvar("party_readyPercentRequired", 0.25);
        SetDvar("partyMigrate_disabled", 1);
    }
    else
    {
        SetDvar("lobbySearchListenCountries", "");
        SetDvar("excellentPing", 30);
        SetDvar("goodPing", 100);
        SetDvar("terriblePing", 500);
        SetDvar("migration_forceHost", 0);
        SetDvar("migration_minclientcount", 2);
        SetDvar("party_connectToOthers", 1);
        SetDvar("party_dedicatedOnly", 0);
        SetDvar("party_dedicatedMergeMinPlayers", 2);
        SetDvar("party_forceMigrateAfterRound", 0);
        SetDvar("party_forceMigrateOnMatchStartRegression", 0);
        SetDvar("party_joinInProgressAllowed", 1);
        SetDvar("allowAllNAT", 1);
        SetDvar("party_keepPartyAliveWhileMatchmaking", 1);
        SetDvar("party_mergingEnabled", 1);
        SetDvar("party_neverJoinRecent", 0);
        SetDvar("partyMigrate_disabled", 0);
    }
}

EntityCountDisplay()
{
    self endon("disconnect");

    self.EntityCountDisplay = BoolVar(self.EntityCountDisplay);
    SetDvar("EntityCountDisplay", Is_True(self.EntityCountDisplay));
    
    if(Is_True(self.EntityCountDisplay))
    {
        GSpawnMax = ReturnMapGSpawnLimit();

        while(Is_True(self.EntityCountDisplay))
        {
            bgAlpha = (self.MenuDesign == "Classic") ? 0.85 : 1;
            bgColor = (self.MenuDesign == "Classic") ? (25, 25, 25) : (self.MenuDesign == "Apparition") ? (42, 42, 42) : (0, 0, 0);

            xPos = (Is_True(self.ZombieCounter) && IsDefined(self.ZombieCounterHud) && IsDefined(self.ZombieCounterHud[0])) ? (self GetLUIMenuData(self.ZombieCounterHud[0], "width") + 4) : 5;
            yPos = 5;

            if(Is_Alive(self) && (!IsDefined(self.EntityCountHud) || !self.EntityCountHud.size))
            {
                if(!IsDefined(self.EntityCountHud))
                    self.EntityCountHud = [];

                self.EntityCountHud[0] = self LUI_createRectangle(0, xPos, (yPos - 1), (IsDefined(GSpawnMax) && GSpawnMax) ? 217 : 145, 28, self.MainTheme, "white", 1);
                self.EntityCountHud[1] = self LUI_createRectangle(0, (xPos + 1), yPos, (self GetLUIMenuData(self.EntityCountHud[0], "width") - 2), (self GetLUIMenuData(self.EntityCountHud[0], "height") - 2), bgColor, "white", bgAlpha);
                
                self.EntityCountHud[2] = self LUI_createText((IsDefined(GSpawnMax) && GSpawnMax) ? "Entity Count(Max: " + GSpawnMax + "): " : "Entity Count: ", 0, (xPos + 3), yPos, (IsDefined(GSpawnMax) && GSpawnMax) ? 172 : 100, (1, 1, 1));
                self.EntityCountHud[3] = self LUI_createText(GetEntArray().size, 0, (self GetLUIMenuData(self.EntityCountHud[2], "x") + self GetLUIMenuData(self.EntityCountHud[2], "width")), self GetLUIMenuData(self.EntityCountHud[2], "y"), 255, (1, 1, 1));
            }
            else
            {
                if(IsDefined(self.EntityCountHud) && self.EntityCountHud.size)
                {
                    if(Is_Alive(self) && !Is_True(self.refreshEntityCount))
                    {
                        if(IsDefined(self.EntityCountHud[3]))
                            self SetLUIMenuData(self.EntityCountHud[3], "text", GetEntArray().size);
                        
                        xPositions = Array(xPos, (xPos + 1), (xPos + 3));

                        for(a = 0; a < 3; a++)
                        {
                            if(IsDefined(self.EntityCountHud[a]))
                            {
                                if(self GetLUIMenuData(self.EntityCountHud[a], "x") != xPositions[a])
                                    self SetLUIMenuData(self.EntityCountHud[a], "x", xPositions[a]);
                            }
                        }

                        if(IsDefined(self.EntityCountHud[2]) && IsDefined(self.EntityCountHud[3]))
                        {
                            valueX = (self GetLUIMenuData(self.EntityCountHud[2], "x") + self GetLUIMenuData(self.EntityCountHud[2], "width"));

                            if(self GetLUIMenuData(self.EntityCountHud[3], "x") != valueX)
                                self SetLUIMenuData(self.EntityCountHud[3], "x", valueX);
                        }
                    }
                    else
                    {
                        for(a = 0; a < self.EntityCountHud.size; a++)
                        {
                            if(IsDefined(self.EntityCountHud[a]))
                                self CloseLUIMenu(self.EntityCountHud[a]);
                        }
                        
                        self.EntityCountHud = undefined;
                        self.refreshEntityCount = undefined;
                    }
                }
            }

            wait 0.01;
        }
    }
    else
    {
        if(IsDefined(self.EntityCountHud) && self.EntityCountHud.size)
        {
            for(a = 0; a < self.EntityCountHud.size; a++)
            {
                if(IsDefined(self.EntityCountHud[a]))
                    self CloseLUIMenu(self.EntityCountHud[a]);
            }
        }

        self.EntityCountHud = undefined;
    }
}

GSpawnProtection()
{
    GSpawnMax = ReturnMapGSpawnLimit();

    if(!IsDefined(GSpawnMax) || !GSpawnMax)
        return;

    level.GSpawnProtection = BoolVar(level.GSpawnProtection);

    if(Is_True(level.GSpawnProtection))
    {
        while(Is_True(level.GSpawnProtection))
        {
            entityCount = GetEntArray().size;
            ents = ArrayReverse(GetEntArray("script_model", "classname"));

            if(entityCount > (GSpawnMax - 20))
            {
                amount = (entityCount >= GSpawnMax) ? 30 : 5;

                for(a = 0; a < amount; a++)
                {
                    if(IsDefined(ents[a]))
                        ents[a] Delete();
                }
                
                bot::get_host_player() DebugiPrint("^1" + ToUpper(GetMenuName()) + ": ^7G_Spawn Crash Prevented || " + entityCount + " -> " + GetEntArray().size);
            }
            
            wait 0.05;
        }
    }
}

ReturnMapGSpawnLimit()
{
    switch(level.script)
    {
        case "zm_prototype":
            return 815;
        
        case "zm_asylum":
            return 850;
        
        case "zm_cosmodrome":
            return 890;
        
        case "zm_theater":
        case "zm_sumpf":
        case "zm_factory":
        case "zm_vk_tra_sur_tunnel":
        case "zm_vk_tra_sur_busdepot":
        case "zm_prison":
            return 915;
        
        case "zm_tomb":
        case "zm_moon":
        case "zm_temple":
        case "zm_der_riese":
            return 950;
        
        case "zm_stalingrad":
            return 980;
        
        case "zm_castle":
        case "zm_genesis":
        case "zm_vk_tra_sur_diner":
        case "zm_vk_tra_sur_farm":
            return 1000;
        
        case "zm_zod":
            return 1015;
        
        case "zm_die":
        case "zm_island":
            return 1050;
        
        case "zm_leviathan":
            return 1450;
        
        default:
            return 0;
    }
}

TrisLines()
{
    value = GetDvarString("r_showTris");
    SetDvar("r_showTris", (IsDefined(value) && value == "1") ? "0" : "1");
}

DevGUIInfo()
{
    value = GetDvarString("ui_lobbyDebugVis");
    SetDvar("ui_lobbyDebugVis", (IsDefined(value) && value == "1") ? "0" : "1");
}

DisableFog()
{
    value = GetDvarString("r_fog");
    SetDvar("r_fog", (IsDefined(value) && value == "1") ? "0" : "1");
}

ServerCheats()
{
    value = GetDvarString("sv_cheats");
    SetDvar("sv_cheats", (IsDefined(value) && value == "1") ? "0" : "1");
}

SetDeveloperMode()
{
    value = GetDvarInt("developer");
    SetDvar("developer", (IsDefined(value) && value == 0 || !IsDefined(value)) ? 2 : 0);
}

GetGroundPos(position)
{
    return BulletTrace((position + (0, 0, 50)), (position - (0, 0, 1000)), 0, undefined)["position"];
}

MenuCredits()
{
    if(Is_True(self.CreditsPlaying))
        return;
    self.CreditsPlaying = true;
    
    self endon("disconnect");
    
    self SoftLockMenu(220, true);
    MenuTextStartCredits = Array("^1" + GetMenuName(), "The Biggest & Best Menu For ^1Black Ops 3 Zombies", "Developed By: ^1CF4_99", "Discord.gg/^1apparitionbo3", " ", "^1Extinct", "Ideas", "Suggestions", "Constructive Criticism", "His Spec-Nade", " ", "^1ItsFebiven", "Ideas", "Suggestions", " ", "^1CraftyCritter", "BO3 GSC Compiler", " ", "^1Joel", "Testing", "Breaking Shit", "Bug Reporting", " ", "^1Thanks For Choosing " + GetMenuName(), "YouTube: ^1CF4_99", "Discord: ^1cf4_99");
    
    self thread MenuCreditsStart(MenuTextStartCredits);
    self SetMenuInstructions("[{+melee}] - Exit Menu Credits");
    
    while(Is_True(self.CreditsPlaying))
    {
        if(self MeleeButtonPressed())
            break;
        
        wait 0.025;
    }
    
    if(Is_True(self.CreditsPlaying))
        self.CreditsPlaying = BoolVar(self.CreditsPlaying);
    
    self notify("EndMenuCredits");
    self SetMenuInstructions();
    self SoftUnlockMenu();
}

MenuCreditsStart(creditArray)
{
    self endon("disconnect");
    self endon("EndMenuCredits");
    
    self.menuUI["MenuCreditsHud"] = [];
    moveTime = 10;
    title = true;

    for(a = 0; a < creditArray.size; a++)
    {
        if(creditArray[a] != " ")
        {
            self.menuUI["MenuCreditsHud"][a] = self createText("objective", title ? 1.4 : 1.1, 4, "", "CENTER", self.menuX + (self.menuUI["background"].width / 2), (self.menuUI["background"].y + (self.menuUI["background"].height - 8)), 0, (1, 1, 1));
            self thread CreditsFadeIn(self.menuUI["MenuCreditsHud"][a], creditArray[a], moveTime, 0.5);
            
            title = false;
            wait (moveTime / 12);
        }
        else
        {
            title = true;
            wait (moveTime / 4);
        }
    }
    
    wait moveTime;

    if(Is_True(self.CreditsPlaying))
        self.CreditsPlaying = BoolVar(self.CreditsPlaying);
}

CreditsFadeIn(hud, text, moveTime, fadeTime)
{
    if(!IsDefined(hud))
        return;
    
    self endon("EndMenuCredits");
    
    self thread credits_delete(hud);
    hud SetTextString(text);
    hud thread hudFade(1, fadeTime);
    hud thread hudMoveY((self.menuUI["background"].y + 12), moveTime);
    
    wait (moveTime - fadeTime);
    
    if(IsDefined(hud))
        hud hudFadeDestroy(0, fadeTime);
}

credits_delete(hud)
{
    if(!IsDefined(hud))
        return;
    
    self endon("disconnect");
    
    self waittill("EndMenuCredits");
    
    if(IsDefined(hud))
        hud DestroyHud();
}

DebugiPrint(message)
{
    if(!IsDefined(self))
    {
        foreach(player in level.players)
            player DebugiPrint(message);
        
        return;
    }
    
    if(!IsDefined(self.PrintMessageQueue))
        self.PrintMessageQueue = [];
    
    if(!IsDefined(self.PrintMessageInt) || (IsDefined(self.PrintMessageInt) && self.PrintMessageInt > 4))
        self.PrintMessageInt = 0;
    
    if(IsDefined(self.PrintMessageQueue[self.PrintMessageInt]))
    {
        self CloseLUIMenu(self.PrintMessageQueue[self.PrintMessageInt]);
        self.PrintMessageQueue[self.PrintMessageInt] = undefined;

        self notify("PrintDeleted" + self.PrintMessageInt);
    }
    
    for(a = 0; a < 5; a++)
    {
        if(IsDefined(self.PrintMessageQueue[a]))
            self SetLUIMenuData(self.PrintMessageQueue[a], "y", (self GetLUIMenuData(self.PrintMessageQueue[a], "y") - 22));
    }
    
    self.PrintMessageQueue[self.PrintMessageInt] = self LUI_createText(message, 0, 20, 500 - ((GetPlayers().size - 1) * 22), 1000, (1, 1, 1));
    self thread iPrintMessageDestroy(self.PrintMessageInt);

    self.PrintMessageInt++;
}

iPrintMessageDestroy(index)
{
    self endon("PrintDeleted" + index);

    wait 5;

    if(IsDefined(self.PrintMessageQueue[index]))
        self CloseLUIMenu(self.PrintMessageQueue[index]);
    
    self.PrintMessageQueue[index] = undefined;
}

/*
    Built To Auto-Size The Width Of A Shader Based On The String Length
    Supports The Use Of \n and button codes(when \n is used, it will scale based on the longest string line)
    Pass The Extra Scaling As A Parameter To Adjust To The Hud Fontscale(Default is 7 if no parameter is passed)

    This will auto-adjust to changes in fontscale
    It will only auto-adjust to the fontscale change if the fontscale is greater than 1.1
    If it is less than, or equal to 1.1, then it will just base it off of 1.1 by default
*/

GetTextWidth3arc(player, widthScale)
{
    if(!IsDefined(self.text) || self.text == "")
        return 1;

    hasButtons = IsSubStr(self.text, "[{");

    if(!IsDefined(widthScale))
    {
        if(hasButtons)
        {
            widthScale = 7;

            if(IsDefined(player) && IsPlayer(player) && player GamePadUsedLast())
                widthScale = 6;
        }
        else
        {
            widthScale = 5;
        }
    }

    widthScale = self GetHudScaleWidth(widthScale);
    nlToks = StrTok(self.text, "\n");
    longest = 0;
    longestSize = 0;

    for(a = 0; a < nlToks.size; a++)
    {
        stripped = StripStringButtons(nlToks[a]);

        if(stripped.size >= longestSize)
        {
            longest = a;
            longestSize = stripped.size;
        }
    }

    strng = StripStringButtons(nlToks[longest]);
    buttonCount = CountButtonCodes(nlToks[longest]);
    width = 1;

    for(a = 0; a < strng.size; a++)
        width += GetHUDCharWidth(strng[a], widthScale);

    if(buttonCount)
        width += Int(widthScale * 1.5) * buttonCount;

    if(width <= 0)
        return widthScale;

    return width;
}

GetHUDCharWidth(ch, widthScale)
{
    if(IsSmallChar(ch))
        return 0;

    if(isInArray(Array("/", ":", "-", "&", "|", " "), ch))
        return Int(widthScale * 0.6);

    return widthScale;
}

GetHudScaleWidth(scale)
{
    if(self.fontscale <= 1.1)
        return scale;

    extra = Int((self.fontscale - 1.1) * 10 + 0.0001);
    return scale + Int(extra / 2);
}

CountButtonCodes(str)
{
    count = 0;

    if(!IsDefined(str) || str == "")
        return count;

    for(a = 0; a < (str.size - 1); a++)
    {
        if(str[a] == "[" && str[(a + 1)] == "{")
            count++;
    }

    return count;
}

StripStringButtons(str)
{
    if(!IsDefined(str) || str == "")
        return "";

    newString = "";

    for(a = 0; a < str.size; a++)
    {
        if(a < (str.size - 1) && str[a] == "[" && str[(a + 1)] == "{")
        {
            for(b = (a + 2); b < str.size; b++)
            {
                if(b < (str.size - 1) && str[b] == "}" && str[(b + 1)] == "]")
                {
                    a = (b + 1);
                    break;
                }
            }

            if(a >= str.size)
                break;

            continue;
        }

        if(a < (str.size - 1) && IsCodeChars(str[a] + str[(a + 1)]))
        {
            a++;
            continue;
        }

        if(IsSmallChar(str[a]))
            continue;

        newString += str[a];
    }

    return newString;
}

IsCodeChars(chars)
{
    return isInArray(Array("^A", "^B", "^F", "^H", "^I", "^0", "^1", "^2", "^3", "^4", "^5", "^6", "^7", "^8", "^9"), chars);
}

IsSmallChar(char)
{
    return isInArray(Array("[", "]", ".", ",", "'", "!", "{", "}", "|"), char);
}

/*
    Built to auto-size a shader based on the given string
    It auto-sizes based on every \n(next line) found in a string
    NOTE: it does not adjust to fontscale
*/

CorrectNL_BGHeight(str)
{
    if(!IsDefined(str))
        return;
    
    if(!IsSubStr(str, "\n"))
        return 12;

    multiplier = 0;
    toks = StrTok(str, "\n");

    if(IsDefined(toks) && toks.size)
    {
        for(a = 0; a < toks.size; a++)
            multiplier++;
    }

    return 3 + (14 * multiplier);
}

//Decided to remake GetDvarVector
GetDvarVector1(vecVar)
{
    dvar = "";
    vecVar = GetDvarString(vecVar);

    if(!IsDefined(vecVar) || vecVar == "")
        return (0, 0, 0);

    for(a = 0; a < vecVar.size; a++)
    {
        if(vecVar[a] != "(" && vecVar[a] != " " && vecVar[a] != ")")
            dvar += vecVar[a];
    }
    
    vals = [];
    toks = StrTok(dvar, ",");
    
    for(a = 0; a < toks.size; a++)
        vals[a] = Float(toks[a]);
    
    if(vals.size < 3)
        return (0, 0, 0);
    
    return (vals[0], vals[1], vals[2]);
}

PlayerScoreIndex(index)
{
    self.PlayerScoreIndex = (index - 1);
    self RefreshMenu(self getCurrent(), self getCursor());
}

PlayerScoreColor(color, index = 1)
{
    if(!IsDefined(color) || !IsVec(color))
        color = (1, 1, 1);
    
    SetDvar("scoreColor" + index, "" + color);
    
    color = GetColorVec(color);
    SetDvar("cg_scorescolor_gamertag_" + index, color[0] + " " + color[1] + " " + color[2] + " 1");
    self RefreshMenu(self getCurrent(), self getCursor());

    self iPrintlnBold("^1" + ToUpper(GetMenuName()) + ": ^7Score Color Will Update At The Start Of Your Next Match");
}

FieldOfViewScale(scale)
{
    SetDvar("cg_fov", scale);
}

FieldOfView(value)
{
    SetDvar("cg_fov_default", value);
}

ShowOrigin()
{
    self.ShowOrigin = BoolVar(self.ShowOrigin);

    if(Is_True(self.ShowOrigin))
    {
        self endon("disconnect");
        self.originHud = [];

        for(a = 0; a < 3; a++)
            self.originHud[self.originHud.size] = self createText("default", 1, 1, 0, "CENTER", 320, 315 + (a * 16), 1, (1, 1, 1));

        while(Is_True(self.ShowOrigin))
        {
            for(a = 0; a < self.originHud.size; a++)
            {
                if(IsDefined(self.originHud[a]))
                    self.originHud[a] SetValue(self.origin[a]);
            }
            
            wait 0.01;
        }
    }
    else
    {
        if(IsDefined(self.originHud) && self.originHud.size)
        {
            for(a = 0; a < self.originHud.size; a++)
            {
                if(IsDefined(self.originHud[a]))
                    self.originHud[a] DestroyHud();
            }
        }
    }
}

Is_True(boolVar)
{
    if(!IsDefined(boolVar) || !boolVar)
        return false;
    
    return true;
}

BoolVar(variable)
{
    if(Is_True(variable))
        return undefined;
    
    return true;
}
