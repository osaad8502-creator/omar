SetGameOverrides()
{
    level.player_out_of_playable_area_monitor = 0;
    level.player_out_of_playable_area_monitor_callback = ::player_out_of_playable_area_monitor;
    level.player_intersection_tracker_override = ::player_intersection_tracker;

    if(IsDefined(level.overrideplayerdamage))
        level.saved_overrideplayerdamage = level.overrideplayerdamage;

    level.overrideplayerdamage = ::override_player_damage;

    if(IsDefined(level.global_damage_func))
        level.saved_global_damage_func = level.global_damage_func;
    
    level.global_damage_func = ::override_zombie_damage;

    if(IsDefined(level.global_damage_func_ads))
        level.saved_global_damage_func_ads = level.global_damage_func_ads;
    
    level.global_damage_func_ads = ::override_zombie_damage_ads;

    if(IsDefined(level.callbackactorkilled))
        level.saved_callbackactorkilled = level.callbackactorkilled;
    
    level.callbackactorkilled = ::override_actor_killed;

    if(ReturnMapName() != "Unknown")
        level.custom_game_over_hud_elem = ::override_game_over_hud_elem;

    if(IsDefined(level.player_score_override))
        level.saved_player_score_override = level.player_score_override;
    
    level.player_score_override = ::override_player_points;
}

override_player_damage(eInflictor, eAttacker, iDamage, iDFlags, sMeansOfDeath, weapon, vPoint, vDir, sHitLoc, psOffsetTime)
{
    if(Is_True(self.playerGodmode) || Is_True(self.PlayerDemiGod) || Is_True(self.NoExplosiveDamage) && zm_utility::is_explosive_damage(sMeansOfDeath) || Is_True(self.ControllableZombie) || Is_True(self.AC130) || Is_True(self.lander))
    {
        if(Is_True(self.PlayerDemiGod))
            self FakeDamageFrom(vDir);
        
        return 0;
    }

    if(iDamage > self.health)
    {
        self.retained_perks = [];

        if(Is_True(self._retain_perks))
        {
            perks = GetArrayKeys(level._custom_perks);

            if(IsDefined(perks) && perks.size)
            {
                MenuPerks = [];
                
                for(a = 0; a < perks.size; a++)
                    array::add(MenuPerks, perks[a], 0);
                
                for(a = 0; a < MenuPerks.size; a++)
                {
                    if(self HasPerk(MenuPerks[a]))
                    {
                        self.retained_perks[self.retained_perks.size] = MenuPerks[a];
                    }
                }
            }
        }
    }

    if(IsDefined(level.saved_overrideplayerdamage))
        return [[ level.saved_overrideplayerdamage ]](eInflictor, eAttacker, iDamage, iDFlags, sMeansOfDeath, weapon, vPoint, vDir, sHitLoc, psOffsetTime);
    
    if(IsDefined(self.saved_playeroverrideplayerdamage))
        return [[ self.saved_playeroverrideplayerdamage ]](eInflictor, eAttacker, iDamage, iDFlags, sMeansOfDeath, weapon, vPoint, vDir, sHitLoc, psOffsetTime);
    
    return zm::player_damage_override(eInflictor, eAttacker, iDamage, iDFlags, sMeansOfDeath, weapon, vPoint, vDir, sHitLoc, psOffsetTime);
}

override_zombie_damage(mod, hit_location, hit_origin, player, amount, team, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel)
{
    if(zm_utility::is_magic_bullet_shield_enabled(self) || IsDefined(self.marked_for_death) || !IsDefined(player) || self zm_spawner::check_zombie_damage_callbacks(mod, hit_location, hit_origin, player, amount, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel))
        return;
    
    self CommonDamageOverride(mod, hit_location, hit_origin, player, amount, team, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel);

    if(IsDefined(level.saved_global_damage_func))
        self thread [[ level.saved_global_damage_func ]](mod, hit_location, hit_origin, player, amount, team, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel);
}

override_zombie_damage_ads(mod, hit_location, hit_origin, player, amount, team, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel)
{
    if(zm_utility::is_magic_bullet_shield_enabled(self) || !IsDefined(player) || self zm_spawner::check_zombie_damage_callbacks(mod, hit_location, hit_origin, player, amount, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel))
        return;
    
    self CommonDamageOverride(mod, hit_location, hit_origin, player, amount, team, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel);

    if(IsDefined(level.saved_global_damage_func_ads))
        self thread [[ level.saved_global_damage_func_ads ]](mod, hit_location, hit_origin, player, amount, team, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel);
}

CommonDamageOverride(mod, hit_location, hit_origin, player, amount, team, weapon, direction_vec, tagname, modelname, partname, dflags, inflictor, chargelevel)
{
    if(IsDefined(self))
    {
        if(IsDefined(level.ZombiesDamageFX))
            thread DisplayZombieEffect(level.ZombiesDamageFX, hit_origin);
        
        if(IsDefined(player) && IsPlayer(player))
        {
            if(Is_True(player.ExtraGore) && IsDefined(level._effect["bloodspurt"]))
            {
                fx = SpawnFX(level._effect["bloodspurt"], hit_origin, direction_vec);

                if(IsDefined(fx))
                    TriggerFX(fx);
            }
            
            if(IsDefined(player.hud_damagefeedback) && Is_True(player.ShowHitmarkers))
                player DamageFeedBack();
            
            if(amount == 696969 && self.health > amount)
            {
                self.maxhealth = 69;
                self.health = 69;
            }

            if(IsDefined(player.PlayerInstaKill) && (player.PlayerInstaKill == "All" || player.PlayerInstaKill == "Melee" && mod == "MOD_MELEE"))
            {
                self.health = 1;
                self DoDamage((self.health + 666), self.origin, player, self, hit_location, zm_utility::remove_mod_from_methodofdeath(mod));
                player notify("zombie_killed");
            }
        }
    }
}

override_actor_killed(einflictor, attacker, idamage, smeansofdeath, weapon, vdir, shitloc, psoffsettime)
{
    if(IsDefined(attacker) && IsPlayer(attacker) && IsDefined(attacker.AP_Phase2Initialized))
        attacker AP_Stats_OnKill(weapon);

    if(game["state"] == "postgame")
        return;
    
    if(IsDefined(level.ZombiesDeathFX))
        thread DisplayZombieEffect(level.ZombiesDeathFX, self.origin);
    
    if(IsDefined(attacker) && IsPlayer(attacker))
    {
        if(Is_True(attacker.ExtraGore) && IsDefined(level._effect["bloodspurt"]))
        {
            fx = SpawnFX(level._effect["bloodspurt"], self.origin, vdir);

            if(IsDefined(fx))
                TriggerFX(fx);
        }

        if(IsDefined(attacker.hud_damagefeedback) && Is_True(attacker.ShowHitmarkers))
            attacker DamageFeedBack();
        
        if(Is_True(level.initAllTheWeapons))
        {
            baseWeapon = !IsVerkoMap() ? zm_weapons::get_base_weapon(weapon) : weapon;

            if(baseWeapon == level.currentWeaponAllTheWeapons)
                level.killsAllTheWeapons++;
            
            if(level.killsAllTheWeapons >= level.killGoalAllTheWeapons)
            {
                level.indexAllTheWeapons++;
                level.killsAllTheWeapons = 0;
            }
        }
    }
    
    if(Is_True(self.explodingzombie) || Is_True(self.ZombieFling) || Is_True(level.ZombieRagdoll) || IsDefined(idamage) && IsInt(idamage) && idamage == 696969)
    {
        self thread zm_spawner::zombie_ragdoll_then_explode(VectorScale(vdir, 145), attacker);

        if(Is_True(self.explodingzombie) && !Is_True(self.nuked))
            self MagicGrenadeType(GetWeapon("frag_grenade"), self GetTagOrigin("j_mainroot"), (0, 0, 0), 0.01);
    }
    
    if(IsDefined(level.saved_callbackactorkilled))
        self thread [[ level.saved_callbackactorkilled ]](einflictor, attacker, idamage, smeansofdeath, weapon, vdir, shitloc, psoffsettime);
}

override_player_points(damage_weapon, player_points)
{
    if(IsDefined(level.saved_player_score_override)) //Der Eisendrache and some custom maps use this override as well
        player_points = self [[ level.saved_player_score_override ]](damage_weapon, player_points);
    
    if(IsDefined(self.DamagePointsMultiplier) || Is_True(self.DisableEarningPoints))
        player_points = (IsDefined(self.DamagePointsMultiplier) && !Is_True(self.DisableEarningPoints)) ? (player_points * self.DamagePointsMultiplier) : 0;
    
    return player_points;
}

DamageFeedBack()
{
    if(!IsDefined(self.hud_damagefeedback))
        return;
    
    if(IsDefined(self.HitMarkerColor))
    {
        if(IsString(self.HitMarkerColor) && self.HitMarkerColor == "Rainbow")
        {
            self.hud_damagefeedback thread HudRGBFade();
        }
        else
        {
            if(Is_True(self.hud_damagefeedback.RGBFade))
                self.hud_damagefeedback.RGBFade = BoolVar(self.hud_damagefeedback.RGBFade);
            
            self.hud_damagefeedback.color = GetColorVec(self.HitMarkerColor);
        }
    }
    
    self zombie_utility::show_hit_marker();

    if(IsDefined(self.HitmarkerFeedbackSound) && self.HitmarkerFeedbackSound != "None" && Is_True(self.hitsoundtracker))
        self PlaySoundToPlayer(self.HitmarkerFeedbackSound, self);
    
    if(IsDefined(self.HitmarkerFeedback))
        self.hud_damagefeedback SetShaderValues(self.HitmarkerFeedback, 24, 48);
}

DisplayZombieEffect(fx, origin)
{
    if(!IsDefined(fx) || !IsString(fx) || !IsDefined(origin) || !IsVec(origin) || !IsDefined(level._effect) || !IsDefined(level._effect[fx]))
        return;
    
    impactfx = SpawnScriptModel(origin, "tag_origin");

    if(IsDefined(impactfx))
    {
        PlayFXOnTag(level._effect[fx], impactfx, "tag_origin");
        impactfx deleteAfter(0.5);
    }
}

override_game_over_hud_elem(player, game_over, survived)
{
    game_over.alignx = "CENTER";
    game_over.aligny = "MIDDLE";

    game_over.horzalign = "CENTER";
    game_over.vertalign = "MIDDLE";

    game_over.y = (game_over.y - 130);
    game_over.foreground = 1;
    game_over.fontscale = 3;
    game_over.alpha = 0;
    game_over.color = player hasMenu() ? level.RGBFadeColor : (1, 1, 1);
    game_over.hidewheninmenu = 1;

    game_over SetText(player hasMenu() ? "Thanks For Using " + GetMenuName() + " Developed By CF4_99" : &"ZOMBIE_GAME_OVER");
    game_over FadeOverTime(1);
    game_over.alpha = 1;

    if(player IsSplitScreen())
    {
        game_over.fontscale = 2;
        game_over.y = (game_over.y + 40);
    }

    survived.alignx = "CENTER";
    survived.aligny = "MIDDLE";

    survived.horzalign = "CENTER";
    survived.vertalign = "MIDDLE";

    survived.y = (survived.y - 100);
    survived.foreground = 1;
    survived.fontscale = 2;
    survived.alpha = 0;
    survived.color = player hasMenu() ? level.RGBFadeColor : (1, 1, 1);
    survived.hidewheninmenu = 1;

    if(player IsHost())
        player thread HoldMeleeToRestart(survived);

    if(player IsSplitScreen())
    {
        survived.fontscale = 1.5;
        survived.y = (survived.y + 40);
    }
}

HoldMeleeToRestart(survived)
{
    if(!IsDefined(self))
        return;
    
    self endon("disconnect");

    while(survived.alpha != 1)
        wait 0.05;
    
    survived SetText("Press & Hold [{+melee}] To Restart The Match");
    goal = 15; //1.5 seconds

    while(1)
    {
        count = 0;

        while(self MeleeButtonPressed())
        {
            count++;

            if(count >= goal)
                break;
            
            wait 0.1;
        }

        if(count >= goal)
            break;
        
        wait 0.01;
    }

    if(count >= goal)
        ServerRestartGame();
}

player_out_of_playable_area_monitor()
{
    return 0;
}

player_intersection_tracker(player)
{
    return 1;
}

WatchForMaxAmmo()
{
    if(Is_True(level.WatchForMaxAmmo))
        return;
    level.WatchForMaxAmmo = true;

    level endon("EndMaxAmmoMonitor");

    while(Is_True(level.ServerMaxAmmoClips))
    {
        level waittill("zmb_max_ammo_level");
        
        if(!Is_True(level.ServerMaxAmmoClips))
            continue;
        
        foreach(player in level.players)
        {
            if(!IsDefined(player) || !Is_Alive(player))
                continue;
            
            foreach(weapon in player GetWeaponsList(1))
            {
                if(!IsDefined(weapon) || weapon == level.weaponnone)
                    continue;
                
                clipAmmo = player GetWeaponAmmoClip(weapon);
                clipSize = weapon.clipsize;

                if(!IsDefined(clipAmmo) || !IsDefined(clipSize))
                    continue;

                if(clipAmmo < clipSize)
                    player SetWeaponAmmoClip(weapon, clipSize);

                if(weapon.isdualwield && weapon.dualwieldweapon != level.weaponnone)
                    player SetWeaponAmmoClip(weapon.dualwieldweapon, clipSize);
            }
        }
    }
}

wallbuy_should_upgrade_weapon_override()
{
    return true;
}

onPlayerDisconnect()
{
    if(self IsHost())
        return;
    
    foreach(player in level.players)
    {
        if(!IsDefined(player) || !IsPlayer(player) || player == self || !player hasMenu())
            continue;
        
        //If a player is navigating another players options, and that player disconnects, it will kick them back to the player menu
        if(IsDefined(player.menu_parent) && isInArray(player.menu_parent, "Players") && player.SelectedPlayer == self)
        {
            openMenu = player isInMenu(false);

            if(openMenu)
                player closeMenu1();
            
            player.menu_parent = [];
            player.currentMenu = "Players";
            player.menu_parent[player.menu_parent.size] = "Main";

            if(openMenu)
            {
                player openMenu1();
                player iPrintlnBold("^1ERROR: ^7Player Has Disconnected");
            }
        }
        else if(player isInMenu() && player getCurrent() == "Players") //If a player is viewing the player menu when a player disconnects, it will refresh the player list
        {
            player RefreshMenu();
        }
    }
}
