# APPARITION PRO MAX — PHASE 3 FINAL INTEGRATION

## Scope
Phase 3 integrates the Phase 1 foundation and Phase 2 core systems into one coordinated Apparition+ system.

## Final flow
Player State → Event Detector → Director → Smart Difficulty → Challenge Generator → Character → HUD

The systems remain modular. They communicate through the AP event/state interfaces rather than directly rewriting each other's internals.

## Integrated systems
- Zombie Counter
- Time Counter
- Perk Guard
- Round 100
- Challenge Generator
- Smart Difficulty
- Event Detector
- Director System
- Interactive Character
- Personality Memory
- Map Personality
- Round Summary
- Loadout Tracker
- Zombie Intel
- Kill Streak
- Clutch Meter
- Session Stats
- Personal Records
- Challenge Streak
- Challenge Difficulty
- HUD Visibility Settings

## Director
The Phase 3 Director follows a state/context decision order:
1. Read live player state.
2. Read recent events.
3. Read map and round state.
4. Read current challenge difficulty.
5. Evaluate pressure and challenge context.
6. Select a bounded action.
7. Trigger the existing event/challenge/character path.

Emergency actions have priority. Challenge generation is suppressed during high pressure. Difficulty is re-evaluated at meaningful state boundaries instead of randomizing every tick.

This is a rule/state Director, not an LLM or external AI service.

## Character
Character dialogue is event-driven and uses bounded session memory plus map personality. Director decisions can intentionally stay silent; they do not have to produce dialogue.

## Challenges
Challenge selection remains map-aware, difficulty-aware, state-aware and anti-repeat. Phase 3 adds current-challenge reevaluation without silently replacing an active challenge or destroying its progress.

## HUD
The existing AP HUD manager remains responsible for visibility and layer ownership. Feature visibility is separate from feature enabled state. The final side menu exposes Smart Difficulty and Director state in addition to the Phase 2 controls.

## Preservation
The final tree was built from the current uploaded `apparition_source_dump.txt`. Original source files are preserved except for the two intentional AP integration points already used by Phase 2:
- `main.gsc`
- `Menu/overrides.gsc`

No Secret Challenges system was added. The optional Weapon Coach, Emergency System, Adaptive Challenges and Daily Run were not promoted to final core features because the supplied design explicitly marked them as additional/not core unless separately adopted.

## Verification
Static verification performed:
- full instruction file read before implementation
- full current Apparition source dump read before implementation
- AP source inspection
- duplicate function-name scan
- AP call/definition scan
- brace-balance scan with comparison against the original source
- original-file byte comparison
- integration-path inspection

No BO3 compiler was available in this environment, so compilation is not claimed.
No PS4/in-game runtime test was available, so runtime success is not claimed.
