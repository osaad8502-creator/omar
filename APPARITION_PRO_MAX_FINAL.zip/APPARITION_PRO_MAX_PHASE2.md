# APPARITION+ — Phase 2 (Core Systems)

## Basis
This phase was rebuilt from the newly supplied Apparition source dump and the project instruction document. The original source files were preserved except for the two intentional integration points:
- `main.gsc`: AP initialization + AP spawn/disconnect callbacks.
- `Menu/overrides.gsc`: one kill-event hook inside `override_actor_killed()`.

The Phase 1 AP modules are carried forward, then Phase 2 modules are added/extended.

## Implemented in Phase 2
1. Zombie Counter — counts live actors from `GetAITeamArray(level.zombie_team)`.
2. Time Counter — session elapsed time based on `GetTime()`.
3. Perk Guard — uses existing `level._custom_perks`, `HasPerk`, `zm_perks::has_perk_paused`, and `zm_perks::give_perk`.
4. Round 100 — wrapper around existing `SetRound(100)`.
5. Challenge Generator — state-aware, non-repeating, map-aware selection.
6. Smart Difficulty — rule/state calculation from round, health, downs, streak, weapon upgrade state, perks, challenge state and recent event history.
7. Event Detector — round/weapon/perk/special-weapon detection plus limited lifecycle polling.
8. Director — basic rule-based coordinator; advanced integration remains Phase 3.
9. Interactive Character — Arabic dialogue pools, event reactions, queue, priority, cooldown and duplicate protection.
10. Personality Memory — bounded session memory.
11. Map Personality — map name is stored and used by the character/challenge layer.
12. Round Summary — temporary HUD on round change.
13. Loadout Tracker — current/previous weapon state from `GetCurrentWeapon()` and `weapon_change` observation.
14. Zombie Intel — live zombie count; no unsupported zombie metadata is fabricated.
15. Kill Streak — event-driven from the real actor-killed hook.
16. Clutch Meter — live pressure metric using zombie count, health, downs and round.
17. Session Stats — kills, downs, revives, round, time and streak data.
18. Personal Records — session/player-variable records; no persistent profile write is claimed.
19. Challenge Streak — completed/failed challenge streak.
20. Challenge Difficulty — Easy / Normal / Hard / Extreme.
21. HUD Visibility — per-layer visibility remains separate from feature enablement.

## Additional implementation
- Challenge HUD
- Challenge difficulty HUD
- Challenge streak HUD
- Loadout HUD
- Kill streak HUD
- Basic Director emergency signal
- Map-filtered example challenges for Kino Der Toten and Origins using only generic kill measurement.

## Verified source APIs used
- `ReturnMapName()`
- `SetRound()`
- `GetAITeamArray(level.zombie_team)`
- `IsAlive()`
- `isDown()`
- `GetCurrentWeapon()`
- `HasPerk()`
- `zm_perks::has_perk_paused()`
- `zm_perks::give_perk()`
- Existing `override_actor_killed()` lifecycle hook
- Existing `createText`, `createRectangle`, and `SetTextString()` HUD patterns.

## Known limitations
- No BO3/GSC compiler was available in this environment, so compilation is not claimed.
- No runtime/PS4 test was available, so in-game behavior is not claimed as verified.
- The source does not expose a clearly defined universal door-purchase callback, so no fake `OnDoorPurchased()` API was invented.
- Pack-a-Punch detection is a conservative fallback based on the weapon entering the source's existing `is_weapon_upgraded`/`"upgraded"` representation; it is not claimed to be a universal PAP-purchase callback.
- Revive/down/death lifecycle detection uses limited polling because a universal player lifecycle callback for each event was not established from this source dump.
- Personal Records are session/player-variable records only in this phase; no permanent profile storage is assumed.
- Director is intentionally basic in Phase 2. Full cross-system decision integration belongs to Phase 3.
- No Secret Challenges were added.

## Validation performed
- All 60 original source files are present and byte-for-byte unchanged except the two intentional integration files above.
- No duplicate GSC function definitions were detected across the rebuilt project.
- All `AP_*` function calls have matching definitions.
- The source tree contains 72 `.gsc` files: 60 original + 12 AP modules.
